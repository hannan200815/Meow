package dev.xoperr.blissgems.utils;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class ParticleUtils {
   public static final Color ASTRA_PURPLE = Color.fromRGB(106, 11, 184);
   public static final Color FIRE_ORANGE = Color.fromRGB(255, 119, 0);
   public static final Color FLUX_CYAN = Color.fromRGB(94, 215, 255);
   public static final Color FLUX_DARK_CYAN = Color.fromRGB(16, 131, 173);
   public static final Color LIFE_PINK = Color.fromRGB(255, 0, 180);
   public static final Color LIFE_PINK_ALT = Color.fromRGB(255, 0, 179);
   public static final Color PUFF_WHITE = Color.fromRGB(255, 255, 255);
   public static final Color SPEED_YELLOW = Color.fromRGB(244, 255, 28);
   public static final Color STRENGTH_RED = Color.fromRGB(199, 0, 10);
   public static final Color WEALTH_GREEN = Color.fromRGB(0, 166, 44);

   public static void drawColoredCircle(Location var0, double var1, Color var3, float var4, int var5) {
      World var6 = var0.getWorld();
      if (var6 != null) {
         Particle.DustOptions var7 = new Particle.DustOptions(var3, var4);

         for(int var8 = 0; var8 < var5; ++var8) {
            double var9 = (double)var8 / (double)var5 * (double)2.0F * Math.PI;
            double var11 = Math.cos(var9) * var1;
            double var13 = Math.sin(var9) * var1;
            Location var15 = var0.clone().add(var11, (double)0.0F, var13);
            var6.spawnParticle(Particle.DUST, var15, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, var7, true);
         }

      }
   }

   public static void drawExpandingCircles(final Location var0, final Color var1, final float var2, double var3, final Runnable var5) {
      final double[] var6 = a(var3);
      (new BukkitRunnable() {
         int a = 0;

         public void run() {
            if (this.a >= var6.length) {
               if (var5 != null) {
                  var5.run();
               }

               this.cancel();
            } else {
               ParticleUtils.drawColoredCircle(var0, var6[this.a], var1, var2, 32);
               if (this.a + 1 < var6.length) {
                  ParticleUtils.drawColoredCircle(var0, var6[this.a + 1], var1, var2, 32);
                  this.a += 2;
               } else {
                  ++this.a;
               }

            }
         }
      }).runTaskTimer(Bukkit.getPluginManager().getPlugin("BlissGems"), 0L, 1L);
   }

   private static double[] a(double var0) {
      int var2 = (int)((var0 - (double)0.75F) / (double)0.25F) + 1;
      double[] var3 = new double[var2];

      for(int var4 = 0; var4 < var2; ++var4) {
         var3[var4] = (double)0.75F + (double)var4 * (double)0.25F;
      }

      return var3;
   }

   public static void drawColoredLine(Location var0, Location var1, Color var2, float var3, int var4) {
      World var5 = var0.getWorld();
      if (var5 != null) {
         Particle.DustOptions var6 = new Particle.DustOptions(var2, var3);
         double var7 = var0.distance(var1);
         int var9 = (int)(var7 * (double)var4);

         for(int var10 = 0; var10 <= var9; ++var10) {
            double var11 = (double)var10 / (double)var9;
            double var13 = var0.getX() + (var1.getX() - var0.getX()) * var11;
            double var15 = var0.getY() + (var1.getY() - var0.getY()) * var11;
            double var17 = var0.getZ() + (var1.getZ() - var0.getZ()) * var11;
            Location var19 = new Location(var5, var13, var15, var17);
            var5.spawnParticle(Particle.DUST, var19, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, var6, true);
         }

      }
   }

   public static void drawPulsingLine(final Location var0, final Location var1, final Color var2, final float var3, final int var4, int var5, final Runnable var6) {
      (new BukkitRunnable() {
         int a = 0;

         public void run() {
            if (this.a >= var4) {
               if (var6 != null) {
                  var6.run();
               }

               this.cancel();
            } else {
               ParticleUtils.drawColoredLine(var0, var1, var2, var3, 10);
               ++this.a;
            }
         }
      }).runTaskTimer(Bukkit.getPluginManager().getPlugin("BlissGems"), 0L, (long)var5);
   }

   public static void drawDome(Location var0, Color var1, float var2, double var3) {
      double[] var5 = new double[]{var3, var3 - (double)1.0F, var3 - (double)2.0F, var3 - (double)3.0F, var3 - (double)4.0F, var3 - (double)5.0F};

      for(int var6 = 0; var6 < var5.length; ++var6) {
         if (!(var5[var6] <= (double)0.0F)) {
            Location var7 = var0.clone().add((double)0.0F, (double)var6, (double)0.0F);
            drawColoredCircle(var7, var5[var6], var1, var2, 48);
         }
      }

   }

   public static void drawSpiral(Location var0, Color var1, float var2, double var3, double var5, double var7) {
      World var9 = var0.getWorld();
      if (var9 != null) {
         Particle.DustOptions var10 = new Particle.DustOptions(var1, var2);
         int var11 = (int)(var3 * (double)8.0F);

         for(int var12 = 0; var12 < var11; ++var12) {
            double var13 = (double)var12 / (double)var11 * var3;
            double var15 = (double)var12 / (double)var11 * (double)4.0F * Math.PI + var7;
            double var17 = Math.cos(var15) * var5;
            double var19 = Math.sin(var15) * var5;
            Location var21 = var0.clone().add(var17, var13, var19);
            var9.spawnParticle(Particle.DUST, var21, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, var10, true);
         }

      }
   }

   public static void drawRing(Location var0, Color var1, float var2, double var3, double var5, int var7) {
      World var8 = var0.getWorld();
      if (var8 != null) {
         Particle.DustOptions var9 = new Particle.DustOptions(var1, var2);

         for(int var10 = 0; var10 < var7; ++var10) {
            double var11 = (double)var10 / (double)var7 * (double)2.0F * Math.PI;
            double var13 = Math.cos(var11) * var3;
            double var15 = Math.sin(var11) * var3;
            Location var17 = var0.clone().add(var13, var5, var15);
            var8.spawnParticle(Particle.DUST, var17, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, var9, true);
         }

      }
   }

   public static void drawBeam(Location var0, Vector var1, double var2, double var4, Particle var6) {
      World var7 = var0.getWorld();
      if (var7 != null) {
         var1 = var1.normalize();
         byte var8 = 25;
         byte var9 = 8;
         double var10 = var2 / (double)var8;

         for(int var12 = 0; var12 < var8; ++var12) {
            Location var13 = var0.clone().add(var1.clone().multiply((double)var12 * var10));
            double var14 = var4 * ((double)1.0F - (double)var12 / (double)var8);
            if (var14 < (double)0.5F) {
               var14 = (double)0.5F;
            }

            for(int var16 = 0; var16 < var9; ++var16) {
               double var17 = (double)var16 / (double)var9 * (double)2.0F * Math.PI;
               Vector var19 = var1.clone().crossProduct(new Vector(0, 1, 0)).normalize();
               Vector var20 = var1.clone().crossProduct(var19).normalize();
               Vector var21 = var19.clone().multiply(Math.cos(var17) * var14).add(var20.clone().multiply(Math.sin(var17) * var14));
               Location var22 = var13.clone().add(var21);
               var7.spawnParticle(var6, var22, 3, (double)0.0F, (double)0.0F, (double)0.0F, 1.0E-9, (Object)null, true);
            }
         }

      }
   }

   public static void drawTrail(Location var0, Particle var1, int var2) {
      World var3 = var0.getWorld();
      if (var3 != null) {
         var3.spawnParticle(var1, var0, var2, 0.1, 0.1, 0.1, (double)0.0F, (Object)null, true);
      }
   }
}
