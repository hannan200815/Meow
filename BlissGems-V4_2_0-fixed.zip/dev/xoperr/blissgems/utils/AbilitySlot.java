package dev.xoperr.blissgems.utils;

public enum AbilitySlot {
   PRIMARY("primary", "Primary"),
   SECONDARY("secondary", "Secondary"),
   TERTIARY("tertiary", "Tertiary"),
   QUATERNARY("quaternary", "Quaternary");

   private final String a;
   private final String b;

   private AbilitySlot(String var3, String var4) {
      this.a = var3;
      this.b = var4;
   }

   public String getId() {
      return this.a;
   }

   public String getDisplayName() {
      return this.b;
   }

   public static AbilitySlot fromId(String var0) {
      if (var0 == null) {
         return null;
      } else {
         String var1 = var0.toLowerCase();

         for(AbilitySlot var5 : values()) {
            if (var5.a.equals(var1)) {
               return var5;
            }
         }

         if (var1.equals("main")) {
            return PRIMARY;
         } else {
            return null;
         }
      }
   }

   // $FF: synthetic method
   private static AbilitySlot[] a() {
      return new AbilitySlot[]{PRIMARY, SECONDARY, TERTIARY, QUATERNARY};
   }
}
