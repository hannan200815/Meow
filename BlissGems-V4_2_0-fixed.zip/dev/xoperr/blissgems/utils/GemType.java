package dev.xoperr.blissgems.utils;

public enum GemType {
   ASTRA("astra", "Astra", "Wield phantom daggers and explore astral dimensions"),
   FIRE("fire", "Fire", "Burn your enemies with charged fireballs and cozy campfires"),
   FLUX("flux", "Flux", "Stun enemies and unleash electric power"),
   LIFE("life", "Life", "Heal yourself and drain the life from enemies"),
   PUFF("puff", "Puff", "Defy gravity with double jumps and immunity to fall damage"),
   SPEED("speed", "Speed", "Move faster and sedate your foes"),
   STRENGTH("strength", "Strength", "Empower your strikes and hunt your enemies"),
   WEALTH("wealth", "Wealth", "Find fortune and fuel an empire");

   private final String id;
   private final String displayName;
   private final String description;

   private GemType(String var3, String var4, String var5) {
      this.id = var3;
      this.displayName = var4;
      this.description = var5;
   }

   public String getId() {
      return this.id;
   }

   public String getDisplayName() {
      return this.displayName;
   }

   public String getDescription() {
      return this.description;
   }

   public String getColor() {
      String var10000;
      switch (this.ordinal()) {
         case 0 -> var10000 = "§d";
         case 1 -> var10000 = "§c";
         case 2 -> var10000 = "§b";
         case 3 -> var10000 = "§a";
         case 4 -> var10000 = "§f";
         case 5 -> var10000 = "§e";
         case 6 -> var10000 = "§4";
         case 7 -> var10000 = "§6";
         default -> throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   public static GemType fromOraxenId(String var0) {
      if (var0 == null) {
         return null;
      } else {
         for(GemType var4 : values()) {
            if (var0.toLowerCase().startsWith(var4.id + "_gem")) {
               return var4;
            }
         }

         return null;
      }
   }

   public static int getTierFromOraxenId(String var0) {
      if (var0 == null) {
         return 1;
      } else {
         return var0.endsWith("_gem_t2") ? 2 : 1;
      }
   }

   public static String buildOraxenId(GemType var0, int var1) {
      String var10000 = var0.getId();
      return var10000 + "_gem_t" + var1;
   }

   public static boolean isGem(String var0) {
      return var0 != null && var0.contains("_gem_t");
   }

   // $FF: synthetic method
   private static GemType[] $values() {
      return new GemType[]{ASTRA, FIRE, FLUX, LIFE, PUFF, SPEED, STRENGTH, WEALTH};
   }
}
