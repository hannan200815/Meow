package dev.xoperr.blissgems.utils;

public enum EnergyState {
   BROKEN(0, 0, "Broken", "§c§lBROKEN"),
   RUINED(1, 1, "Ruined", "§4Ruined"),
   SHATTERED(2, 2, "Shattered", "§6Shattered"),
   CRACKED(3, 3, "Cracked", "§eΩCracked"),
   SCRATCHED(4, 4, "Scratched", "§aSκratched"),
   PRISTINE(5, 5, "Pristine", "§bPristine"),
   PRISTINE_PLUS_1(6, 6, "Pristine +1", "§d§lPristine §5+1"),
   PRISTINE_PLUS_2(7, 7, "Pristine +2", "§d§lPristine §5+2"),
   PRISTINE_PLUS_3(8, 8, "Pristine +3", "§d§lPristine §5+3"),
   PRISTINE_PLUS_4(9, 9, "Pristine +4", "§d§lPristine §5+4"),
   PRISTINE_PLUS_5(10, 10, "Pristine +5", "§d§lPristine §5+5");

   private final int a;
   private final int b;
   private final String c;
   private final String d;

   private EnergyState(int var3, int var4, String var5, String var6) {
      this.a = var3;
      this.b = var4;
      this.c = var5;
      this.d = var6;
   }

   public int getMinEnergy() {
      return this.a;
   }

   public int getMaxEnergy() {
      return this.b;
   }

   public String getName() {
      return this.c;
   }

   public String getDisplayName() {
      return this.d;
   }

   public static EnergyState fromEnergy(int var0) {
      var0 = Math.max(0, Math.min(10, var0));

      for(EnergyState var4 : values()) {
         if (var0 >= var4.a && var0 <= var4.b) {
            return var4;
         }
      }

      return BROKEN;
   }

   public boolean passivesActive() {
      return this.a > 1;
   }

   public boolean abilitiesUsable() {
      return this.a >= 2;
   }

   public boolean isEnhanced() {
      return this.a > 5;
   }

   public boolean isMaxEnergy() {
      return this == PRISTINE_PLUS_5;
   }

   // $FF: synthetic method
   private static EnergyState[] a() {
      return new EnergyState[]{BROKEN, RUINED, SHATTERED, CRACKED, SCRATCHED, PRISTINE, PRISTINE_PLUS_1, PRISTINE_PLUS_2, PRISTINE_PLUS_3, PRISTINE_PLUS_4, PRISTINE_PLUS_5};
   }
}
