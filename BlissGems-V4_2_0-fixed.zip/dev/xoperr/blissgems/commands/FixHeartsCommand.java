package dev.xoperr.blissgems.commands;

import dev.xoperr.blissgems.BlissGems;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class FixHeartsCommand implements CommandExecutor, TabCompleter {
   private final BlissGems plugin;

   public FixHeartsCommand(BlissGems var1) {
      this.plugin = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!var1.hasPermission("blissgems.admin") && !var1.hasPermission("blissgems.fixhearts")) {
         var1.sendMessage("§cYou don't have permission to use this command.");
         return true;
      } else {
         Player var5;
         if (var4.length == 0) {
            if (!(var1 instanceof Player)) {
               var1.sendMessage("§cUsage: /fixhearts <player>");
               return true;
            }

            var5 = (Player)var1;
         } else {
            var5 = Bukkit.getPlayer(var4[0]);
            if (var5 == null) {
               var1.sendMessage("§cPlayer §e" + var4[0] + "§c not found or offline.");
               return true;
            }
         }

         AttributeInstance var6 = var5.getAttribute(Attribute.GENERIC_MAX_HEALTH);
         if (var6 == null) {
            var1.sendMessage("§cCould not access max-health attribute for " + var5.getName() + ".");
            return true;
         } else {
            Logger var10000 = this.plugin.getLogger();
            String var10001 = var5.getName();
            var10000.info("[fixhearts] " + var10001 + " baseValue=" + var6.getBaseValue() + " value=" + var6.getValue() + " health=" + var5.getHealth());

            for(AttributeModifier var8 : var6.getModifiers()) {
               String var9 = "n/a";

               try {
                  NamespacedKey var10 = var8.getKey();
                  if (var10 != null) {
                     var9 = var10.toString();
                  }
               } catch (Throwable var11) {
               }

               var10000 = this.plugin.getLogger();
               var10001 = var8.getName();
               var10000.info("[fixhearts]   modifier name=" + var10001 + " key=" + var9 + " uuid=" + String.valueOf(var8.getUniqueId()) + " amount=" + var8.getAmount() + " op=" + String.valueOf(var8.getOperation()));
            }

            if (this.plugin.getLifeAbilities() != null) {
               this.plugin.getLifeAbilities().cleanup(var5);
            }

            if (this.plugin.getSoulManager() != null) {
               this.plugin.getSoulManager().cleanup(var5);
            }

            int var12 = 0;

            for(AttributeModifier var16 : new ArrayList(var6.getModifiers())) {
               var6.removeModifier(var16);
               ++var12;
            }

            double var15 = var6.getDefaultValue();
            var6.setBaseValue(var15);
            var5.setHealth(var6.getValue());
            var5.sendMessage("§d§l❤ §fYour hearts have been restored.");
            if (var1 != var5) {
               var10001 = var5.getName();
               var1.sendMessage("§aFixed hearts for §l" + var10001 + "§a (removed " + var12 + " modifier(s)).");
            }

            var10000 = this.plugin.getLogger();
            var10001 = var1.getName();
            var10000.info("[fixhearts] " + var10001 + " reset hearts for " + var5.getName() + " (removed " + var12 + " modifier(s))");
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length == 1) {
         String var5 = var4[0].toLowerCase();
         return (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((var1x) -> var1x.toLowerCase().startsWith(var5)).collect(Collectors.toList());
      } else {
         return new ArrayList();
      }
   }
}
