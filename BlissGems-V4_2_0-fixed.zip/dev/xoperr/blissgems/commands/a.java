package dev.xoperr.blissgems.commands;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.GemType;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class a {
   private final BlissGems a;

   public a(BlissGems var1) {
      this.a = var1;
   }

   public void a(Player var1, String[] var2) {
      if (var2.length == 0) {
         this.a(var1);
      } else {
         switch (var2[0].toLowerCase()) {
            case "top":
               this.a(var1);
               break;
            case "me":
            case "my":
            case "personal":
               this.b(var1);
               break;
            case "gems":
            case "usage":
               this.c(var1);
               break;
            default:
               var1.sendMessage("§c/bliss stats [top|me|gems]");
         }
      }

   }

   private void a(Player var1) {
      var1.sendMessage("§6§m" + "═".repeat(50));
      var1.sendMessage("§e§l\ud83c\udfc6 TOP KILLERS \ud83c\udfc6");
      var1.sendMessage("§6§m" + "═".repeat(50));
      List var2 = this.a.getStatsManager().getTopKillers(10);
      if (var2.isEmpty()) {
         var1.sendMessage("§7No kills recorded yet.");
      } else {
         int var3 = 1;

         for(Map.Entry var5 : var2) {
            Player var6 = Bukkit.getPlayer((UUID)var5.getKey());
            String var7 = var6 != null ? var6.getName() : "Unknown";
            String var10000;
            switch (var3) {
               case 1 -> var10000 = "\ud83e\udd47";
               case 2 -> var10000 = "\ud83e\udd48";
               case 3 -> var10000 = "\ud83e\udd49";
               default -> var10000 = "  ";
            }

            String var8 = var10000;
            var1.sendMessage("§e" + var8 + " §7#" + var3 + " §f" + var7 + " §7- §f" + String.valueOf(var5.getValue()) + " §7kills");
            ++var3;
         }
      }

      var1.sendMessage("§6§m" + "═".repeat(50));
      var1.sendMessage("§8Use §7/bliss stats me §8for your personal stats");
      var1.sendMessage("§8Use §7/bliss stats gems §8for gem distribution");
   }

   private void b(Player var1) {
      var1.sendMessage("§6§m" + "═".repeat(50));
      var1.sendMessage("§e§l\ud83d\udcca YOUR STATS \ud83d\udcca");
      var1.sendMessage("§6§m" + "═".repeat(50));
      int var2 = this.a.getStatsManager().getKills(var1);
      int var3 = this.a.getStatsManager().getDeaths(var1);
      long var4 = this.a.getStatsManager().getTimePlayed(var1);
      GemType var6 = this.a.getGemManager().getGemType(var1);
      int var7 = this.a.getEnergyManager().getEnergy(var1);
      var1.sendMessage("§7Kills: §f" + var2);
      var1.sendMessage("§7Deaths: §f" + var3);
      Object var10001 = var3 == 0 ? var2 : String.format("%.2f", (double)var2 / (double)var3);
      var1.sendMessage("§7K/D Ratio: §f" + String.valueOf(var10001));
      String var8 = this.a(var4);
      var1.sendMessage("§7Time Played: §f" + var8);
      var8 = var6 != null ? var6.getDisplayName() : "None";
      var1.sendMessage("§7Current Gem: §f" + var8);
      var1.sendMessage("§7Energy: §f" + var7 + "§8/§f10");
      var1.sendMessage("§6§m" + "═".repeat(50));
   }

   private void c(Player var1) {
      var1.sendMessage("§6§m" + "═".repeat(50));
      var1.sendMessage("§e§l\ud83d\udc8e GEM DISTRIBUTION \ud83d\udc8e");
      var1.sendMessage("§6§m" + "═".repeat(50));
      Map var2 = this.a.getStatsManager().getGemUsageStats();

      for(Map.Entry var4 : var2.entrySet()) {
         String var5 = (String)var4.getKey();
         int var6 = (Integer)var4.getValue();
         String var10000;
         switch (var5) {
            case "Fire Gem" -> var10000 = "\ud83d\udd25";
            case "Speed Gem" -> var10000 = "⚡";
            case "Wealth Gem" -> var10000 = "\ud83d\udcb0";
            case "Astra Gem" -> var10000 = "✨";
            case "Puff Gem" -> var10000 = "\ud83d\udca8";
            case "Flux Gem" -> var10000 = "⚡";
            case "Life Gem" -> var10000 = "❤️";
            case "Strength Gem" -> var10000 = "\ud83d\udcaa";
            default -> var10000 = "  ";
         }

         String var7 = var10000;
         var1.sendMessage("§7" + var7 + " " + var5 + ": §f" + var6 + " §7player" + (var6 == 1 ? "" : "s"));
      }

      var1.sendMessage("§6§m" + "═".repeat(50));
   }

   private String a(long var1) {
      long var3 = var1 / 1000L;
      long var5 = var3 / 60L;
      long var7 = var5 / 60L;
      long var9 = var7 / 24L;
      if (var9 > 0L) {
         return var9 + "d " + var7 % 24L + "h";
      } else if (var7 > 0L) {
         return var7 + "h " + var5 % 60L + "m";
      } else {
         return var5 > 0L ? var5 + "m " + var3 % 60L + "s" : var3 + "s";
      }
   }
}
