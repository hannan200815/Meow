package dev.xoperr.blissgems.commands;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.api.GemDefinition;
import dev.xoperr.blissgems.managers.AbilityBindingManager;
import dev.xoperr.blissgems.managers.GemRegistryImpl;
import dev.xoperr.blissgems.managers.SoulManager;
import dev.xoperr.blissgems.utils.AbilityBinding;
import dev.xoperr.blissgems.utils.AbilitySlot;
import dev.xoperr.blissgems.utils.Achievement;
import dev.xoperr.blissgems.utils.CustomItemManager;
import dev.xoperr.blissgems.utils.EnergyState;
import dev.xoperr.blissgems.utils.GemType;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class BlissCommand implements CommandExecutor, TabCompleter {
   private final BlissGems plugin;

   public BlissCommand(BlissGems var1) {
      this.plugin = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length == 0) {
         if (var1 instanceof Player) {
            this.plugin.getEnhancedGuiManager().openMainMenu((Player)var1);
         } else {
            this.sendHelp(var1);
         }

         return true;
      } else {
         switch (var4[0].toLowerCase()) {
            case "give":
               this.handleGive(var1, var4);
               break;
            case "reroll":
               this.handleReroll(var1, var4);
               break;
            case "giveitem":
               this.handleGiveItem(var1, var4);
               break;
            case "energy":
               this.handleEnergy(var1, var4);
               break;
            case "withdraw":
               this.handleWithdraw(var1, var4);
               break;
            case "info":
               this.handleInfo(var1, var4);
               break;
            case "reload":
               this.handleReload(var1, var4);
               break;
            case "pockets":
               this.handlePockets(var1, var4);
               break;
            case "amplify":
               this.handleAmplify(var1, var4);
               break;
            case "toggle_click":
               this.handleToggleClick(var1, var4);
               break;
            case "ability:main":
               this.handleAbilityMain(var1, var4);
               break;
            case "ability:secondary":
               this.handleAbilitySecondary(var1, var4);
               break;
            case "ability:tertiary":
               this.handleAbilityTertiary(var1, var4);
               break;
            case "ability:quaternary":
               this.handleAbilityQuaternary(var1, var4);
               break;
            case "trust":
               this.handleTrust(var1, var4);
               break;
            case "untrust":
               this.handleUntrust(var1, var4);
               break;
            case "trusted":
               this.handleTrustedList(var1, var4);
               break;
            case "bannable":
               this.handleBannable(var1, var4);
               break;
            case "autosmelt":
               this.handleAutoSmelt(var1, var4);
               break;
            case "stats":
               this.handleStats(var1, var4);
               break;
            case "release":
               this.handleReleaseSouls(var1, var4);
               break;
            case "souls":
               this.handleSoulsInfo(var1, var4);
               break;
            case "achievements":
               this.handleAchievements(var1, var4);
               break;
            case "normalise":
            case "normalize":
               this.handleNormalise(var1, var4);
               break;
            case "smp":
               this.handleSmp(var1, var4);
               break;
            case "clearcds":
               this.handleClearCooldowns(var1, var4);
               break;
            case "ability":
               this.handleAbilityBindingsList(var1, var4);
               break;
            case "set_ability":
               this.handleSetAbility(var1, var4);
               break;
            default:
               this.sendHelp(var1);
         }

         return true;
      }
   }

   private void handleGive(CommandSender var1, String[] var2) {
      if (!var1.hasPermission("blissgems.admin")) {
         var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("no-permission"));
      } else if (var2.length < 3) {
         var1.sendMessage("§cUsage: /bliss give <player> <gem_type> [tier]");
      } else {
         Player var3 = Bukkit.getPlayer(var2[1]);
         if (var3 == null) {
            var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("player-not-found"));
         } else {
            String var4 = var2[2].toLowerCase();
            GemType var5 = null;
            String var6 = null;
            String var7 = null;

            for(GemType var11 : GemType.values()) {
               if (var11.getId().equalsIgnoreCase(var4) || var11.getDisplayName().equalsIgnoreCase(var4)) {
                  var5 = var11;
                  var6 = var11.getId();
                  var7 = var11.getDisplayName();
                  break;
               }
            }

            if (var5 == null) {
               GemRegistryImpl var13 = this.plugin.getGemRegistry();
               if (var13 != null) {
                  GemDefinition var15 = var13.getGem(var4);
                  if (var15 != null) {
                     var6 = var15.getId();
                     var7 = var15.getDisplayName();
                  }
               }
            }

            if (var6 == null) {
               var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("invalid-gem-type"));
            } else {
               int var14 = 1;
               if (var2.length >= 4) {
                  try {
                     var14 = Integer.parseInt(var2[3]);
                     if (var14 < 1 || var14 > 2) {
                        var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("invalid-tier"));
                        return;
                     }
                  } catch (NumberFormatException var12) {
                     var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("invalid-tier"));
                     return;
                  }
               }

               for(int var16 = 0; var16 < var3.getInventory().getSize(); ++var16) {
                  ItemStack var17 = var3.getInventory().getItem(var16);
                  if (var17 != null) {
                     String var18 = CustomItemManager.getIdByItem(var17);
                     if (this.plugin.getGemManager().isAnyGem(var18)) {
                        var3.getInventory().setItem(var16, (ItemStack)null);
                     }
                  }
               }

               if (this.plugin.getGemManager().giveGem(var3, var6, var14)) {
                  var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("gem-given", "player", var3.getName(), "gem", var7, "tier", var14));
               } else {
                  var1.sendMessage("§cFailed to give gem!");
               }

            }
         }
      }
   }

   private void handleReroll(CommandSender var1, String[] var2) {
      if (!var1.hasPermission("blissgems.admin")) {
         var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("no-permission"));
      } else if (var2.length < 2) {
         var1.sendMessage("§cUsage: /bliss reroll <player> [tier]");
      } else {
         Player var3 = Bukkit.getPlayer(var2[1]);
         if (var3 == null) {
            var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("player-not-found"));
         } else {
            ArrayList var4 = new ArrayList();

            for(GemType var8 : GemType.values()) {
               if (this.plugin.getConfig().getBoolean("gems.enabled." + var8.getId(), true)) {
                  var4.add(var8);
               }
            }

            if (var4.isEmpty()) {
               var1.sendMessage("§cNo gems are enabled in the config!");
            } else {
               GemType var11 = (GemType)var4.get((new Random()).nextInt(var4.size()));
               int var12 = 1;
               if (var2.length >= 3) {
                  try {
                     var12 = Integer.parseInt(var2[2]);
                     if (var12 < 1 || var12 > 2) {
                        var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("invalid-tier"));
                        return;
                     }
                  } catch (NumberFormatException var10) {
                     var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("invalid-tier"));
                     return;
                  }
               }

               for(int var13 = 0; var13 < var3.getInventory().getSize(); ++var13) {
                  ItemStack var14 = var3.getInventory().getItem(var13);
                  if (var14 != null) {
                     String var9 = CustomItemManager.getIdByItem(var14);
                     if (this.plugin.getGemManager().isAnyGem(var9)) {
                        var3.getInventory().setItem(var13, (ItemStack)null);
                     }
                  }
               }

               var1.sendMessage("§d§lInitiating gem ritual for " + var3.getName() + "...");
               var3.sendMessage("§d§l§nGEM REROLL RITUAL");
               var3.sendMessage("§7§oThe ancient powers are choosing your fate...");
               this.plugin.getGemRitualManager().performGemRitual(var3, var11, false, var12);
               this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
                  if (this.plugin.getGemManager().giveGem(var3, var11, var12)) {
                     String var5 = this.plugin.getConfigManager().getFormattedMessage("gem-rerolled", "player", var3.getName(), "gem", var11.getDisplayName(), "tier", var12);
                     if (var5 != null && !var5.isEmpty()) {
                        var1.sendMessage(var5);
                     } else {
                        String var10001 = var3.getName();
                        var1.sendMessage("§aRerolled " + var10001 + "'s gem to " + var11.getColor() + var11.getDisplayName() + " §a(Tier " + var12 + ")!");
                     }

                     String var6 = this.plugin.getConfigManager().getFormattedMessage("gem-rerolled-received", "gem", var11.getDisplayName(), "tier", var12);
                     if (var6 != null && !var6.isEmpty()) {
                        var3.sendMessage(var6);
                     } else {
                        String var7 = var11.getColor();
                        var3.sendMessage("§d§l» §fYour gem has been chosen: " + var7 + "§l" + var11.getDisplayName() + " §f(Tier " + var12 + ")§d§l «");
                     }
                  } else {
                     var1.sendMessage("§cFailed to reroll gem!");
                  }

               }, 20L);
            }
         }
      }
   }

   private void handleGiveItem(CommandSender var1, String[] var2) {
      if (!var1.hasPermission("blissgems.admin")) {
         var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("no-permission"));
      } else if (var2.length < 3) {
         var1.sendMessage("§cUsage: /bliss giveitem <player> <item_id> [amount]");
         var1.sendMessage("§7Available items:");
         var1.sendMessage("§b  - energy_bottle");
         var1.sendMessage("§b  - repair_kit");
         var1.sendMessage("§b  - gem_trader");
         var1.sendMessage("§b  - gem_fragment");
         var1.sendMessage("§b  - gem_upgrader §7(universal - works for all gems)");
      } else {
         Player var3 = Bukkit.getPlayer(var2[1]);
         if (var3 == null) {
            var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("player-not-found"));
         } else {
            String var4 = var2[2].toLowerCase();
            int var5 = 1;
            if (var2.length >= 4) {
               try {
                  var5 = Integer.parseInt(var2[3]);
                  if (var5 < 1 || var5 > 64) {
                     var1.sendMessage("§cAmount must be between 1 and 64!");
                     return;
                  }
               } catch (NumberFormatException var8) {
                  var1.sendMessage("§cInvalid amount!");
                  return;
               }
            }

            ItemStack var6 = CustomItemManager.getItemById(var4);
            if (var6 == null) {
               var1.sendMessage("§cInvalid item ID: " + var4);
               var1.sendMessage("§7Available items: energy_bottle, repair_kit, gem_trader, gem_fragment, gem_upgrader");
            } else {
               var6.setAmount(var5);
               var3.getInventory().addItem(new ItemStack[]{var6});
               String var7 = var6.getItemMeta() != null ? var6.getItemMeta().getDisplayName() : var4;
               var1.sendMessage("§aGave " + var5 + "x " + var7 + " §ato " + var3.getName() + "!");
               var3.sendMessage("§aYou received " + var5 + "x " + var7 + "§a!");
            }
         }
      }
   }

   private void handleEnergy(CommandSender var1, String[] var2) {
      if (var2.length == 1) {
         if (!(var1 instanceof Player)) {
            var1.sendMessage("§cOnly players can check their energy!");
         } else {
            Player var10 = (Player)var1;
            int var11 = this.plugin.getEnergyManager().getEnergy(var10);
            EnergyState var12 = EnergyState.fromEnergy(var11);
            String var6 = this.getEnergyBar(var11);
            this.plugin.getConfigManager().sendFormattedMessage(var10, "energy-info-header");
            this.plugin.getConfigManager().sendFormattedMessage(var10, "energy-info-line1", "energyBar", var6, "energy", var11);
            this.plugin.getConfigManager().sendFormattedMessage(var10, "energy-info-line2", "state", var12.getDisplayName());
         }
      } else if (!var1.hasPermission("blissgems.admin")) {
         var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("no-permission"));
      } else if (var2.length < 4) {
         var1.sendMessage("§cUsage: /bliss energy <player> <set/add/remove> <amount>");
      } else {
         Player var4 = Bukkit.getPlayer(var2[1]);
         if (var4 == null) {
            var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("player-not-found"));
         } else {
            String var5 = var2[2].toLowerCase();

            int var3;
            try {
               var3 = Integer.parseInt(var2[3]);
            } catch (NumberFormatException var9) {
               var1.sendMessage("§cInvalid amount!");
               return;
            }

            switch (var5) {
               case "set":
                  this.plugin.getEnergyManager().setEnergy(var4, var3);
                  var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("energy-set", "player", var4.getName(), "amount", var3));
                  break;
               case "add":
                  this.plugin.getEnergyManager().addEnergy(var4, var3);
                  var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("energy-added", "player", var4.getName(), "amount", var3));
                  break;
               case "remove":
                  int var8 = this.plugin.getEnergyManager().getEnergy(var4);
                  if (var8 <= 0) {
                     var1.sendMessage("§c" + var4.getName() + " already has 0 energy!");
                  } else {
                     this.plugin.getEnergyManager().removeEnergy(var4, var3);
                     var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("energy-removed", "player", var4.getName(), "amount", var3));
                  }
                  break;
               default:
                  var1.sendMessage("§cUsage: /bliss energy <player> <set/add/remove> <amount>");
            }

         }
      }
   }

   private String getEnergyBar(int var1) {
      StringBuilder var2 = new StringBuilder();

      for(int var3 = 1; var3 <= 10; ++var3) {
         if (var3 <= var1) {
            var2.append("§a█");
         } else {
            var2.append("§7█");
         }
      }

      return var2.toString();
   }

   private void handleWithdraw(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         int var4 = this.plugin.getEnergyManager().getEnergy(var3);
         if (var4 <= 1) {
            this.plugin.getConfigManager().sendFormattedMessage(var3, "not-enough-energy");
         } else {
            this.plugin.getEnergyManager().removeEnergy(var3, 1);
            ItemStack var5 = CustomItemManager.getItemById("energy_bottle");
            if (var5 != null) {
               var3.getInventory().addItem(new ItemStack[]{var5});
               this.plugin.getConfigManager().sendFormattedMessage(var3, "energy-withdrawn");
            } else {
               this.plugin.getConfigManager().sendFormattedMessage(var3, "energy-bottle-failed");
            }

         }
      }
   }

   private void handleInfo(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else if (!this.plugin.getGemManager().hasActiveGem(var3)) {
         this.plugin.getConfigManager().sendFormattedMessage(var3, "no-active-gem");
      } else {
         GemType var4 = this.plugin.getGemManager().getGemType(var3);
         int var5 = this.plugin.getGemManager().getGemTier(var3);
         int var6 = this.plugin.getEnergyManager().getEnergy(var3);
         EnergyState var7 = this.plugin.getEnergyManager().getEnergyState(var3);
         this.plugin.getConfigManager().sendFormattedMessage(var3, "gem-info", "gem", var4.getDisplayName(), "tier", var5, "energy", var6, "state", var7.getDisplayName());
      }
   }

   private void handleReload(CommandSender var1, String[] var2) {
      if (!var1.hasPermission("blissgems.admin")) {
         this.plugin.getConfigManager().sendFormattedMessage(var1, "no-permission");
      } else {
         this.plugin.getConfigManager().reload();
         this.plugin.getConfigManager().sendFormattedMessage(var1, "config-reloaded");
      }
   }

   private void handlePockets(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         GemType var4 = this.plugin.getGemManager().getGemType(var3);
         if (var4 != GemType.WEALTH) {
            this.plugin.getConfigManager().sendFormattedMessage(var3, "requires-wealth-gem-pockets");
         } else {
            int var5 = this.plugin.getGemManager().getGemTier(var3);
            if (var5 < 2) {
               this.plugin.getConfigManager().sendFormattedMessage(var3, "requires-wealth-t2-pockets");
            } else {
               this.plugin.getWealthAbilities().a(var3);
            }
         }
      }
   }

   private void handleAmplify(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         GemType var4 = this.plugin.getGemManager().getGemType(var3);
         if (var4 != GemType.WEALTH) {
            var3.sendMessage("§cYou need a Wealth gem to use Amplification!");
         } else {
            int var5 = this.plugin.getGemManager().getGemTier(var3);
            if (var5 < 2) {
               var3.sendMessage("§cAmplification requires Tier 2 Wealth gem!");
            } else {
               this.plugin.getWealthAbilities().e(var3);
            }
         }
      }
   }

   private void handleToggleClick(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         boolean var4 = this.plugin.getClickActivationManager().toggleClickActivation(var3);
         if (var4) {
            this.plugin.getConfigManager().sendFormattedMessage(var3, "click-activation-enabled");
         } else {
            this.plugin.getConfigManager().sendFormattedMessage(var3, "click-activation-disabled");
         }

      }
   }

   private String findGemInHand(Player var1) {
      ItemStack var2 = var1.getInventory().getItemInMainHand();
      ItemStack var3 = var1.getInventory().getItemInOffHand();
      GemRegistryImpl var4 = this.plugin.getGemRegistry();
      String var5 = CustomItemManager.getIdByItem(var2);
      if (var5 == null || !GemType.isGem(var5) && (var4 == null || !var4.isRegisteredGem(var5))) {
         var5 = CustomItemManager.getIdByItem(var3);
         return var5 == null || !GemType.isGem(var5) && (var4 == null || !var4.isRegisteredGem(var5)) ? null : var5;
      } else {
         return var5;
      }
   }

   private void handleAbilityMain(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         String var4 = this.findGemInHand(var3);
         if (var4 == null) {
            this.plugin.getConfigManager().sendFormattedMessage(var3, "must-hold-gem");
         } else {
            int var5 = this.plugin.getEnergyManager().getEnergy(var3);
            if (var5 <= 0) {
               this.plugin.getConfigManager().sendFormattedMessage(var3, "no-energy");
            } else {
               GemRegistryImpl var6 = this.plugin.getGemRegistry();
               int var7 = var6 != null ? var6.tierFromItemId(var4) : (var4.endsWith("_gem_t2") ? 2 : 1);
               GemType var8 = GemType.fromOraxenId(var4);
               if (var8 != null) {
                  switch (var8) {
                     case ASTRA -> this.plugin.getAstraAbilities().g(var3);
                     case FIRE -> this.plugin.getFireAbilities().d(var3);
                     case FLUX -> this.plugin.getFluxAbilities().e(var3);
                     case LIFE -> this.plugin.getLifeAbilities().a(var3);
                     case PUFF -> this.plugin.getPuffAbilities().c(var3);
                     case SPEED -> this.plugin.getSpeedAbilities().a(var3, var7);
                     case STRENGTH -> this.plugin.getStrengthAbilities().a(var3);
                     case WEALTH -> this.plugin.getWealthAbilities().b(var3);
                  }

               } else {
                  if (var6 != null) {
                     String var9 = var6.gemIdFromItemId(var4);
                     GemAbilityHandler var10 = var9 != null ? var6.getAbilityHandler(var9) : null;
                     if (var10 != null) {
                        var10.onPrimary(var3, var7);
                     }
                  }

               }
            }
         }
      }
   }

   private void handleAbilitySecondary(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         String var4 = this.findGemInHand(var3);
         if (var4 == null) {
            this.plugin.getConfigManager().sendFormattedMessage(var3, "must-hold-gem");
         } else {
            GemRegistryImpl var5 = this.plugin.getGemRegistry();
            int var6 = var5 != null ? var5.tierFromItemId(var4) : (var4.endsWith("_gem_t2") ? 2 : 1);
            if (var6 < 2) {
               String var11 = this.plugin.getConfigManager().getFormattedMessage("requires-tier2");
               if (var11 != null && !var11.isEmpty()) {
                  var3.sendMessage(var11);
               }

            } else {
               int var7 = this.plugin.getEnergyManager().getEnergy(var3);
               if (var7 <= 0) {
                  String var12 = this.plugin.getConfigManager().getFormattedMessage("no-energy");
                  if (var12 != null && !var12.isEmpty()) {
                     var3.sendMessage(var12);
                  }

               } else {
                  GemType var8 = GemType.fromOraxenId(var4);
                  if (var8 != null) {
                     switch (var8) {
                        case ASTRA -> this.plugin.getAstraAbilities().h(var3);
                        case FIRE -> this.plugin.getFireAbilities().f(var3);
                        case FLUX -> this.plugin.getFluxAbilities().e(var3);
                        case LIFE -> this.plugin.getLifeAbilities().b(var3);
                        case PUFF -> this.plugin.getPuffAbilities().d(var3);
                        case SPEED -> this.plugin.getSpeedAbilities().d(var3);
                        case STRENGTH -> this.plugin.getStrengthAbilities().b(var3);
                        case WEALTH -> this.plugin.getWealthAbilities().d(var3);
                     }

                  } else {
                     if (var5 != null) {
                        String var9 = var5.gemIdFromItemId(var4);
                        GemAbilityHandler var10 = var9 != null ? var5.getAbilityHandler(var9) : null;
                        if (var10 != null) {
                           var10.onSecondary(var3, var6);
                        }
                     }

                  }
               }
            }
         }
      }
   }

   public void triggerPrimary(Player var1) {
      this.handleAbilityMain(var1, new String[0]);
   }

   public void triggerSecondary(Player var1) {
      this.handleAbilitySecondary(var1, new String[0]);
   }

   public void triggerTertiary(Player var1) {
      this.handleAbilityTertiary(var1, new String[0]);
   }

   public void triggerQuaternary(Player var1) {
      this.handleAbilityQuaternary(var1, new String[0]);
   }

   public boolean triggerSlot(Player var1, AbilitySlot var2) {
      if (var2 == null) {
         return false;
      } else {
         switch (var2) {
            case PRIMARY:
               this.triggerPrimary(var1);
               return true;
            case SECONDARY:
               this.triggerSecondary(var1);
               return true;
            case TERTIARY:
               this.triggerTertiary(var1);
               return true;
            case QUATERNARY:
               this.triggerQuaternary(var1);
               return true;
            default:
               return false;
         }
      }
   }

   private void handleAbilityTertiary(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         String var4 = this.findGemInHand(var3);
         if (var4 == null) {
            String var11 = this.plugin.getConfigManager().getFormattedMessage("must-hold-gem");
            if (var11 != null && !var11.isEmpty()) {
               var3.sendMessage(var11);
            }

         } else {
            GemRegistryImpl var5 = this.plugin.getGemRegistry();
            int var6 = var5 != null ? var5.tierFromItemId(var4) : (var4.endsWith("_gem_t2") ? 2 : 1);
            if (var6 < 2) {
               String var12 = this.plugin.getConfigManager().getFormattedMessage("requires-tier2");
               if (var12 != null && !var12.isEmpty()) {
                  var3.sendMessage(var12);
               }

            } else {
               int var7 = this.plugin.getEnergyManager().getEnergy(var3);
               if (var7 <= 0) {
                  String var13 = this.plugin.getConfigManager().getFormattedMessage("no-energy");
                  if (var13 != null && !var13.isEmpty()) {
                     var3.sendMessage(var13);
                  }

               } else {
                  GemType var8 = GemType.fromOraxenId(var4);
                  if (var8 != null) {
                     switch (var8) {
                        case ASTRA -> this.plugin.getAstraAbilities().a(var3);
                        case FIRE -> this.plugin.getFireAbilities().h(var3);
                        case FLUX -> this.plugin.getFluxAbilities().f(var3);
                        case LIFE -> this.plugin.getLifeAbilities().c(var3);
                        case PUFF -> this.plugin.getPuffAbilities().e(var3);
                        case SPEED -> this.plugin.getSpeedAbilities().a(var3);
                        case STRENGTH -> this.plugin.getStrengthAbilities().c(var3);
                        case WEALTH -> this.plugin.getWealthAbilities().c(var3);
                        default -> var3.sendMessage("§c§oNo tertiary ability for your gem type!");
                     }

                  } else {
                     if (var5 != null) {
                        String var9 = var5.gemIdFromItemId(var4);
                        GemAbilityHandler var10 = var9 != null ? var5.getAbilityHandler(var9) : null;
                        if (var10 != null) {
                           var10.onTertiary(var3, var6);
                        }
                     }

                  }
               }
            }
         }
      }
   }

   private void handleAbilityQuaternary(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         String var4 = this.findGemInHand(var3);
         if (var4 == null) {
            String var11 = this.plugin.getConfigManager().getFormattedMessage("must-hold-gem");
            if (var11 != null && !var11.isEmpty()) {
               var3.sendMessage(var11);
            }

         } else {
            GemRegistryImpl var5 = this.plugin.getGemRegistry();
            int var6 = var5 != null ? var5.tierFromItemId(var4) : (var4.endsWith("_gem_t2") ? 2 : 1);
            if (var6 < 2) {
               String var12 = this.plugin.getConfigManager().getFormattedMessage("requires-tier2");
               if (var12 != null && !var12.isEmpty()) {
                  var3.sendMessage(var12);
               }

            } else {
               int var7 = this.plugin.getEnergyManager().getEnergy(var3);
               if (var7 <= 0) {
                  String var13 = this.plugin.getConfigManager().getFormattedMessage("no-energy");
                  if (var13 != null && !var13.isEmpty()) {
                     var3.sendMessage(var13);
                  }

               } else {
                  GemType var8 = GemType.fromOraxenId(var4);
                  if (var8 != null) {
                     switch (var8) {
                        case ASTRA:
                           this.plugin.getAstraAbilities().b(var3);
                           break;
                        case FIRE:
                           this.plugin.getFireAbilities().i(var3);
                           break;
                        case FLUX:
                           this.plugin.getFluxAbilities().g(var3);
                           break;
                        case LIFE:
                           this.plugin.getLifeAbilities().d(var3);
                           break;
                        case PUFF:
                        case SPEED:
                        case STRENGTH:
                        default:
                           var3.sendMessage("§c§oNo quaternary ability for your gem type!");
                           break;
                        case WEALTH:
                           this.plugin.getWealthAbilities().e(var3);
                     }

                  } else {
                     if (var5 != null) {
                        String var9 = var5.gemIdFromItemId(var4);
                        GemAbilityHandler var10 = var9 != null ? var5.getAbilityHandler(var9) : null;
                        if (var10 != null) {
                           var10.onQuaternary(var3, var6);
                        }
                     }

                  }
               }
            }
         }
      }
   }

   private void handleAbilityBindingsList(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         AbilityBindingManager var4 = this.plugin.getAbilityBindingManager();
         if (var4 == null) {
            var3.sendMessage("§cBinding system unavailable.");
         } else {
            EnumMap var5 = var4.getAll(var3);
            var3.sendMessage("§d§l⚡ Your Ability Bindings");

            for(AbilitySlot var9 : AbilitySlot.values()) {
               AbilityBinding var10 = null;

               for(Map.Entry var12 : var5.entrySet()) {
                  if (var12.getValue() == var9) {
                     var10 = (AbilityBinding)var12.getKey();
                     break;
                  }
               }

               String var18 = var10 != null ? "§f" + var10.getDisplayName() : "§8unbound";
               String var10001 = var9.getDisplayName();
               var3.sendMessage("§7" + var10001 + " §8→ " + var18);
            }

            var3.sendMessage("");
            var3.sendMessage("§d§l⚡ Available Inputs");

            for(AbilityBinding var16 : AbilityBinding.values()) {
               AbilitySlot var17 = (AbilitySlot)var5.get(var16);
               String var19 = var17 != null ? " §8(§7" + var17.getDisplayName() + "§8)" : "";
               String var20 = var16.getId();
               var3.sendMessage("§f• §7" + var20 + " §8- §f" + var16.getDisplayName() + var19);
            }

            var3.sendMessage("");
            var3.sendMessage("§7Change with §f/bliss set_ability <slot> <input>");
            var3.sendMessage("§7Unbind a slot with §f/bliss set_ability <slot> none");
            var3.sendMessage("§7Reset defaults with §f/bliss set_ability reset");
         }
      }
   }

   private void handleSetAbility(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         AbilityBindingManager var4 = this.plugin.getAbilityBindingManager();
         if (var4 == null) {
            var3.sendMessage("§cBinding system unavailable.");
         } else if (var2.length >= 2 && var2[1].equalsIgnoreCase("reset")) {
            var4.resetToDefaults(var3);
            var3.sendMessage("§aAbility bindings reset to defaults.");
         } else if (var2.length < 3) {
            var3.sendMessage("§cUsage: §f/bliss set_ability <slot> <input>");
            var3.sendMessage("§7Slots: §fprimary, secondary, tertiary, quaternary");
            var3.sendMessage("§7Inputs: §fright_click, shift_right_click, left_click, shift_left_click, swap_hand, shift_swap_hand, none");
            var3.sendMessage("§7See current bindings with §f/bliss ability");
         } else {
            AbilitySlot var5 = AbilitySlot.fromId(var2[1]);
            if (var5 == null) {
               var3.sendMessage("§cUnknown slot: §f" + var2[1] + "§c. Valid: primary, secondary, tertiary, quaternary.");
            } else {
               String var6 = var2[2];
               if (!var6.equalsIgnoreCase("none") && !var6.equalsIgnoreCase("unbind")) {
                  AbilityBinding var10 = AbilityBinding.fromId(var6);
                  if (var10 == null) {
                     var3.sendMessage("§cUnknown input: §f" + var6 + "§c. See §f/bliss ability§c for the list.");
                  } else {
                     var4.setBinding(var3, var10, var5);
                     String var10001 = var10.getDisplayName();
                     var3.sendMessage("§aBound §f" + var10001 + "§a → §l" + var5.getDisplayName() + "§a.");
                  }
               } else {
                  EnumMap var7 = var4.getAll(var3);

                  for(Map.Entry var9 : var7.entrySet()) {
                     if (var9.getValue() == var5) {
                        var4.unbind(var3, (AbilityBinding)var9.getKey());
                     }
                  }

                  var3.sendMessage("§aUnbound §l" + var5.getDisplayName() + "§a.");
               }
            }
         }
      }
   }

   private void handleTrust(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else if (var2.length < 2) {
         var1.sendMessage("§cUsage: /bliss trust <player>");
      } else {
         Player var3 = (Player)var1;
         Player var4 = Bukkit.getPlayer(var2[1]);
         if (var4 == null) {
            var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("player-not-found"));
         } else if (var3.getUniqueId().equals(var4.getUniqueId())) {
            var3.sendMessage("§cYou already trust yourself!");
         } else {
            this.plugin.getTrustedPlayersManager().addTrustedPlayer(var3, var4);
            var3.sendMessage("§aYou now trust §l" + var4.getName() + "§r§a! Your gem abilities will not harm them.");
            var4.sendMessage("§a" + var3.getName() + " §anow trusts you! Their gem abilities will not harm you.");
         }
      }
   }

   private void handleUntrust(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else if (var2.length < 2) {
         var1.sendMessage("§cUsage: /bliss untrust <player>");
      } else {
         Player var3 = (Player)var1;
         Player var4 = Bukkit.getPlayer(var2[1]);
         if (var4 == null) {
            var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("player-not-found"));
         } else {
            boolean var5 = this.plugin.getTrustedPlayersManager().removeTrustedPlayer(var3, var4);
            if (var5) {
               var3.sendMessage("§cYou no longer trust §l" + var4.getName() + "§r§c! Your gem abilities can now harm them.");
               var4.sendMessage("§c" + var3.getName() + " §cno longer trusts you! Their gem abilities can now harm you.");
            } else {
               var3.sendMessage("§cYou were not trusting " + var4.getName() + "!");
            }

         }
      }
   }

   private void handleTrustedList(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         Set var4 = this.plugin.getTrustedPlayersManager().getTrustedPlayers(var3);
         if (var4.isEmpty()) {
            var3.sendMessage("§7You have no trusted players. Use §b/bliss trust <player>§7 to add someone.");
         } else {
            var3.sendMessage("§5§lTrusted Players (" + var4.size() + "):");

            for(UUID var6 : var4) {
               OfflinePlayer var7 = Bukkit.getOfflinePlayer(var6);
               String var8 = var7.getName() != null ? var7.getName() : var6.toString();
               String var9 = var7.isOnline() ? "§a[Online]" : "§7[Offline]";
               var3.sendMessage("§8 - §b" + var8 + " " + var9);
            }

         }
      }
   }

   private void handleBannable(CommandSender var1, String[] var2) {
      if (!var1.hasPermission("blissgems.admin")) {
         var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("no-permission"));
      } else if (var2.length < 2) {
         var1.sendMessage("§cUsage: /bliss bannable <true/false>");
         var1.sendMessage("§7Current status: " + (this.plugin.getConfigManager().isBanOnZeroEnergyEnabled() ? "§aEnabled" : "§cDisabled"));
      } else {
         String var3 = var2[1].toLowerCase();
         boolean var4;
         if (!var3.equals("true") && !var3.equals("on") && !var3.equals("yes") && !var3.equals("1")) {
            if (!var3.equals("false") && !var3.equals("off") && !var3.equals("no") && !var3.equals("0")) {
               var1.sendMessage("§cInvalid value! Use true or false.");
               return;
            }

            var4 = false;
         } else {
            var4 = true;
         }

         this.plugin.getConfigManager().setBanOnZeroEnergy(var4);
         if (var4) {
            String var5 = this.plugin.getConfigManager().getFormattedMessage("ban-enabled");
            if (var5 != null && !var5.isEmpty()) {
               var1.sendMessage(var5);
            } else {
               var1.sendMessage("§aBan-on-zero-energy has been enabled!");
            }
         } else {
            String var6 = this.plugin.getConfigManager().getFormattedMessage("ban-disabled");
            if (var6 != null && !var6.isEmpty()) {
               var1.sendMessage(var6);
            } else {
               var1.sendMessage("§cBan-on-zero-energy has been disabled!");
            }
         }

      }
   }

   private void handleAutoSmelt(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else if (!var3.hasPermission("blissgems.autosmelt")) {
         var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("no-permission"));
      } else {
         GemType var4 = this.plugin.getGemManager().getGemType(var3);
         int var5 = this.plugin.getGemManager().getGemTier(var3);
         if (var4 == GemType.WEALTH && var5 >= 2) {
            boolean var6 = this.plugin.getWealthAbilities().f(var3);
            this.plugin.getWealthAbilities().a(var3, !var6);
            if (!var6) {
               var3.sendMessage("§a§lAuto-Smelt enabled! Ores will now be automatically smelted when mined.");
            } else {
               var3.sendMessage("§c§lAuto-Smelt disabled!");
            }

         } else {
            var3.sendMessage("§c§lYou need Wealth Gem Tier 2 to use auto-smelt!");
         }
      }
   }

   private void handleStats(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         a var4 = new a(this.plugin);
         var4.a(var3, var2.length > 1 ? (String[])Arrays.copyOfRange(var2, 1, var2.length) : new String[0]);
      }
   }

   private void handleReleaseSouls(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else if (!this.plugin.getGemManager().hasGemType(var3, GemType.ASTRA)) {
         var3.sendMessage("§c§oOnly Astra gem holders can release captured souls!");
      } else if (!this.plugin.getEnergyManager().arePassivesActive(var3)) {
         var3.sendMessage("§c§oYour gem energy is too low to release souls!");
      } else {
         this.plugin.getSoulManager().releaseAllSouls(var3);
      }
   }

   private void handleSoulsInfo(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else if (!this.plugin.getGemManager().hasGemType(var3, GemType.ASTRA)) {
         var3.sendMessage("§c§oOnly Astra gem holders can view captured souls!");
      } else {
         List var4 = this.plugin.getSoulManager().getCapturedSouls(var3);
         int var5 = var4.size();
         byte var6 = 2;
         var3.sendMessage("§d§lCaptured Souls (" + var5 + "/" + var6 + "):");
         if (var5 == 0) {
            var3.sendMessage("§7  No souls captured. Sneak + hit a mob to capture it.");
         } else {
            for(int var7 = 0; var7 < var4.size(); ++var7) {
               var3.sendMessage("§d  " + (var7 + 1) + ". §f" + ((SoulManager.CapturedMob)var4.get(var7)).getDisplayName());
            }

            var3.sendMessage("§7  Use §d/bliss release§7 to release all captured souls.");
         }

      }
   }

   private void handleNormalise(CommandSender var1, String[] var2) {
      if (!var1.hasPermission("blissgems.admin")) {
         var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("no-permission"));
      } else {
         int var3 = 0;

         for(Player var5 : Bukkit.getOnlinePlayers()) {
            AttributeInstance var6 = var5.getAttribute(Attribute.GENERIC_ATTACK_SPEED);
            if (var6 != null) {
               double var7 = var6.getBaseValue();
               var6.setBaseValue((double)1024.0F);
               var6.setBaseValue(var7);
            }

            ++var3;
         }

         var1.sendMessage("§a§lAttack cooldown reset for " + var3 + " online player(s)!");

         for(Player var10 : Bukkit.getOnlinePlayers()) {
            var10.sendMessage("§e§oAttack cooldowns have been normalized by an admin.");
         }

      }
   }

   private void handleSmp(CommandSender var1, String[] var2) {
      if (!var1.hasPermission("blissgems.admin")) {
         var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("no-permission"));
      } else if (var2.length >= 2 && var2[1].equalsIgnoreCase("start")) {
         if (this.plugin.getConfigManager().isSmpStarted()) {
            this.plugin.getConfigManager().sendFormattedMessage(var1, "smp-already-started");
         } else {
            this.plugin.getConfigManager().setSmpStarted(true);
            this.plugin.getConfigManager().sendFormattedMessage(var1, "smp-started");

            for(Player var4 : Bukkit.getOnlinePlayers()) {
               if (!this.hasReceivedFirstGem(var4)) {
                  GemType var5 = this.getRandomEnabledGem();
                  if (var5 != null) {
                     var4.sendMessage("");
                     var4.sendMessage("§d§l§m                                                  ");
                     var4.sendMessage("§d§lWELCOME TO BLISSGEMS!");
                     var4.sendMessage("");
                     var4.sendMessage("§7§oThe ancient gem ritual begins...");
                     var4.sendMessage("§7§oYour destiny is being forged...");
                     var4.sendMessage("§d§l§m                                                  ");
                     var4.sendMessage("");
                     this.plugin.getGemRitualManager().performGemRitual(var4, var5, true, 1);
                     this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
                        if (var4.isOnline() && this.plugin.getGemManager().giveGem(var4, (GemType)var5, 1)) {
                           this.markFirstGemReceived(var4);
                           String var3 = this.plugin.getConfigManager().getFormattedMessage("first-gem-received", "gem", var5.getDisplayName());
                           if (var3 != null && !var3.isEmpty()) {
                              var4.sendMessage(var3);
                           } else {
                              var4.sendMessage("");
                              String var10001 = var5.getColor();
                              var4.sendMessage("§d§l» §fYour gem has been chosen: " + var10001 + "§l" + var5.getDisplayName() + "§d§l «");
                              var4.sendMessage("");
                           }

                           Logger var10000 = this.plugin.getLogger();
                           String var4x = var4.getName();
                           var10000.info("SMP Start: Gave " + var4x + " their first gem: " + var5.getDisplayName());
                        }

                     }, 20L);
                  }
               }
            }

         }
      } else {
         var1.sendMessage("§cUsage: /bliss smp start");
      }
   }

   private boolean hasReceivedFirstGem(Player var1) {
      File var2 = new File(this.plugin.getDataFolder(), "playerdata");
      File var3 = new File(var2, String.valueOf(var1.getUniqueId()) + ".yml");
      if (!var3.exists()) {
         return false;
      } else {
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         return ((FileConfiguration)var4).getBoolean("received-first-gem", false);
      }
   }

   private void markFirstGemReceived(Player var1) {
      File var2 = new File(this.plugin.getDataFolder(), "playerdata");
      if (!var2.exists()) {
         var2.mkdirs();
      }

      File var3 = new File(var2, String.valueOf(var1.getUniqueId()) + ".yml");
      YamlConfiguration var4;
      if (var3.exists()) {
         var4 = YamlConfiguration.loadConfiguration(var3);
      } else {
         var4 = new YamlConfiguration();
      }

      ((FileConfiguration)var4).set("received-first-gem", true);
      if (!((FileConfiguration)var4).contains("energy")) {
         ((FileConfiguration)var4).set("energy", this.plugin.getConfigManager().getStartingEnergy());
      }

      try {
         ((FileConfiguration)var4).save(var3);
      } catch (IOException var6) {
         Logger var10000 = this.plugin.getLogger();
         String var10001 = var1.getName();
         var10000.warning("Failed to save first gem status for " + var10001 + ": " + var6.getMessage());
      }

   }

   private GemType getRandomEnabledGem() {
      ArrayList var1 = new ArrayList();

      for(GemType var5 : GemType.values()) {
         if (this.plugin.getConfigManager().isGemEnabled(var5)) {
            var1.add(var5);
         }
      }

      if (var1.isEmpty()) {
         return null;
      } else {
         return (GemType)var1.get((new Random()).nextInt(var1.size()));
      }
   }

   private void handleClearCooldowns(CommandSender var1, String[] var2) {
      if (!var1.hasPermission("blissgems.admin")) {
         var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("no-permission"));
      } else if (var2.length < 2) {
         var1.sendMessage("§cUsage: /bliss clearcds <player|all>");
      } else if (!var2[1].equalsIgnoreCase("all")) {
         Player var6 = Bukkit.getPlayer(var2[1]);
         if (var6 == null) {
            var1.sendMessage(this.plugin.getConfigManager().getFormattedMessage("player-not-found"));
         } else {
            this.plugin.getAbilityManager().clearCooldowns(var6);
            var1.sendMessage("§aCleared all ability cooldowns for §l" + var6.getName() + "§a!");
         }
      } else {
         int var3 = 0;

         for(Player var5 : Bukkit.getOnlinePlayers()) {
            this.plugin.getAbilityManager().clearCooldowns(var5);
            ++var3;
         }

         var1.sendMessage("§a§lCleared all ability cooldowns for " + var3 + " online player(s)!");
      }
   }

   private void handleAchievements(CommandSender var1, String[] var2) {
      if (!(var1 instanceof Player var3)) {
         var1.sendMessage("§cOnly players can use this command!");
      } else {
         Set var4 = this.plugin.getAchievementManager().getUnlocked(var3);
         int var5 = Achievement.values().length;
         int var6 = var4.size();
         var3.sendMessage("§6§l⭐ Achievements (" + var6 + "/" + var5 + ")");
         var3.sendMessage("");

         for(Achievement var10 : Achievement.values()) {
            boolean var11 = var4.contains(var10);
            int var12 = this.plugin.getAchievementManager().getProgress(var3, var10);
            int var13 = var10.getTargetProgress();
            if (var11) {
               String var10001 = var10.getDisplayName();
               var3.sendMessage("§a✔ §e" + var10001 + " §7- " + var10.getDescription());
            } else if (var13 > 1 && var12 > 0) {
               String var15 = var10.getDisplayName();
               var3.sendMessage("§8✘ §7" + var15 + " §8- " + var10.getDescription() + " §e(" + var12 + "/" + var13 + ")");
            } else {
               String var14 = var10.getDisplayName();
               var3.sendMessage("§8✘ §7" + var14 + " §8- " + var10.getDescription());
            }
         }

      }
   }

   private void sendHelp(CommandSender var1) {
      var1.sendMessage("§5§lBlissGems Commands:");
      var1.sendMessage("§7/bliss give <player> <gem_type> [tier] §8- Give a gem");
      var1.sendMessage("§7/bliss reroll <player> [tier] §8- Give a random gem");
      var1.sendMessage("§7/bliss giveitem <player> <item_id> [amount] §8- Give special items");
      var1.sendMessage("§7/bliss energy <player> <set/add/remove> <amount> §8- Manage energy");
      var1.sendMessage("§7/bliss withdraw §8- Extract energy into bottle");
      var1.sendMessage("§7/bliss info §8- Show your gem info");
      var1.sendMessage("§7/bliss pockets §8- Open personal inventory (Wealth T2)");
      var1.sendMessage("§7/bliss amplify §8- Amplify potion effects (Wealth T2)");
      var1.sendMessage("§7/bliss autosmelt §8- Toggle auto-smelting (Wealth T2)");
      var1.sendMessage("§7/bliss toggle_click §8- Toggle click activation on/off");
      var1.sendMessage("§7/bliss ability:main §8- Trigger primary ability");
      var1.sendMessage("§7/bliss ability:secondary §8- Trigger secondary ability (T2)");
      var1.sendMessage("§7/bliss trust <player> §8- Trust player (prevent friendly fire)");
      var1.sendMessage("§7/bliss untrust <player> §8- Untrust player");
      var1.sendMessage("§7/bliss trusted §8- List trusted players");
      var1.sendMessage("§7/bliss souls §8- View captured souls (Astra)");
      var1.sendMessage("§7/bliss release §8- Release captured souls (Astra)");
      var1.sendMessage("§7/bliss achievements §8- View your achievements");
      var1.sendMessage("§7/bliss stats [top|me|gems] §8- View server stats");
      var1.sendMessage("§7/bliss bannable <true/false> §8- Toggle ban on 0 energy (Admin)");
      var1.sendMessage("§7/bliss smp start §8- Start the SMP and distribute gems (Admin)");
      var1.sendMessage("§7/bliss normalise §8- Reset attack cooldowns for all players (Admin)");
      var1.sendMessage("§7/bliss clearcds <player|all> §8- Clear ability cooldowns (Admin)");
      var1.sendMessage("§7/bliss reload §8- Reload config");
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      ArrayList var5 = new ArrayList();
      if (var4.length == 1) {
         var5.addAll(Arrays.asList("give", "reroll", "giveitem", "energy", "withdraw", "info", "pockets", "amplify", "autosmelt", "reload", "toggle_click", "ability:main", "ability:secondary", "ability:tertiary", "ability:quaternary", "trust", "untrust", "trusted", "stats", "achievements", "bannable", "souls", "release", "normalise", "normalize", "smp", "clearcds"));
      } else if (var4.length == 2) {
         if (var4[0].equalsIgnoreCase("clearcds")) {
            List var6 = (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList());
            var6.add(0, "all");
            return var6;
         }

         if (var4[0].equalsIgnoreCase("give") || var4[0].equalsIgnoreCase("reroll") || var4[0].equalsIgnoreCase("giveitem") || var4[0].equalsIgnoreCase("energy") || var4[0].equalsIgnoreCase("trust") || var4[0].equalsIgnoreCase("untrust")) {
            return (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList());
         }

         if (var4[0].equalsIgnoreCase("stats")) {
            return Arrays.asList("top", "me", "gems");
         }

         if (var4[0].equalsIgnoreCase("bannable")) {
            return Arrays.asList("true", "false");
         }

         if (var4[0].equalsIgnoreCase("smp")) {
            return Arrays.asList("start");
         }
      } else if (var4.length == 3) {
         if (var4[0].equalsIgnoreCase("give")) {
            List var11 = (List)Arrays.stream(GemType.values()).map(GemType::getId).collect(Collectors.toList());
            GemRegistryImpl var7 = this.plugin.getGemRegistry();
            if (var7 != null) {
               for(GemDefinition var9 : var7.getAllGems()) {
                  if (!var11.contains(var9.getId())) {
                     var11.add(var9.getId());
                  }
               }
            }

            return var11;
         }

         if (var4[0].equalsIgnoreCase("giveitem")) {
            ArrayList var10 = new ArrayList();
            var10.add("energy_bottle");
            var10.add("repair_kit");
            var10.add("gem_trader");
            var10.add("gem_fragment");
            var10.add("gem_upgrader");
            return var10;
         }

         if (var4[0].equalsIgnoreCase("energy")) {
            return Arrays.asList("set", "add", "remove");
         }
      } else if (var4.length == 3) {
         if (var4[0].equalsIgnoreCase("reroll")) {
            return Arrays.asList("1", "2");
         }
      } else if (var4.length == 4) {
         if (var4[0].equalsIgnoreCase("give")) {
            return Arrays.asList("1", "2");
         }

         if (var4[0].equalsIgnoreCase("giveitem")) {
            return Arrays.asList("1", "8", "16", "32", "64");
         }
      }

      return (List)var5.stream().filter((var1x) -> var1x.toLowerCase().startsWith(var4[var4.length - 1].toLowerCase())).collect(Collectors.toList());
   }
}
