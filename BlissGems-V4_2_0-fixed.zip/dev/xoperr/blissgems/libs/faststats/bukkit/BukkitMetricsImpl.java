package dev.xoperr.blissgems.libs.faststats.bukkit;

import com.google.gson.JsonObject;
import dev.xoperr.blissgems.libs.faststats.core.SimpleMetrics;
import java.nio.file.Path;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.logging.Level;
import org.b.a.b;
import org.b.a.e;
import org.bukkit.Server;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;
import org.c.a.d;

final class BukkitMetricsImpl extends SimpleMetrics implements BukkitMetrics {
   private final Plugin plugin;
   private final String pluginVersion;
   private final String minecraftVersion;
   private final String serverType;

   @b.b
   @e(
      c = "io"
   )
   private BukkitMetricsImpl(Factory var1, Plugin var2, Path var3) throws IllegalStateException {
      super(var1, (Path)var3);
      this.plugin = var2;
      Server var4 = var2.getServer();
      this.pluginVersion = (String)this.tryOrEmpty(() -> var2.getPluginMeta().getVersion()).orElseGet(() -> var2.getDescription().getVersion());
      this.minecraftVersion = (String)this.tryOrEmpty(() -> var4.getMinecraftVersion()).or(() -> this.tryOrEmpty(() -> var4.getBukkitVersion().split("-", 2)[0])).orElseGet(() -> var4.getVersion().split("\\(MC: |\\)", 3)[1]);
      this.serverType = var4.getName();
      this.startSubmitting();
   }

   Plugin plugin() {
      return this.plugin;
   }

   private boolean checkOnlineMode() {
      Server var1 = this.plugin.getServer();
      Optional var10000 = this.tryOrEmpty(() -> var1.getServerConfig().isProxyOnlineMode()).or(() -> this.tryOrEmpty(this::isProxyOnlineMode));
      Objects.requireNonNull(var1);
      return (Boolean)var10000.orElseGet(var1::getOnlineMode);
   }

   private boolean isProxyOnlineMode() {
      Server var1 = this.plugin.getServer();
      ConfigurationSection var2 = var1.spigot().getPaperConfig().getConfigurationSection("proxies");
      if (var2 == null) {
         return false;
      } else if (var2.getBoolean("velocity.enabled") && var2.getBoolean("velocity.online-mode")) {
         return true;
      } else {
         ConfigurationSection var3 = var1.spigot().getSpigotConfig().getConfigurationSection("settings");
         if (var3 == null) {
            return false;
         } else {
            return var3.getBoolean("bungeecord") && var2.getBoolean("bungee-cord.online-mode");
         }
      }
   }

   protected void appendDefaultData(JsonObject var1) {
      var1.addProperty("minecraft_version", this.minecraftVersion);
      var1.addProperty("online_mode", this.checkOnlineMode());
      var1.addProperty("player_count", (Number)this.getPlayerCount());
      var1.addProperty("plugin_version", this.pluginVersion);
      var1.addProperty("server_type", this.serverType);
   }

   private int getPlayerCount() {
      try {
         return this.plugin.getServer().getOnlinePlayers().size();
      } catch (Throwable var2) {
         this.error("Failed to get player count", var2);
         return 0;
      }
   }

   protected void printError(String var1, @d Throwable var2) {
      this.plugin.getLogger().log(Level.SEVERE, var1, var2);
   }

   protected void printInfo(String var1) {
      this.plugin.getLogger().info(var1);
   }

   protected void printWarning(String var1) {
      this.plugin.getLogger().warning(var1);
   }

   public void ready() {
      if (this.getErrorTracker().isPresent()) {
         try {
            Class.forName("com.destroystokyo.paper.event.server.ServerExceptionEvent");
            this.plugin.getServer().getPluginManager().registerEvents(new PaperEventListener(this), this.plugin);
         } catch (ClassNotFoundException var2) {
         }
      }

   }

   private <T> Optional<T> tryOrEmpty(Supplier<T> var1) {
      try {
         return Optional.of(var1.get());
      } catch (Exception | NoSuchMethodError var3) {
         return Optional.empty();
      }
   }

   static final class Factory extends SimpleMetrics.Factory<Plugin, BukkitMetrics.Factory> implements BukkitMetrics.Factory {
      public BukkitMetrics create(Plugin var1) throws IllegalStateException {
         Path var2 = getPluginsFolder(var1).resolve("faststats");
         Path var3 = var2.resolve("config.properties");
         return new BukkitMetricsImpl(this, var1, var3);
      }

      private static Path getPluginsFolder(Plugin var0) {
         try {
            return var0.getServer().getPluginsFolder().toPath();
         } catch (NoSuchMethodError var2) {
            return var0.getDataFolder().getParentFile().toPath();
         }
      }
   }
}
