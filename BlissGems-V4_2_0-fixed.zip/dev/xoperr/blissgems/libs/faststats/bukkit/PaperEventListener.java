package dev.xoperr.blissgems.libs.faststats.bukkit;

import com.destroystokyo.paper.event.server.ServerExceptionEvent;
import com.destroystokyo.paper.exception.ServerException;
import com.destroystokyo.paper.exception.ServerPluginException;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

record PaperEventListener(BukkitMetricsImpl metrics) implements Listener {
   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onServerException(ServerExceptionEvent var1) {
      ServerException var3 = var1.getException();
      if (var3 instanceof ServerPluginException var2) {
         if (var2.getResponsiblePlugin().equals(this.metrics.plugin())) {
            this.metrics.getErrorTracker().ifPresent((var1x) -> var1x.trackError((Throwable)var2));
         }
      }
   }
}
