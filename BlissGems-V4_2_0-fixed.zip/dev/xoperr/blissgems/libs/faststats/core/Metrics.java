package dev.xoperr.blissgems.libs.faststats.core;

import dev.xoperr.blissgems.libs.faststats.core.data.Metric;
import java.net.URI;
import java.util.Optional;
import java.util.UUID;
import org.b.a.b;
import org.b.a.e;

public interface Metrics {
   @Token
   @e(
      b = true
   )
   String getToken();

   @e(
      b = true
   )
   Optional<ErrorTracker> getErrorTracker();

   @e(
      b = true
   )
   Config getConfig();

   default void ready() {
   }

   @e(
      c = "this"
   )
   void shutdown();

   public sealed interface Config permits SimpleMetrics.Config {
      @e(
         b = true
      )
      UUID serverId();

      @e(
         b = true
      )
      boolean enabled();

      @e(
         b = true
      )
      boolean errorTracking();

      @e(
         b = true
      )
      boolean additionalMetrics();

      @e(
         b = true
      )
      boolean debug();
   }

   public interface Factory<T, F extends Factory<T, F>> {
      @e(
         c = "this"
      )
      F addMetric(Metric<?> var1) throws IllegalArgumentException;

      @e(
         c = "this"
      )
      F onFlush(Runnable var1);

      @e(
         c = "this"
      )
      F errorTracker(ErrorTracker var1);

      @e(
         c = "this"
      )
      F debug(boolean var1);

      @e(
         c = "this"
      )
      F token(@Token String var1) throws IllegalArgumentException;

      @e(
         c = "this"
      )
      F url(URI var1);

      @b.b
      @e(
         a = "_ -> new",
         c = "io"
      )
      Metrics create(T var1) throws IllegalStateException;
   }
}
