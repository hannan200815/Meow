package dev.xoperr.blissgems.libs.faststats.core;

import com.google.gson.JsonObject;
import dev.xoperr.blissgems.libs.faststats.core.data.Metric;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpConnectTimeoutException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.time.Duration;
import java.util.HashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BiPredicate;
import java.util.zip.GZIPOutputStream;
import org.b.a.b;
import org.b.a.e;
import org.b.a.g;
import org.b.a.t;
import org.c.a.d;

public abstract class SimpleMetrics implements Metrics {
   private final HttpClient httpClient;
   private @d ScheduledExecutorService executor;
   private final Set<Metric<?>> metrics;
   private final Config config;
   @Token
   private final String token;
   private final @d ErrorTracker tracker;
   private final @d Runnable flush;
   private final URI url;
   private final boolean debug;
   private final String SDK_NAME;
   private final String SDK_VERSION;
   private final String javaVersion;
   private final String osArch;
   private final String osName;
   private final String osVersion;
   private final int coreCount;

   @e(
      c = "io"
   )
   protected SimpleMetrics(Factory<?, ?> var1, Config var2) throws IllegalStateException {
      this.httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3L)).version(Version.HTTP_1_1).build();
      this.executor = null;
      Properties var3 = new Properties();

      try {
         InputStream var4 = this.getClass().getResourceAsStream("/META-INF/faststats.properties");

         try {
            if (var4 != null) {
               var3.load(var4);
            }
         } catch (Throwable var8) {
            if (var4 != null) {
               try {
                  var4.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }
            }

            throw var8;
         }

         if (var4 != null) {
            var4.close();
         }
      } catch (IOException var9) {
      }

      this.SDK_NAME = var3.getProperty("name", "unknown");
      this.SDK_VERSION = var3.getProperty("version", "unknown");
      this.javaVersion = System.getProperty("java.version");
      this.osArch = System.getProperty("os.arch");
      this.osName = System.getProperty("os.name");
      this.osVersion = System.getProperty("os.version");
      this.coreCount = Runtime.getRuntime().availableProcessors();
      if (var1.token == null) {
         throw new IllegalStateException("Token must be specified");
      } else {
         this.config = var2;
         this.metrics = var2.additionalMetrics ? Set.copyOf(var1.metrics) : Set.of();
         this.debug = var1.debug || Boolean.getBoolean("faststats.debug") || var2.debug();
         this.token = var1.token;
         this.tracker = var2.errorTracking ? var1.tracker : null;
         this.flush = var1.flush;
         this.url = var1.url;
      }
   }

   @e(
      c = "io"
   )
   protected SimpleMetrics(Factory<?, ?> var1, Path var2) throws IllegalStateException {
      this(var1, SimpleMetrics.Config.read(var2));
   }

   @t
   protected SimpleMetrics(Config var1, Set<Metric<?>> var2, @Token String var3, @d ErrorTracker var4, @d Runnable var5, URI var6, boolean var7) {
      this.httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3L)).version(Version.HTTP_1_1).build();
      this.executor = null;
      Properties var8 = new Properties();

      try {
         InputStream var9 = this.getClass().getResourceAsStream("/META-INF/faststats.properties");

         try {
            if (var9 != null) {
               var8.load(var9);
            }
         } catch (Throwable var13) {
            if (var9 != null) {
               try {
                  var9.close();
               } catch (Throwable var12) {
                  var13.addSuppressed(var12);
               }
            }

            throw var13;
         }

         if (var9 != null) {
            var9.close();
         }
      } catch (IOException var14) {
      }

      this.SDK_NAME = var8.getProperty("name", "unknown");
      this.SDK_VERSION = var8.getProperty("version", "unknown");
      this.javaVersion = System.getProperty("java.version");
      this.osArch = System.getProperty("os.arch");
      this.osName = System.getProperty("os.name");
      this.osVersion = System.getProperty("os.version");
      this.coreCount = Runtime.getRuntime().availableProcessors();
      if (!var3.matches("[a-z0-9]{32}")) {
         throw new IllegalArgumentException("Invalid token '" + var3 + "', must match '[a-z0-9]{32}'");
      } else {
         this.metrics = var1.additionalMetrics ? Set.copyOf(var2) : Set.of();
         this.config = var1;
         this.debug = var7;
         this.token = var3;
         this.tracker = var4;
         this.flush = var5;
         this.url = var6;
      }
   }

   protected String getOnboardingMessage() {
      return "This plugin uses FastStats to collect anonymous usage statistics.\nNo personal or identifying information is ever collected.\nTo opt out, set 'enabled=false' in the metrics configuration file.\nLearn more at: https://faststats.dev/info\n\nSince this is your first start with FastStats, metrics submission will not start\nuntil you restart the server to allow you to opt out if you prefer.";
   }

   protected long getInitialDelay() {
      return TimeUnit.SECONDS.toMillis(Long.getLong("faststats.initial-delay", 30L));
   }

   protected long getPeriod() {
      return TimeUnit.MINUTES.toMillis(30L);
   }

   @b.b
   @g
   protected void startSubmitting() {
      this.startSubmitting(this.getInitialDelay(), this.getPeriod(), TimeUnit.MILLISECONDS);
   }

   private void startSubmitting(long var1, long var3, TimeUnit var5) {
      if (Boolean.getBoolean("faststats.first-run")) {
         this.info("Skipping metrics submission due to first-run flag");
      } else {
         if (this.config.firstRun) {
            int var6 = 0;
            String[] var7 = this.getOnboardingMessage().split("\n");

            for(String var11 : var7) {
               if (var11.length() > var6) {
                  var6 = var11.length();
               }
            }

            this.printInfo("-".repeat(var6));

            for(String var16 : var7) {
               this.printInfo(var16);
            }

            this.printInfo("-".repeat(var6));
            System.setProperty("faststats.first-run", "true");
            if (!this.config.externallyManaged()) {
               return;
            }
         }

         boolean var12 = Boolean.parseBoolean(System.getProperty("faststats.enabled", "true"));
         if (this.config.enabled() && var12) {
            if (this.isSubmitting()) {
               this.warn("Metrics already submitting, not starting again");
            } else {
               this.executor = Executors.newSingleThreadScheduledExecutor((var0) -> {
                  Thread var1 = new Thread(var0, "metrics-submitter");
                  var1.setDaemon(true);
                  return var1;
               });
               this.info("Starting metrics submission");
               this.executor.scheduleAtFixedRate(this::submit, Math.max(0L, var1), Math.max(1000L, var3), var5);
            }
         } else {
            this.warn("Metrics disabled, not starting submission");
         }
      }
   }

   protected boolean isSubmitting() {
      return this.executor != null && !this.executor.isShutdown();
   }

   public boolean submit() {
      try {
         return this.submitNow();
      } catch (Throwable var2) {
         this.error("Failed to submit metrics", var2);
         return false;
      }
   }

   private boolean submitNow() throws IOException {
      String var1 = this.createData().toString();
      byte[] var2 = var1.getBytes(StandardCharsets.UTF_8);
      this.info("Uncompressed data: " + var1);
      ByteArrayOutputStream var3 = new ByteArrayOutputStream();

      boolean var10;
      label88: {
         boolean var18;
         try {
            GZIPOutputStream var4;
            label92: {
               var4 = new GZIPOutputStream(var3);

               try {
                  label93: {
                     var4.write(var2);
                     var4.finish();
                     byte[] var5 = var3.toByteArray();
                     this.info("Compressed size: " + var5.length + " bytes");
                     HttpRequest.Builder var10000 = HttpRequest.newBuilder().POST(BodyPublishers.ofByteArray(var5)).header("Content-Encoding", "gzip").header("Content-Type", "application/octet-stream").header("Authorization", "Bearer " + this.getToken());
                     String var10002 = this.getSdkName();
                     HttpRequest var6 = var10000.header("User-Agent", "FastStats Metrics " + var10002 + "/" + this.getSdkVersion()).timeout(Duration.ofSeconds(3L)).uri(this.url).build();
                     this.info("Sending metrics to: " + String.valueOf(this.url));

                     try {
                        HttpResponse var7 = this.httpClient.send(var6, BodyHandlers.ofString(StandardCharsets.UTF_8));
                        int var8 = var7.statusCode();
                        String var9 = (String)var7.body();
                        if (var8 >= 200 && var8 < 300) {
                           this.info("Metrics submitted with status code: " + var8 + " (" + var9 + ")");
                           Optional var19 = this.getErrorTracker();
                           Objects.requireNonNull(SimpleErrorTracker.class);
                           var19.map(SimpleErrorTracker.class::cast).ifPresent(SimpleErrorTracker::clear);
                           if (this.flush != null) {
                              this.flush.run();
                           }

                           var10 = true;
                           break label93;
                        }

                        if (var8 >= 300 && var8 < 400) {
                           this.warn("Received redirect response from metrics server: " + var8 + " (" + var9 + ")");
                        } else if (var8 >= 400 && var8 < 500) {
                           this.error("Submitted invalid request to metrics server: " + var8 + " (" + var9 + ")", (Throwable)null);
                        } else if (var8 >= 500 && var8 < 600) {
                           this.error("Received server error response from metrics server: " + var8 + " (" + var9 + ")", (Throwable)null);
                        } else {
                           this.warn("Received unexpected response from metrics server: " + var8 + " (" + var9 + ")");
                        }
                     } catch (HttpConnectTimeoutException var13) {
                        this.error("Metrics submission timed out after 3 seconds: " + String.valueOf(this.url), (Throwable)null);
                     } catch (ConnectException var14) {
                        this.error("Failed to connect to metrics server: " + String.valueOf(this.url), (Throwable)null);
                     } catch (Throwable var15) {
                        this.error("Failed to submit metrics", var15);
                     }

                     var18 = false;
                     break label92;
                  }
               } catch (Throwable var16) {
                  try {
                     var4.close();
                  } catch (Throwable var12) {
                     var16.addSuppressed(var12);
                  }

                  throw var16;
               }

               var4.close();
               break label88;
            }

            var4.close();
         } catch (Throwable var17) {
            try {
               var3.close();
            } catch (Throwable var11) {
               var17.addSuppressed(var11);
            }

            throw var17;
         }

         var3.close();
         return var18;
      }

      var3.close();
      return var10;
   }

   private String getSdkName() {
      return this.SDK_NAME;
   }

   private String getSdkVersion() {
      return this.SDK_VERSION;
   }

   protected JsonObject createData() {
      JsonObject var1 = new JsonObject();
      JsonObject var2 = new JsonObject();
      var2.addProperty("java_version", this.javaVersion);
      var2.addProperty("os_arch", this.osArch);
      var2.addProperty("os_name", this.osName);
      var2.addProperty("os_version", this.osVersion);
      var2.addProperty("core_count", (Number)this.coreCount);
      this.metrics.forEach((var2x) -> {
         try {
            var2x.getData().ifPresent((var2xx) -> var2.add(var2x.getId(), var2xx));
         } catch (Throwable var4) {
            this.error("Failed to build metric data: " + var2x.getId(), var4);
            this.getErrorTracker().ifPresent((var1) -> var1.trackError(var4));
         }

      });

      try {
         this.appendDefaultData(var2);
      } catch (Throwable var4) {
         this.error("Failed to append default data", var4);
         this.getErrorTracker().ifPresent((var1x) -> var1x.trackError(var4));
      }

      var1.addProperty("identifier", this.config.serverId().toString());
      var1.add("data", var2);
      Optional var10000 = this.getErrorTracker();
      Objects.requireNonNull(SimpleErrorTracker.class);
      var10000.map(SimpleErrorTracker.class::cast).map(SimpleErrorTracker::getData).filter((var0) -> !var0.isEmpty()).ifPresent((var1x) -> var1.add("errors", var1x));
      return var1;
   }

   @Token
   public String getToken() {
      return this.token;
   }

   public Optional<ErrorTracker> getErrorTracker() {
      return Optional.ofNullable(this.tracker);
   }

   public Metrics.Config getConfig() {
      return this.config;
   }

   @e(
      c = "param1"
   )
   protected abstract void appendDefaultData(JsonObject var1);

   protected void error(String var1, @d Throwable var2) {
      if (this.debug) {
         this.printError("[" + this.getClass().getName() + "]: " + var1, var2);
      }

   }

   protected void warn(String var1) {
      if (this.debug) {
         String var10001 = this.getClass().getName();
         this.printWarning("[" + var10001 + "]: " + var1);
      }

   }

   protected void info(String var1) {
      if (this.debug) {
         String var10001 = this.getClass().getName();
         this.printInfo("[" + var10001 + "]: " + var1);
      }

   }

   protected abstract void printError(String var1, @d Throwable var2);

   protected abstract void printInfo(String var1);

   protected abstract void printWarning(String var1);

   public void shutdown() {
      this.getErrorTracker().ifPresent(ErrorTracker::detachErrorContext);
      if (this.executor != null) {
         try {
            this.info("Shutting down metrics submission");
            this.executor.shutdown();
            Optional var10000 = this.getErrorTracker();
            Objects.requireNonNull(SimpleErrorTracker.class);
            var10000.map(SimpleErrorTracker.class::cast).filter(SimpleErrorTracker::needsFlushing).ifPresent((var1) -> this.submit());
         } catch (Throwable var5) {
            this.error("Failed to submit metrics on shutdown", var5);
         } finally {
            this.executor = null;
         }
      }

   }

   public abstract static class Factory<T, F extends Metrics.Factory<T, F>> implements Metrics.Factory<T, F> {
      private final Set<Metric<?>> metrics = new HashSet(0);
      private URI url = URI.create("https://metrics.faststats.dev/v1/collect");
      private @d ErrorTracker tracker;
      private @d Runnable flush;
      private @d String token;
      private boolean debug = false;

      public F addMetric(Metric<?> var1) throws IllegalArgumentException {
         if (!this.metrics.add(var1)) {
            throw new IllegalArgumentException("Metric already added: " + var1.getId());
         } else {
            return (F)this;
         }
      }

      public F onFlush(Runnable var1) {
         this.flush = var1;
         return (F)this;
      }

      public F errorTracker(ErrorTracker var1) {
         this.tracker = var1;
         return (F)this;
      }

      public F debug(boolean var1) {
         this.debug = var1;
         return (F)this;
      }

      public F token(@Token String var1) throws IllegalArgumentException {
         if (!var1.matches("[a-z0-9]{32}")) {
            throw new IllegalArgumentException("Invalid token '" + var1 + "', must match '[a-z0-9]{32}'");
         } else {
            this.token = var1;
            return (F)this;
         }
      }

      public F url(URI var1) {
         this.url = var1;
         return (F)this;
      }
   }

   public static record Config(UUID serverId, boolean additionalMetrics, boolean debug, boolean enabled, boolean errorTracking, boolean firstRun, boolean externallyManaged) implements Metrics.Config {
      public static final String DEFAULT_COMMENT = " FastStats (https://faststats.dev) collects anonymous usage statistics for plugin developers.\n# This helps developers understand how their projects are used in the real world.\n#\n# No IP addresses, player data, or personal information is collected.\n# The server ID below is randomly generated and can be regenerated at any time.\n#\n# Enabling metrics has no noticeable performance impact.\n# Keeping metrics enabled is recommended, but you can disable them by setting 'enabled=false'.\n#\n# If you suspect a plugin is collecting personal data or bypassing the \"enabled\" option,\n# please report it at: https://faststats.dev/abuse\n#\n# For more information, visit: https://faststats.dev/info\n";

      @e(
         c = "io"
      )
      public static Config read(Path var0) throws RuntimeException {
         return read(var0, " FastStats (https://faststats.dev) collects anonymous usage statistics for plugin developers.\n# This helps developers understand how their projects are used in the real world.\n#\n# No IP addresses, player data, or personal information is collected.\n# The server ID below is randomly generated and can be regenerated at any time.\n#\n# Enabling metrics has no noticeable performance impact.\n# Keeping metrics enabled is recommended, but you can disable them by setting 'enabled=false'.\n#\n# If you suspect a plugin is collecting personal data or bypassing the \"enabled\" option,\n# please report it at: https://faststats.dev/abuse\n#\n# For more information, visit: https://faststats.dev/info\n", false, false);
      }

      @e(
         c = "io"
      )
      public static Config read(Path var0, String var1, boolean var2, boolean var3) throws RuntimeException {
         Optional var4 = readOrEmpty(var0);
         boolean var5 = var4.isEmpty();
         AtomicBoolean var6 = new AtomicBoolean(var5);
         UUID var7 = (UUID)var4.map((var0x) -> var0x.getProperty("serverId")).map((var1x) -> {
            try {
               String var2 = var1x.trim();
               String var3 = var2.length() > 36 ? var2.substring(0, 36) : var2;
               if (!var3.equals(var1x)) {
                  var6.set(true);
               }

               return UUID.fromString(var3);
            } catch (IllegalArgumentException var4) {
               var6.set(true);
               return UUID.randomUUID();
            }
         }).orElseGet(() -> {
            var6.set(true);
            return UUID.randomUUID();
         });
         BiPredicate var8 = (var2x, var3x) -> (Boolean)var4.map((var1) -> var1.getProperty(var2x)).map(Boolean::parseBoolean).orElseGet(() -> {
               var6.set(true);
               return var3x;
            });
         boolean var9 = var2 ? var3 : var8.test("enabled", true);
         boolean var10 = var8.test("submitErrors", true);
         boolean var11 = var8.test("submitAdditionalMetrics", true);
         boolean var12 = var8.test("debug", false);
         if (var6.get()) {
            try {
               save(var0, var2, var1, var7, var9, var10, var11, var12);
            } catch (IOException var14) {
               throw new RuntimeException("Failed to save metrics config", var14);
            }
         }

         return new Config(var7, var11, var12, var9, var10, var5, var2);
      }

      private static Optional<Properties> readOrEmpty(Path var0) throws RuntimeException {
         if (!Files.isRegularFile(var0, new LinkOption[0])) {
            return Optional.empty();
         } else {
            try {
               BufferedReader var1 = Files.newBufferedReader(var0, StandardCharsets.UTF_8);

               Optional var3;
               try {
                  Properties var2 = new Properties();
                  var2.load(var1);
                  var3 = Optional.of(var2);
               } catch (Throwable var5) {
                  if (var1 != null) {
                     try {
                        var1.close();
                     } catch (Throwable var4) {
                        var5.addSuppressed(var4);
                     }
                  }

                  throw var5;
               }

               if (var1 != null) {
                  var1.close();
               }

               return var3;
            } catch (IOException var6) {
               throw new RuntimeException("Failed to read metrics config", var6);
            }
         }
      }

      private static void save(Path var0, boolean var1, String var2, UUID var3, boolean var4, boolean var5, boolean var6, boolean var7) throws IOException {
         Files.createDirectories(var0.getParent());
         OutputStream var8 = Files.newOutputStream(var0);

         try {
            OutputStreamWriter var9 = new OutputStreamWriter(var8, StandardCharsets.UTF_8);

            try {
               Properties var10 = new Properties();
               var10.setProperty("serverId", var3.toString());
               if (!var1) {
                  var10.setProperty("enabled", Boolean.toString(var4));
               }

               var10.setProperty("submitErrors", Boolean.toString(var5));
               var10.setProperty("submitAdditionalMetrics", Boolean.toString(var6));
               var10.setProperty("debug", Boolean.toString(var7));
               var10.store(var9, var2);
            } catch (Throwable var14) {
               try {
                  var9.close();
               } catch (Throwable var13) {
                  var14.addSuppressed(var13);
               }

               throw var14;
            }

            var9.close();
         } catch (Throwable var15) {
            if (var8 != null) {
               try {
                  var8.close();
               } catch (Throwable var12) {
                  var15.addSuppressed(var12);
               }
            }

            throw var15;
         }

         if (var8 != null) {
            var8.close();
         }

      }
   }
}
