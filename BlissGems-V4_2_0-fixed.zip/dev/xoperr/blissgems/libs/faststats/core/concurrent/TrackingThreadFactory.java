package dev.xoperr.blissgems.libs.faststats.core.concurrent;

import java.util.concurrent.ThreadFactory;
import org.b.a.a;
import org.b.a.e;
import org.b.a.k;

@a.d
public interface TrackingThreadFactory extends ThreadFactory {
   @e(
      a = "_ -> new",
      b = true
   )
   Thread newThread(Runnable var1);

   @e(
      a = "_, _ -> new",
      b = true
   )
   Thread newThread(@k String var1, Runnable var2);
}
