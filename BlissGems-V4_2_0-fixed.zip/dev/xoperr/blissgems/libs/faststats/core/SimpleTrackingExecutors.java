package dev.xoperr.blissgems.libs.faststats.core;

import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingExecutors;
import java.security.PrivilegedAction;
import java.security.PrivilegedExceptionAction;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

final class SimpleTrackingExecutors implements TrackingExecutors {
   private final ErrorTracker tracker;

   public SimpleTrackingExecutors(ErrorTracker var1) {
      this.tracker = var1;
   }

   public ExecutorService newFixedThreadPool(int var1) {
      return this.tracker.threadPoolExecutor().create(var1, var1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue());
   }

   public ExecutorService newWorkStealingPool(int var1) {
      return Executors.newWorkStealingPool(var1);
   }

   public ExecutorService newWorkStealingPool() {
      return Executors.newWorkStealingPool();
   }

   public ExecutorService newFixedThreadPool(int var1, ThreadFactory var2) {
      return Executors.newFixedThreadPool(var1, WrappedTrackingThreadFactory.wrap(this.tracker, var2));
   }

   public ExecutorService newSingleThreadExecutor() {
      return this.newSingleThreadExecutor(this.defaultThreadFactory());
   }

   public ExecutorService newSingleThreadExecutor(ThreadFactory var1) {
      return Executors.newSingleThreadExecutor(WrappedTrackingThreadFactory.wrap(this.tracker, var1));
   }

   public ExecutorService newCachedThreadPool() {
      return this.tracker.threadPoolExecutor().create(0, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS, new SynchronousQueue());
   }

   public ExecutorService newCachedThreadPool(ThreadFactory var1) {
      return Executors.newCachedThreadPool(WrappedTrackingThreadFactory.wrap(this.tracker, var1));
   }

   public ExecutorService newThreadPerTaskExecutor(ThreadFactory var1) {
      return Executors.newSingleThreadExecutor(WrappedTrackingThreadFactory.wrap(this.tracker, var1));
   }

   public ExecutorService newVirtualThreadPerTaskExecutor() {
      return this.newThreadPerTaskExecutor(Thread.ofVirtual().factory());
   }

   public ScheduledExecutorService newSingleThreadScheduledExecutor() {
      return Executors.newSingleThreadScheduledExecutor();
   }

   public ScheduledExecutorService newSingleThreadScheduledExecutor(ThreadFactory var1) {
      return Executors.newSingleThreadScheduledExecutor(WrappedTrackingThreadFactory.wrap(this.tracker, var1));
   }

   public ScheduledExecutorService newScheduledThreadPool(int var1) {
      return Executors.newScheduledThreadPool(var1);
   }

   public ScheduledExecutorService newScheduledThreadPool(int var1, ThreadFactory var2) {
      return Executors.newScheduledThreadPool(var1, WrappedTrackingThreadFactory.wrap(this.tracker, var2));
   }

   public ExecutorService unconfigurableExecutorService(ExecutorService var1) {
      return Executors.unconfigurableExecutorService(var1);
   }

   public ScheduledExecutorService unconfigurableScheduledExecutorService(ScheduledExecutorService var1) {
      return Executors.unconfigurableScheduledExecutorService(var1);
   }

   public ThreadFactory defaultThreadFactory() {
      return new SimpleTrackingThreadFactory(this.tracker);
   }

   public <T> Callable<T> callable(Runnable var1, T var2) {
      return Executors.callable(this.tracker.base().tracked(var1), var2);
   }

   public Callable<Object> callable(Runnable var1) {
      return Executors.callable(this.tracker.base().tracked(var1));
   }

   public Callable<Object> callable(PrivilegedAction<?> var1) {
      return Executors.callable(this.tracker.base().tracked(var1));
   }

   public Callable<Object> callable(PrivilegedExceptionAction<?> var1) {
      return Executors.callable(this.tracker.base().tracked(var1));
   }
}
