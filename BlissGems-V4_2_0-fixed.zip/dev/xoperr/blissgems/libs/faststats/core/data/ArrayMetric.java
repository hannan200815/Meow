package dev.xoperr.blissgems.libs.faststats.core.data;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;
import org.c.a.d;

final class ArrayMetric<T> extends SimpleMetric<T[]> {
   public ArrayMetric(@SourceId String var1, Callable<T @d []> var2) throws IllegalArgumentException {
      super(var1, var2);
   }

   public Optional<JsonElement> getData() throws Exception {
      return this.compute().map((var0) -> {
         JsonArray var1 = new JsonArray(var0.length);

         for(Object var5 : var0) {
            Objects.requireNonNull(var5);
            byte var7 = 0;
            //$FF: var7->value
            //0->java/lang/Boolean
            //1->java/lang/Number
            switch (((Class)var5).typeSwitch<invokedynamic>(var5, var7)) {
               case 0:
                  Boolean var8 = (Boolean)var5;
                  var1.add(var8);
                  break;
               case 1:
                  Number var9 = (Number)var5;
                  var1.add(var9);
                  break;
               default:
                  var1.add(var5.toString());
            }
         }

         return var1;
      });
   }
}
