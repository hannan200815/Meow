package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.CustomItemManager;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.BanList.Type;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class ReviveBeaconListener implements Listener {
   private final BlissGems plugin;

   public ReviveBeaconListener(BlissGems var1) {
      this.plugin = var1;
   }

   @EventHandler
   public void onPlayerInteract(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getItem();
      if (var3 != null) {
         String var4 = CustomItemManager.getIdByItem(var3);
         if (var4 != null && var4.equals("revive_beacon")) {
            if (var1.getAction().toString().contains("RIGHT_CLICK")) {
               var1.setCancelled(true);
               int var5 = this.plugin.getConfig().getInt("revive-beacon.duration", 300);
               double var6 = this.plugin.getConfig().getDouble("revive-beacon.range", (double)10.0F);
               Location var8 = var2.getLocation().clone();
               if (var3.getAmount() > 1) {
                  var3.setAmount(var3.getAmount() - 1);
               } else {
                  var2.getInventory().setItemInMainHand((ItemStack)null);
               }

               int var9 = var5 / 60;
               int var10 = var5 % 60;
               String var11 = var9 > 0 ? String.format("%dm %ds", var9, var10) : String.format("%ds", var10);
               var2.sendMessage("");
               var2.sendMessage("§e§l§m                                      ");
               var2.sendMessage("§e§l§nREVIVE BEACON RITUAL");
               var2.sendMessage("");
               var2.sendMessage("§7§oThe beacon of resurrection awakens...");
               var2.sendMessage("§7§oDuration: §f" + var11);
               var2.sendMessage("§7§oRange: §f" + (int)var6 + " blocks");
               var2.sendMessage("§e§l§m                                      ");
               var2.sendMessage("");
               this.plugin.getGemRitualManager().performReviveBeaconRitual(var2, var8);
               this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
                  this.plugin.getReviveBeaconManager().activateBeacon(var2, var8, var5, var6);
                  var2.sendMessage("");
                  var2.sendMessage("§a§l✦ Revive Beacon is now active!");
                  var2.sendMessage("§7If you die within range, you'll be revived and unbanned!");
                  var2.sendMessage("");
               }, 60L);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onPlayerDeath(PlayerDeathEvent var1) {
      Player var2 = var1.getEntity();
      if (this.plugin.getReviveBeaconManager().canRevive(var2)) {
         Location var3 = this.plugin.getReviveBeaconManager().getReviveLocation(var2);
         if (var3 != null) {
            var1.setKeepInventory(true);
            var1.setKeepLevel(true);
            var1.getDrops().clear();
            int var4 = this.plugin.getEnergyManager().getEnergy(var2);
            int var5 = this.plugin.getConfigManager().getEnergyLossOnDeath();
            int var6 = var4 - var5;
            boolean var7 = var6 <= 0 && this.plugin.getConfigManager().isBanOnZeroEnergyEnabled();
            this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
               var2.spigot().respawn();
               if (var7 || var2.isBanned()) {
                  BanList var5 = Bukkit.getBanList(Type.PROFILE);
                  if (var5.isBanned(var2.getName()) || var5.isBanned(var2.getUniqueId().toString())) {
                     var5.pardon(var2.getName());
                     var5.pardon(var2.getUniqueId().toString());
                     var2.sendMessage("§d§l✦ You have been unbanned by the Revive Beacon!");
                  }
               }

               if (var6 <= 0) {
                  int var7x = this.plugin.getConfig().getInt("revive-beacon.restore-energy", 3);
                  this.plugin.getEnergyManager().setEnergy(var2, var7x);
                  var2.sendMessage("§b§l✦ Your energy has been restored to " + var7x + "!");
               }

               var2.teleport(var3);
               double var8 = var2.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
               var2.setHealth(Math.min(var8, this.plugin.getConfig().getDouble("revive-beacon.revive-health", var8 / (double)2.0F)));
               var2.setFoodLevel(20);
               var2.setFireTicks(0);
               var2.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
               var2.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 1));
               var2.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 200, 0));
               var2.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 100, 0));
               var2.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var2.getLocation().clone().add((double)0.0F, (double)1.0F, (double)0.0F), 100, (double)1.0F, (double)2.0F, (double)1.0F, 0.2);
               var2.getWorld().playSound(var2.getLocation(), Sound.ITEM_TOTEM_USE, 1.0F, 1.0F);
               var2.getWorld().playSound(var2.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0F, 1.5F);
               var2.sendMessage("");
               var2.sendMessage("§a§l✦ §f§lYOU HAVE BEEN REVIVED!");
               var2.sendMessage("§7Your Revive Beacon has saved you from death!");
               var2.sendMessage("");
               this.plugin.getReviveBeaconManager().removeBeacon(var2);
            }, 1L);
         }
      }
   }
}
