package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.Achievement;
import dev.xoperr.blissgems.utils.CustomItemManager;
import dev.xoperr.blissgems.utils.GemType;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class UpgraderListener implements Listener {
   private final BlissGems plugin;

   public UpgraderListener(BlissGems var1) {
      this.plugin = var1;
   }

   @EventHandler
   public void onPlayerInteract(PlayerInteractEvent var1) {
      if (var1.getAction() == Action.RIGHT_CLICK_AIR || var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
         Player var2 = var1.getPlayer();
         ItemStack var3 = var1.getItem();
         if (var3 != null) {
            String var4 = CustomItemManager.getIdByItem(var3);
            if (var4 != null && var4.equals("gem_upgrader")) {
               var1.setCancelled(true);
               if (!this.plugin.getGemManager().hasActiveGem(var2)) {
                  this.plugin.getConfigManager().sendFormattedMessage(var2, "no-gem");
               } else {
                  GemType var5 = this.plugin.getGemManager().getGemType(var2);
                  int var6 = this.plugin.getGemManager().getGemTier(var2);
                  if (var6 != 1) {
                     this.plugin.getConfigManager().sendFormattedMessage(var2, "upgrade-already-tier2");
                  } else {
                     if (this.plugin.getGemManager().upgradeGem(var2, var5)) {
                        ItemStack var7 = var2.getInventory().getItemInMainHand();
                        ItemStack var8 = var2.getInventory().getItemInOffHand();
                        boolean var9 = var7 != null && "gem_upgrader".equals(CustomItemManager.getIdByItem(var7));
                        boolean var10 = var8 != null && "gem_upgrader".equals(CustomItemManager.getIdByItem(var8));
                        if (var3.getAmount() > 1) {
                           var3.setAmount(var3.getAmount() - 1);
                        } else if (var9) {
                           var2.getInventory().setItemInMainHand((ItemStack)null);
                        } else if (var10) {
                           var2.getInventory().setItemInOffHand((ItemStack)null);
                        }

                        if (this.plugin.getConfigManager().shouldPlayUpgradeEffects()) {
                           try {
                              String var11 = this.plugin.getConfigManager().getUpgradeSound();
                              Sound var12 = Sound.valueOf(var11);
                              var2.playSound(var2.getLocation(), var12, 1.0F, 1.5F);
                              String var13 = this.plugin.getConfigManager().getUpgradeParticle();
                              Particle var14 = Particle.valueOf(var13);
                              int var15 = this.plugin.getConfigManager().getUpgradeParticleCount();
                              var2.spawnParticle(var14, var2.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), var15, (double)0.5F, (double)0.5F, (double)0.5F);
                           } catch (IllegalArgumentException var16) {
                              this.plugin.getLogger().warning("Invalid particle or sound in config: " + var16.getMessage());
                           }
                        }

                        this.plugin.getConfigManager().sendFormattedMessage(var2, "upgrade-success");
                        if (this.plugin.getAchievementManager() != null) {
                           this.plugin.getAchievementManager().unlock(var2, Achievement.THE_NEXT_LEVEL);
                        }
                     } else {
                        var2.sendMessage("§cFailed to upgrade gem!");
                     }

                  }
               }
            }
         }
      }
   }
}
