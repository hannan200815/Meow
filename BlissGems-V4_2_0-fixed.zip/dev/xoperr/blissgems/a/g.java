package dev.xoperr.blissgems.a;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.utils.Achievement;
import dev.xoperr.blissgems.utils.ParticleUtils;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public class g implements GemAbilityHandler {
   private final BlissGems a;
   private static final Set<PotionEffectType> b;
   private final Map<UUID, UUID> c = new HashMap();
   private final Map<UUID, BukkitTask> d = new HashMap();
   private final Map<UUID, Map<UUID, Integer>> e = new HashMap();

   public g(BlissGems var1) {
      this.a = var1;
   }

   public void a(Player var1, int var2) {
      if (var2 >= 2 && var1.isSneaking()) {
         this.b(var1);
      } else {
         this.a(var1);
      }

   }

   public void onPrimary(Player var1, int var2) {
      this.a(var1);
   }

   public void onSecondary(Player var1, int var2) {
      this.b(var1);
   }

   public void onTertiary(Player var1, int var2) {
      this.c(var1);
   }

   public void a(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "strength-nullify";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            int var3 = this.a.getConfig().getInt("abilities.strength-nullify.range", 20);
            LivingEntity var4 = this.b(var1, var3);
            if (var4 == null) {
               var1.sendMessage("§cNo target found!");
            } else {
               if (var4 instanceof Player) {
                  Player var5 = (Player)var4;
                  if (this.a.getTrustedPlayersManager().isTrusted(var1, var5)) {
                     var1.sendMessage("§cYou cannot nullify a trusted player!");
                     return;
                  }
               }

               int var9 = 0;

               for(PotionEffect var7 : var4.getActivePotionEffects()) {
                  if (!var7.isAmbient() && b.contains(var7.getType())) {
                     var4.removePotionEffect(var7.getType());
                     ++var9;
                  }
               }

               Particle.DustOptions var10 = new Particle.DustOptions(ParticleUtils.STRENGTH_RED, 1.5F);
               var4.getWorld().spawnParticle(Particle.DUST, var4.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 40, (double)0.5F, 0.8, (double)0.5F, (double)0.0F, var10, true);
               var4.getWorld().spawnParticle(Particle.SMOKE, var4.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, 0.8, (double)0.5F, 0.05);
               var4.getWorld().spawnParticle(Particle.SWEEP_ATTACK, var4.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, (double)0.5F, (double)0.5F, (double)0.5F);
               var1.playSound(var1.getLocation(), Sound.ENTITY_WITHER_BREAK_BLOCK, 0.8F, 1.2F);
               var4.getWorld().playSound(var4.getLocation(), Sound.ENTITY_WITHER_BREAK_BLOCK, 0.8F, 1.2F);
               this.a.getAbilityManager().useAbility(var1, var2);
               String var11 = var4 instanceof Player ? ((Player)var4).getName() : "target";
               String var8 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Nullify");
               if (var8 != null) {
                  var1.sendMessage(var8 + " §7(Stripped " + var9 + " effects from " + var11 + ")");
               }

               if (var4 instanceof Player) {
                  ((Player)var4).sendMessage("§c§oYour potion effects have been nullified!");
               }

            }
         }
      }
   }

   public void b(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "strength-frailer";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            int var3 = this.a.getConfig().getInt("abilities.strength-frailer.range", 15);
            LivingEntity var4 = this.b(var1, var3);
            if (var4 == null) {
               var1.sendMessage("§cNo target found!");
            } else {
               if (var4 instanceof Player) {
                  Player var5 = (Player)var4;
                  if (this.a.getTrustedPlayersManager().isTrusted(var1, var5)) {
                     var1.sendMessage("§cYou cannot use Frailer on a trusted player!");
                     return;
                  }
               }

               int var10 = this.a.getConfig().getInt("abilities.durations.strength-frailer-weakness", 20) * 20;
               int var6 = this.a.getConfig().getInt("abilities.durations.strength-frailer-wither", 40) * 20;
               int var7 = this.a.getConfig().getInt("abilities.durations.strength-frailer-slowness", 20) * 20;
               int var8 = this.a.getConfig().getInt("abilities.strength-frailer.slowness-level", 2);
               var4.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, var10, 0, false, true));
               var4.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, var6, 0, false, true));
               var4.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, var7, Math.max(0, var8 - 1), false, true));
               Particle.DustOptions var9 = new Particle.DustOptions(ParticleUtils.STRENGTH_RED, 1.5F);
               var4.getWorld().spawnParticle(Particle.DUST, var4.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 40, (double)0.5F, 0.8, (double)0.5F, (double)0.0F, var9, true);
               var4.getWorld().spawnParticle(Particle.SMOKE, var4.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 25, (double)0.5F, 0.8, (double)0.5F, 0.05);
               var4.getWorld().spawnParticle(Particle.CRIMSON_SPORE, var4.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F);
               var1.playSound(var1.getLocation(), Sound.ENTITY_WITHER_HURT, 1.0F, 0.8F);
               var4.getWorld().playSound(var4.getLocation(), Sound.ENTITY_WITHER_HURT, 1.0F, 0.8F);
               this.a.getAbilityManager().useAbility(var1, var2);
               this.a.getConfigManager().sendFormattedMessage(var1, "ability-activated", "ability", "Frailer Power");
               if (var4 instanceof Player) {
                  ((Player)var4).sendMessage("§c§oYou have been weakened by Frailer Power!");
               }

            }
         }
      }
   }

   public void c(final Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "strength-shadow-stalker";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            if (this.c.containsKey(var1.getUniqueId())) {
               this.e(var1);
               var1.sendMessage("§c§oStopped tracking.");
            } else {
               ItemStack var3 = var1.getInventory().getItemInMainHand();
               if (var3 != null && var3.getType() != Material.AIR) {
                  final UUID var4 = null;
                  if (var3.getType() == Material.PLAYER_HEAD && var3.hasItemMeta()) {
                     SkullMeta var5 = (SkullMeta)var3.getItemMeta();
                     if (var5.getOwningPlayer() != null) {
                        var4 = var5.getOwningPlayer().getUniqueId();
                     }
                  }

                  if (var4 == null) {
                     var1.sendMessage("§c§oThis is not a valid player head!");
                  } else if (var4.equals(var1.getUniqueId())) {
                     var1.sendMessage("§c§oYou cannot track yourself!");
                  } else {
                     Player var13 = Bukkit.getPlayer(var4);
                     if (var13 != null && var13.isOnline()) {
                        if (var3.getAmount() > 1) {
                           var3.setAmount(var3.getAmount() - 1);
                        } else {
                           var1.getInventory().setItemInMainHand((ItemStack)null);
                        }

                        int var6 = this.a.getConfig().getInt("abilities.strength-shadow-stalker.duration", 60);
                        final int var7 = var6 * 20;
                        final int var8 = this.a.getConfig().getInt("abilities.strength-shadow-stalker.invisibility-max-range", 2500);
                        final UUID var9 = var1.getUniqueId();
                        this.c.put(var9, var4);
                        if (this.a.getAchievementManager() != null) {
                           Map var11 = (Map)this.e.computeIfAbsent(var9, (var0) -> new HashMap());
                           int var12 = (Integer)var11.getOrDefault(var4, 0) + 1;
                           var11.put(var4, var12);
                           if (var12 >= 17) {
                              this.a.getAchievementManager().unlock(var1, Achievement.ITS_RABBIT_SEASON);
                           }
                        }

                        var13.sendMessage("§c§l⚠ §c§oYou are being hunted...");
                        var13.playSound(var13.getLocation(), Sound.ENTITY_WARDEN_NEARBY_CLOSER, 0.7F, 1.5F);
                        Particle.DustOptions var14 = new Particle.DustOptions(ParticleUtils.STRENGTH_RED, 1.5F);
                        var1.getWorld().spawnParticle(Particle.DUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 40, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var14, true);
                        var1.playSound(var1.getLocation(), Sound.ENTITY_WARDEN_SNIFF, 1.0F, 1.2F);
                        BukkitTask var15 = (new BukkitRunnable() {
                           int a = 0;

                           public void run() {
                              Player var1x = Bukkit.getPlayer(var9);
                              Player var2 = Bukkit.getPlayer(var4);
                              if (var1x != null && var1x.isOnline() && var2 != null && var2.isOnline() && this.a < var7 && g.this.c.containsKey(var9)) {
                                 ++this.a;
                                 if (this.a % 20 == 0) {
                                    boolean var3 = var1x.getWorld().equals(var2.getWorld());
                                    if (var3) {
                                       double var4x = var1x.getLocation().distance(var2.getLocation());
                                       boolean var6 = var2.hasPotionEffect(PotionEffectType.INVISIBILITY);
                                       if (var6 && var4x > (double)var8) {
                                          TextComponent var14 = new TextComponent("§c§lTRACKING §7… §c" + var2.getName() + " §7(invisible, too far)");
                                          var1x.spigot().sendMessage(ChatMessageType.ACTION_BAR, var14);
                                       } else {
                                          String var7x = g.this.a(var1x.getLocation(), var2.getLocation());
                                          TextComponent var8x = new TextComponent("§c§lTRACKING §7" + var7x + " §c" + var2.getName() + " §7" + (int)var4x + "m");
                                          var1x.spigot().sendMessage(ChatMessageType.ACTION_BAR, var8x);

                                          for(UUID var10 : g.this.a.getTrustedPlayersManager().getTrustedPlayers(var1x)) {
                                             Player var11 = Bukkit.getPlayer(var10);
                                             if (var11 != null && var11.isOnline() && var11.getWorld().equals(var1x.getWorld()) && var11.getLocation().distance(var1x.getLocation()) < (double)50.0F) {
                                                TextComponent var12 = new TextComponent("§8[§cTRACK§8] §7" + var7x + " §c" + var2.getName() + " §7" + (int)var4x + "m");
                                                var11.spigot().sendMessage(ChatMessageType.ACTION_BAR, var12);
                                             }
                                          }
                                       }

                                       if (this.a % 40 == 0) {
                                          Particle.DustOptions var15 = new Particle.DustOptions(ParticleUtils.STRENGTH_RED, 0.6F);
                                          var1x.getWorld().spawnParticle(Particle.DUST, var1x.getLocation().add((double)0.0F, 2.2, (double)0.0F), 3, 0.15, 0.1, 0.15, (double)0.0F, var15, true);
                                       }
                                    } else {
                                       TextComponent var13 = new TextComponent("§c§lTRACKING §7… §c" + var2.getName() + " §7(different dimension)");
                                       var1x.spigot().sendMessage(ChatMessageType.ACTION_BAR, var13);
                                    }
                                 }

                              } else {
                                 g.this.e(var1x != null ? var1x : var1);
                                 this.cancel();
                              }
                           }
                        }).runTaskTimer(this.a, 0L, 1L);
                        this.d.put(var9, var15);
                        this.a.getAbilityManager().useAbility(var1, var2);
                        String var10001 = var13.getName();
                        var1.sendMessage("§c§l☠ Shadow Stalker §7Tracking §c" + var10001 + " §7for " + var6 + " seconds.");
                     } else {
                        var1.sendMessage("§c§oTarget player is not online!");
                     }
                  }
               } else {
                  var1.sendMessage("§c§oHold a player head!");
               }
            }
         }
      }
   }

   private void e(Player var1) {
      if (var1 != null) {
         UUID var2 = var1.getUniqueId();
         UUID var3 = (UUID)this.c.remove(var2);
         BukkitTask var4 = (BukkitTask)this.d.remove(var2);
         if (var4 != null) {
            var4.cancel();
         }

         if (var1.isOnline()) {
            var1.sendMessage("§c§oShadow Stalker tracking ended.");
         }

         if (var3 != null) {
            Player var5 = Bukkit.getPlayer(var3);
            if (var5 != null && var5.isOnline()) {
               var5.sendMessage("§a§oYou are no longer being hunted.");
            }
         }

      }
   }

   public boolean d(Player var1) {
      return this.c.containsKey(var1.getUniqueId());
   }

   private LivingEntity b(Player var1, int var2) {
      RayTraceResult var3 = var1.getWorld().rayTraceEntities(var1.getEyeLocation(), var1.getEyeLocation().getDirection(), (double)var2, (var1x) -> var1x instanceof LivingEntity && var1x != var1);
      return var3 != null ? (LivingEntity)var3.getHitEntity() : null;
   }

   private String a(Location var1, Location var2) {
      Vector var3 = var2.toVector().subtract(var1.toVector()).normalize();
      double var4 = Math.atan2(var3.getZ(), var3.getX());
      double var6 = Math.toRadians((double)var1.getYaw());

      double var8;
      for(var8 = var4 - var6; var8 > Math.PI; var8 -= (Math.PI * 2D)) {
      }

      while(var8 < -Math.PI) {
         var8 += (Math.PI * 2D);
      }

      if (var8 > (-Math.PI / 4D) && var8 <= (Math.PI / 4D)) {
         return "→";
      } else if (var8 > (Math.PI / 4D) && var8 <= 2.356194490192345) {
         return "↓";
      } else {
         return var8 > -2.356194490192345 && var8 <= (-Math.PI / 4D) ? "↑" : "←";
      }
   }

   public void cleanup(Player var1) {
      this.e(var1);
   }

   static {
      b = Set.of(PotionEffectType.SPEED, PotionEffectType.STRENGTH, PotionEffectType.REGENERATION, PotionEffectType.FIRE_RESISTANCE, PotionEffectType.WATER_BREATHING, PotionEffectType.INVISIBILITY, PotionEffectType.NIGHT_VISION, PotionEffectType.ABSORPTION, PotionEffectType.HEALTH_BOOST, PotionEffectType.RESISTANCE, PotionEffectType.HASTE, PotionEffectType.JUMP_BOOST, PotionEffectType.CONDUIT_POWER, PotionEffectType.DOLPHINS_GRACE, PotionEffectType.LUCK, PotionEffectType.HERO_OF_THE_VILLAGE, PotionEffectType.SLOW_FALLING, PotionEffectType.SATURATION);
   }
}
