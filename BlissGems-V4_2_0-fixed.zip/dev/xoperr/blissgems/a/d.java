package dev.xoperr.blissgems.a;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.utils.ParticleUtils;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.attribute.AttributeModifier.Operation;
import org.bukkit.block.Biome;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

public class d implements GemAbilityHandler {
   private final BlissGems a;

   public d(BlissGems var1) {
      this.a = var1;
   }

   public void a(Player var1, int var2) {
      if (var2 == 2 && var1.isSneaking()) {
         this.b(var1);
      } else {
         this.a(var1);
      }

   }

   public void onPrimary(Player var1, int var2) {
      this.a(var1);
   }

   public void onSecondary(Player var1, int var2) {
      this.b(var1);
   }

   public void onTertiary(Player var1, int var2) {
      this.c(var1);
   }

   public void onQuaternary(Player var1, int var2) {
      this.d(var1);
   }

   public void a(Player var1) {
      String var2 = "life-drainer";
      if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
         LivingEntity var3 = this.b(var1, 15);
         if (var3 == null) {
            var1.sendMessage("§cNo target found!");
         } else {
            int var4 = this.a.getConfigManager().getAbilityDuration("life-drainer");
            var3.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, var4 * 20, 1, false, true));
            Particle.DustOptions var5 = new Particle.DustOptions(ParticleUtils.LIFE_PINK, 1.5F);
            var3.getWorld().spawnParticle(Particle.DUST, var3.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var5, true);
            var3.getWorld().spawnParticle(Particle.SCULK_SOUL, var3.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, (double)0.5F, (double)0.5F, (double)0.5F);
            var1.playSound(var1.getLocation(), Sound.ENTITY_WITHER_HURT, 1.0F, 1.5F);
            this.a.getAbilityManager().useAbility(var1, var2);
            this.a.getConfigManager().sendFormattedMessage(var1, "ability-activated", "ability", "Heart Drainer");
         }
      }
   }

   public void b(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "life-circle-of-life";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            int var3 = this.a.getConfigManager().getAbilityDuration("life-circle");
            int var4 = var3 * 20;
            double var5 = this.a.getConfig().getDouble("abilities.life-circle.radius", (double)8.0F);
            double var7 = this.a.getConfig().getDouble("abilities.life-circle.max-health-increase", (double)4.0F);
            double var9 = this.a.getConfig().getDouble("abilities.life-circle.max-health-decrease", (double)4.0F);
            Location var11 = var1.getLocation().clone();
            HashSet var12 = new HashSet();
            NamespacedKey var13 = new NamespacedKey(this.a, "circle-of-life");
            int[] var14 = new int[]{0};
            BukkitTask var15 = this.a.getServer().getScheduler().runTaskTimer(this.a, () -> {
               if (var1.isOnline() && !var1.isDead() && var14[0] < var4) {
                  if (var1.getLocation().distance(var11) <= var5) {
                     this.a(var1, var13, var7, var12);
                     var1.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 40, 1, true, true));
                  } else {
                     this.a(var1, var13, var12);
                  }

                  for(Entity var14x : var11.getWorld().getNearbyEntities(var11, var5, var5, var5)) {
                     if (var14x != var1) {
                        if (!(var14x instanceof Player)) {
                           if (var14x instanceof LivingEntity) {
                              ((LivingEntity)var14x).addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 40, 0, false, true));
                           }
                        } else {
                           Player var15 = (Player)var14x;
                           boolean var16 = this.a.getTrustedPlayersManager().isTrusted(var1, var15);
                           if (var16) {
                              this.a(var15, var13, var7, var12);
                              var15.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 40, 1, true, true));
                           } else {
                              this.a(var15, var13, -var9, var12);
                              var15.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 40, 0, false, true));
                           }
                        }
                     }
                  }

                  HashSet var23 = new HashSet();

                  for(UUID var26 : new HashSet(var12)) {
                     if (!var26.equals(var1.getUniqueId())) {
                        Player var28 = this.a.getServer().getPlayer(var26);
                        if (var28 == null || !var28.isOnline() || var28.getLocation().distance(var11) > var5) {
                           if (var28 != null && var28.isOnline()) {
                              this.a(var28, var13);
                           }

                           var23.add(var26);
                        }
                     }
                  }

                  var12.removeAll(var23);
                  Particle.DustOptions var25 = new Particle.DustOptions(ParticleUtils.LIFE_PINK_ALT, 1.0F);
                  var1.getWorld().spawnParticle(Particle.DUST, var11.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)4.0F, (double)0.5F, (double)4.0F, (double)0.0F, var25, true);
                  var1.getWorld().spawnParticle(Particle.HEART, var11.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 20, (double)4.0F, (double)0.5F, (double)4.0F);
                  var1.getWorld().spawnParticle(Particle.SCULK_SOUL, var11.clone().add((double)0.0F, (double)0.5F, (double)0.0F), 30, (double)4.0F, 0.2, (double)4.0F);
                  var1.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, var11.clone().add((double)0.0F, 0.2, (double)0.0F), 15, (double)3.0F, 0.1, (double)3.0F);
                  byte var27 = 32;

                  for(int var29 = 0; var29 < var27; ++var29) {
                     double var17 = (double)var29 / (double)var27 * (double)2.0F * Math.PI;
                     double var19 = Math.cos(var17) * var5;
                     double var21 = Math.sin(var17) * var5;
                     var1.getWorld().spawnParticle(Particle.DUST, var11.clone().add(var19, 0.2, var21), 2, 0.1, 0.1, 0.1, (double)0.0F, var25, true);
                     var1.getWorld().spawnParticle(Particle.HEART, var11.clone().add(var19, (double)1.0F, var21), 1, 0.05, 0.05, 0.05, (double)0.0F);
                     var1.getWorld().spawnParticle(Particle.SCULK_SOUL, var11.clone().add(var19, 1.8, var21), 1, 0.05, 0.05, 0.05, (double)0.0F);
                  }

                  var14[0] += 20;
               }
            }, 0L, 20L);
            this.a.getServer().getScheduler().runTaskLater(this.a, () -> {
               var15.cancel();

               for(UUID var5 : var12) {
                  Player var6 = this.a.getServer().getPlayer(var5);
                  if (var6 != null && var6.isOnline()) {
                     this.a(var6, var13);
                  }
               }

               var12.clear();
            }, (long)var4);
            this.a.getAbilityManager().useAbility(var1, var2);
            this.a.getConfigManager().sendFormattedMessage(var1, "ability-activated", "ability", "Circle of Life");
         }
      }
   }

   private void a(Player var1, NamespacedKey var2, double var3, Set<UUID> var5) {
      AttributeInstance var6 = var1.getAttribute(Attribute.GENERIC_MAX_HEALTH);
      if (var6 != null) {
         boolean var7 = var6.getModifiers().stream().anyMatch((var2x) -> this.a(var2x, var2));
         if (!var7) {
            String var10003 = var2.toString();
            var6.addModifier(new AttributeModifier(UUID.nameUUIDFromBytes((var10003 + ":" + String.valueOf(var1.getUniqueId())).getBytes()), var2.toString(), var3, Operation.ADD_NUMBER));
            var5.add(var1.getUniqueId());
         }
      }
   }

   private void a(Player var1, NamespacedKey var2, Set<UUID> var3) {
      this.a(var1, var2);
      var3.remove(var1.getUniqueId());
   }

   private void a(Player var1, NamespacedKey var2) {
      AttributeInstance var3 = var1.getAttribute(Attribute.GENERIC_MAX_HEALTH);
      if (var3 != null) {
         ArrayList var4 = new ArrayList();

         for(AttributeModifier var6 : var3.getModifiers()) {
            if (this.a(var6, var2)) {
               var4.add(var6);
            }
         }

         for(AttributeModifier var8 : var4) {
            var3.removeModifier(var8);
         }

      }
   }

   private boolean a(AttributeModifier var1, NamespacedKey var2) {
      try {
         NamespacedKey var3 = var1.getKey();
         if (var3 != null && var3.equals(var2)) {
            return true;
         }
      } catch (Throwable var4) {
      }

      String var5 = var1.getName();
      return var5 != null && (var5.equals(var2.toString()) || var5.equals(var2.getKey()));
   }

   public void c(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "life-vitality-vortex";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            int var3 = this.a.getConfigManager().getAbilityDuration("life-vitality-vortex");
            int var4 = var3 * 20;
            Biome var5 = var1.getLocation().getBlock().getBiome();
            String var6 = var5.name().toUpperCase();
            PotionEffect[] var7 = this.a(var6, var4);

            for(PotionEffect var11 : var7) {
               var1.addPotionEffect(var11);
            }

            Particle.DustOptions var12 = new Particle.DustOptions(ParticleUtils.LIFE_PINK, 1.5F);
            var1.getWorld().spawnParticle(Particle.DUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 50, (double)1.0F, (double)1.0F, (double)1.0F, (double)0.0F, var12, true);
            var1.getWorld().spawnParticle(Particle.HEART, var1.getLocation().add((double)0.0F, (double)1.5F, (double)0.0F), 15, (double)0.5F, (double)0.5F, (double)0.5F);
            var1.playSound(var1.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0F, 1.5F);
            this.a.getAbilityManager().useAbility(var1, var2);
            this.a.getConfigManager().sendFormattedMessage(var1, "ability-activated", "ability", "Vitality Vortex");
         }
      }
   }

   private PotionEffect[] a(String var1, int var2) {
      if (!var1.contains("FOREST") && !var1.contains("PLAINS") && !var1.contains("MEADOW")) {
         if (!var1.contains("DESERT") && !var1.contains("BADLANDS") && !var1.contains("SAVANNA")) {
            if (!var1.contains("OCEAN") && !var1.contains("RIVER") && !var1.contains("BEACH") && !var1.contains("SWAMP")) {
               if (!var1.contains("TAIGA") && !var1.contains("SNOWY") && !var1.contains("FROZEN") && !var1.contains("ICE")) {
                  if (var1.contains("JUNGLE")) {
                     return new PotionEffect[]{new PotionEffect(PotionEffectType.SPEED, var2, 1, true, true), new PotionEffect(PotionEffectType.JUMP_BOOST, var2, 0, true, true)};
                  } else if (!var1.contains("NETHER") && !var1.contains("CRIMSON") && !var1.contains("WARPED") && !var1.contains("BASALT") && !var1.contains("SOUL_SAND")) {
                     if (var1.contains("END") && !var1.contains("ENDER")) {
                        return new PotionEffect[]{new PotionEffect(PotionEffectType.SLOW_FALLING, var2, 0, true, true), new PotionEffect(PotionEffectType.NIGHT_VISION, var2, 0, true, true)};
                     } else {
                        return !var1.contains("MOUNTAIN") && !var1.contains("STONY") && !var1.contains("CAVE") && !var1.contains("DRIPSTONE") && !var1.contains("LUSH") && !var1.contains("DEEP_DARK") ? new PotionEffect[]{new PotionEffect(PotionEffectType.REGENERATION, var2, 0, true, true), new PotionEffect(PotionEffectType.SPEED, var2, 0, true, true)} : new PotionEffect[]{new PotionEffect(PotionEffectType.HASTE, var2, 1, true, true), new PotionEffect(PotionEffectType.NIGHT_VISION, var2, 0, true, true)};
                     }
                  } else {
                     return new PotionEffect[]{new PotionEffect(PotionEffectType.FIRE_RESISTANCE, var2, 0, true, true), new PotionEffect(PotionEffectType.STRENGTH, var2, 1, true, true)};
                  }
               } else {
                  return new PotionEffect[]{new PotionEffect(PotionEffectType.RESISTANCE, var2, 0, true, true), new PotionEffect(PotionEffectType.SPEED, var2, 0, true, true)};
               }
            } else {
               return new PotionEffect[]{new PotionEffect(PotionEffectType.WATER_BREATHING, var2, 0, true, true), new PotionEffect(PotionEffectType.DOLPHINS_GRACE, var2, 0, true, true)};
            }
         } else {
            return new PotionEffect[]{new PotionEffect(PotionEffectType.FIRE_RESISTANCE, var2, 0, true, true), new PotionEffect(PotionEffectType.STRENGTH, var2, 0, true, true)};
         }
      } else {
         return new PotionEffect[]{new PotionEffect(PotionEffectType.REGENERATION, var2, 1, true, true), new PotionEffect(PotionEffectType.SATURATION, var2, 0, true, true)};
      }
   }

   public void d(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "life-heart-lock";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            int var3 = this.a.getConfig().getInt("abilities.life-heart-lock.range", 15);
            LivingEntity var4 = this.b(var1, var3);
            if (var4 == null) {
               var1.sendMessage("§cNo target found!");
            } else {
               if (var4 instanceof Player) {
                  Player var5 = (Player)var4;
                  if (this.a.getTrustedPlayersManager().isTrusted(var1, var5)) {
                     var1.sendMessage("§c§oYou cannot Heart Lock a trusted player!");
                     return;
                  }
               }

               int var18 = this.a.getConfigManager().getAbilityDuration("life-heart-lock");
               int var6 = var18 * 20;
               AttributeInstance var7 = var4.getAttribute(Attribute.GENERIC_MAX_HEALTH);
               if (var7 == null) {
                  var1.sendMessage("§cCannot Heart Lock this target!");
               } else {
                  double var8 = var4.getHealth();
                  double var10 = var7.getValue();
                  double var12 = var8 - var10;
                  NamespacedKey var14 = new NamespacedKey(this.a, "heart-lock");
                  ArrayList var15 = new ArrayList();

                  for(AttributeModifier var17 : var7.getModifiers()) {
                     if (this.a(var17, var14)) {
                        var15.add(var17);
                     }
                  }

                  for(AttributeModifier var21 : var15) {
                     var7.removeModifier(var21);
                  }

                  String var10003 = var14.toString();
                  var7.addModifier(new AttributeModifier(UUID.nameUUIDFromBytes((var10003 + ":" + String.valueOf(var4.getUniqueId())).getBytes()), var14.toString(), var12, Operation.ADD_NUMBER));
                  this.a.getServer().getScheduler().runTaskLater(this.a, () -> {
                     if (var4.isValid()) {
                        AttributeInstance var3 = var4.getAttribute(Attribute.GENERIC_MAX_HEALTH);
                        if (var3 != null) {
                           ArrayList var4x = new ArrayList();

                           for(AttributeModifier var6 : var3.getModifiers()) {
                              if (this.a(var6, var14)) {
                                 var4x.add(var6);
                              }
                           }

                           for(AttributeModifier var9 : var4x) {
                              var3.removeModifier(var9);
                           }

                           double var8 = var3.getValue();
                           if (var4.getHealth() > var8) {
                              var4.setHealth(var8);
                           }
                        }
                     }

                  }, (long)var6);
                  Particle.DustOptions var20 = new Particle.DustOptions(ParticleUtils.LIFE_PINK, 1.5F);
                  Particle.DustOptions var22 = new Particle.DustOptions(Color.fromRGB(150, 0, 100), 1.2F);
                  var4.getWorld().spawnParticle(Particle.DUST, var4.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var20, true);
                  var4.getWorld().spawnParticle(Particle.DUST, var4.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var22, true);
                  var4.getWorld().playSound(var4.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.0F, 0.5F);
                  var1.playSound(var1.getLocation(), Sound.BLOCK_GLASS_BREAK, 0.5F, 0.5F);
                  this.a.getAbilityManager().useAbility(var1, var2);
                  this.a.getConfigManager().sendFormattedMessage(var1, "ability-activated", "ability", "Heart Lock");
                  if (var4 instanceof Player) {
                     ((Player)var4).sendMessage("§d§oYour max health has been locked!");
                  }

               }
            }
         }
      }
   }

   public void cleanup(Player var1) {
      AttributeInstance var2 = var1.getAttribute(Attribute.GENERIC_MAX_HEALTH);
      if (var2 != null) {
         ArrayList var3 = new ArrayList();

         for(AttributeModifier var5 : var2.getModifiers()) {
            if (this.a(var5)) {
               var3.add(var5);
            }
         }

         for(AttributeModifier var8 : var3) {
            var2.removeModifier(var8);
         }

         double var7 = var2.getValue();
         if (var1.getHealth() > var7) {
            var1.setHealth(var7);
         }

         if (!var3.isEmpty()) {
            Logger var10000 = this.a.getLogger();
            int var10001 = var3.size();
            var10000.info("[LifeAbilities] Removed " + var10001 + " stale life-modifier(s) from " + var1.getName());
         }

      }
   }

   private boolean a(AttributeModifier var1) {
      String var2 = var1.getName();
      if (var2 != null) {
         String var3 = var2.toLowerCase();
         if (var3.contains("blissgems")) {
            return true;
         }

         if (var3.contains("circle-of-life") || var3.contains("heart-lock")) {
            return true;
         }

         if (var3.contains("circle_of_life") || var3.contains("heart_lock")) {
            return true;
         }
      }

      try {
         NamespacedKey var7 = var1.getKey();
         if (var7 != null) {
            if ("blissgems".equals(var7.getNamespace())) {
               return true;
            }

            String var4 = var7.getKey();
            if (var4 != null) {
               String var5 = var4.toLowerCase();
               if (!var5.contains("circle-of-life") && !var5.contains("heart-lock")) {
                  if (!var5.contains("circle_of_life") && !var5.contains("heart_lock")) {
                     return false;
                  }

                  return true;
               }

               return true;
            }
         }
      } catch (Throwable var6) {
      }

      return false;
   }

   private LivingEntity b(Player var1, int var2) {
      return var1.getWorld().rayTraceEntities(var1.getEyeLocation(), var1.getEyeLocation().getDirection(), (double)var2, (var1x) -> var1x instanceof LivingEntity && var1x != var1) != null ? (LivingEntity)var1.getWorld().rayTraceEntities(var1.getEyeLocation(), var1.getEyeLocation().getDirection(), (double)var2, (var1x) -> var1x instanceof LivingEntity && var1x != var1).getHitEntity() : null;
   }
}
