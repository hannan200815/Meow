package dev.xoperr.blissgems.core.listeners;

import dev.xoperr.blissgems.core.b.c;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.ItemStack;

public class ItemDropListener implements Listener {
   private final c protectionManager;

   public ItemDropListener(c var1) {
      this.protectionManager = var1;
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onItemDrop(PlayerDropItemEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getItemDrop().getItemStack();
      if (this.protectionManager.c(var3)) {
         var1.setCancelled(true);
      }

   }
}
