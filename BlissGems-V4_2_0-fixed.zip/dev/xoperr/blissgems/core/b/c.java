package dev.xoperr.blissgems.core.b;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class c {
   private final Plugin a;
   private final NamespacedKey b;
   private final NamespacedKey c;
   private final NamespacedKey d;

   public c(Plugin var1) {
      this.a = var1;
      this.b = new NamespacedKey(var1, "is_gem");
      this.c = new NamespacedKey(var1, "gem_id");
      this.d = new NamespacedKey(var1, "gem_tier");
   }

   public boolean a(ItemStack var1) {
      if (var1 != null && var1.getType() != Material.AIR) {
         if (this.c(var1)) {
            return false;
         } else {
            ItemMeta var2 = var1.hasItemMeta() ? var1.getItemMeta() : this.a.getServer().getItemFactory().getItemMeta(var1.getType());
            if (var2 == null) {
               return false;
            } else {
               PersistentDataContainer var3 = var2.getPersistentDataContainer();
               var3.set(this.b, PersistentDataType.BYTE, (byte)1);
               var1.setItemMeta(var2);
               return true;
            }
         }
      } else {
         return false;
      }
   }

   public boolean a(ItemStack var1, String var2, int var3) {
      if (var1 != null && var1.getType() != Material.AIR) {
         ItemMeta var4 = var1.hasItemMeta() ? var1.getItemMeta() : this.a.getServer().getItemFactory().getItemMeta(var1.getType());
         if (var4 == null) {
            return false;
         } else {
            PersistentDataContainer var5 = var4.getPersistentDataContainer();
            var5.set(this.b, PersistentDataType.BYTE, (byte)1);
            if (var2 != null) {
               var5.set(this.c, PersistentDataType.STRING, var2);
            }

            var5.set(this.d, PersistentDataType.INTEGER, var3);
            var1.setItemMeta(var4);
            return true;
         }
      } else {
         return false;
      }
   }

   public boolean b(ItemStack var1) {
      if (var1 != null && var1.getType() != Material.AIR) {
         if (!var1.hasItemMeta()) {
            return false;
         } else {
            ItemMeta var2 = var1.getItemMeta();
            if (var2 == null) {
               return false;
            } else {
               PersistentDataContainer var3 = var2.getPersistentDataContainer();
               if (!var3.has(this.b, PersistentDataType.BYTE)) {
                  return false;
               } else {
                  var3.remove(this.b);
                  var3.remove(this.c);
                  var3.remove(this.d);
                  var1.setItemMeta(var2);
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   public boolean c(ItemStack var1) {
      if (var1 != null && var1.getType() != Material.AIR) {
         if (!var1.hasItemMeta()) {
            return false;
         } else {
            ItemMeta var2 = var1.getItemMeta();
            if (var2 == null) {
               return false;
            } else {
               PersistentDataContainer var3 = var2.getPersistentDataContainer();
               return var3.has(this.b, PersistentDataType.BYTE) && (Byte)var3.get(this.b, PersistentDataType.BYTE) == 1;
            }
         }
      } else {
         return false;
      }
   }

   public String d(ItemStack var1) {
      if (!this.c(var1)) {
         return null;
      } else {
         ItemMeta var2 = var1.getItemMeta();
         if (var2 == null) {
            return null;
         } else {
            PersistentDataContainer var3 = var2.getPersistentDataContainer();
            return (String)var3.get(this.c, PersistentDataType.STRING);
         }
      }
   }

   public int e(ItemStack var1) {
      if (!this.c(var1)) {
         return 0;
      } else {
         ItemMeta var2 = var1.getItemMeta();
         if (var2 == null) {
            return 0;
         } else {
            PersistentDataContainer var3 = var2.getPersistentDataContainer();
            Integer var4 = (Integer)var3.get(this.d, PersistentDataType.INTEGER);
            return var4 != null ? var4 : 0;
         }
      }
   }
}
