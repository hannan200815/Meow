package dev.xoperr.blissgems.core.b;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class d {
   private final Plugin a;
   private final boolean b;
   private final boolean c;

   public d(Plugin var1) {
      this.a = var1;
      this.b = this.c();
      this.c = var1.getConfig().getBoolean("worldguard.enabled", true);
      if (this.b) {
         var1.getLogger().info("WorldGuard detected - region protection enabled");
      } else {
         var1.getLogger().info("WorldGuard not found - region protection disabled");
      }

   }

   private boolean c() {
      try {
         Class.forName("com.sk89q.worldguard.WorldGuard");
         return this.a.getServer().getPluginManager().getPlugin("WorldGuard") != null;
      } catch (ClassNotFoundException var2) {
         return false;
      }
   }

   public boolean a(Player var1) {
      return this.a(var1.getLocation());
   }

   public boolean a(Location var1) {
      if (this.b && this.c) {
         try {
            RegionManager var2 = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(var1.getWorld()));
            if (var2 == null) {
               return false;
            } else {
               ApplicableRegionSet var3 = var2.getApplicableRegions(BukkitAdapter.asBlockVector(var1));
               return this.a(var3);
            }
         } catch (Exception var4) {
            this.a.getLogger().warning("Error checking WorldGuard regions: " + var4.getMessage());
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean a(ApplicableRegionSet var1) {
      String var2 = this.a.getConfig().getString("worldguard.mode", "blacklist");
      List var3 = this.a.getConfig().getStringList("worldguard.regions");

      for(ProtectedRegion var5 : var1) {
         String var6 = var5.getId();
         if (var2.equalsIgnoreCase("whitelist")) {
            if (!var3.contains(var6)) {
               return true;
            }
         } else if (var2.equalsIgnoreCase("blacklist") && var3.contains(var6)) {
            return true;
         }
      }

      return false;
   }

   public String a() {
      return this.a.getConfig().getString("worldguard.disabled-message", "&cGem abilities are disabled in this region!");
   }

   public boolean b() {
      return this.b;
   }
}
