package dev.xoperr.blissgems.core.b;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

public class b {
   private final Plugin a;
   private final List<dev.xoperr.blissgems.core.a.b.a> b;

   public b(Plugin var1) {
      this.a = var1;
      this.b = new ArrayList();
      this.d();
   }

   public dev.xoperr.blissgems.core.a.b.a a(dev.xoperr.blissgems.core.a.b.c var1, Location var2) {
      if (var2 != null && var2.getWorld() != null) {
         ItemDisplay var3 = (ItemDisplay)var2.getWorld().spawn(var2, ItemDisplay.class, (var1x) -> {
            ItemStack var2 = var1.k();
            var1x.setItemStack(var2);
            var1x.setBillboard(var1.j());
            var1x.setBrightness(new Display.Brightness(var1.e(), var1.f()));
            var1x.setViewRange(var1.g());
            var1x.setInterpolationDuration(var1.h());
            var1x.setInterpolationDelay(var1.i());
            float var3 = var1.d();
            Transformation var4 = new Transformation(new Vector3f(0.0F, 0.0F, 0.0F), new AxisAngle4f(0.0F, 0.0F, 0.0F, 1.0F), new Vector3f(var3, var3, var3), new AxisAngle4f(0.0F, 0.0F, 0.0F, 1.0F));
            var1x.setTransformation(var4);
         });
         dev.xoperr.blissgems.core.a.b.a var4 = new dev.xoperr.blissgems.core.a.b.a(var3, var1.a());
         this.b.add(var4);
         return var4;
      } else {
         throw new IllegalArgumentException("Location and world cannot be null");
      }
   }

   public void a() {
      for(dev.xoperr.blissgems.core.a.b.a var2 : new ArrayList(this.b)) {
         var2.d();
      }

      this.b.clear();
   }

   public int b() {
      this.e();
      return this.b.size();
   }

   public void c() {
      this.a();
   }

   private void d() {
      this.a.getServer().getScheduler().runTaskTimer(this.a, this::e, 100L, 100L);
   }

   private void e() {
      Iterator var1 = this.b.iterator();

      while(var1.hasNext()) {
         dev.xoperr.blissgems.core.a.b.a var2 = (dev.xoperr.blissgems.core.a.b.a)var1.next();
         if (!var2.b()) {
            var1.remove();
         }
      }

   }
}
