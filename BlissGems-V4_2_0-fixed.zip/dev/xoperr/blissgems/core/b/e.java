package dev.xoperr.blissgems.core.b;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class e {
   private final Plugin a;
   private final List<dev.xoperr.blissgems.core.a.e.b> b;
   private BukkitTask c;

   public e(Plugin var1) {
      this.a = var1;
      this.b = new ArrayList();
      this.b();
   }

   public void a(Player var1, String var2) {
      if (var1 != null && var2 != null) {
         var1.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(var2));
      }
   }

   public void a(Player var1) {
      if (var1 != null) {
         var1.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(""));
      }
   }

   public void a(Player var1, String var2, String var3, int var4, int var5, int var6) {
      if (var1 != null && var2 != null) {
         var1.sendTitle(var2, var3, var4, var5, var6);
      }
   }

   public void b(Player var1) {
      if (var1 != null) {
         var1.resetTitle();
      }
   }

   public void a(dev.xoperr.blissgems.core.a.e.b var1) {
      if (var1 != null) {
         this.b.add(var1);
         this.b.sort(Comparator.comparingInt(dev.xoperr.blissgems.core.a.e.b::a).reversed());
      }
   }

   public void b(dev.xoperr.blissgems.core.a.e.b var1) {
      this.b.remove(var1);
   }

   private void b() {
      this.c = this.a.getServer().getScheduler().runTaskTimer(this.a, this::c, 0L, 5L);
   }

   private void c() {
      for(Player var2 : this.a.getServer().getOnlinePlayers()) {
         this.c(var2);
      }

   }

   private void c(Player var1) {
      ItemStack var2 = var1.getInventory().getItemInMainHand();
      ItemStack var3 = var1.getInventory().getItemInOffHand();

      for(dev.xoperr.blissgems.core.a.e.b var5 : this.b) {
         if (var5.b(var1, var2, var3)) {
            String var6 = var5.a(var1, var2, var3);
            if (var6 != null) {
               this.a(var1, var6);
               return;
            }
         }
      }

   }

   public void a() {
      if (this.c != null) {
         this.c.cancel();
      }

      this.b.clear();
   }
}
