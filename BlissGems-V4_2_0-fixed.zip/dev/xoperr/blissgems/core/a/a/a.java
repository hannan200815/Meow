package dev.xoperr.blissgems.core.a.a;

import org.bukkit.entity.Player;

public class a {
   private static dev.xoperr.blissgems.core.b.a a;

   public static void a(dev.xoperr.blissgems.core.b.a var0) {
      a = var0;
   }

   public static void a(b var0) {
      b();
      a.a(var0);
   }

   public static void a(String var0) {
      b();
      a.a(var0);
   }

   public static b b(String var0) {
      b();
      return a.b(var0);
   }

   public static boolean c(String var0) {
      b();
      return a.c(var0);
   }

   public static void a(Player var0) {
      b();
      a.a(var0);
   }

   public static void b(Player var0) {
      b();
      a.b(var0);
   }

   public static void a(boolean var0) {
      b();
      a.a(var0);
   }

   public static boolean a() {
      b();
      return a.a();
   }

   private static void b() {
      if (a == null) {
         throw new IllegalStateException("AutoEnchantAPI has not been initialized! Ensure XoperrCore is loaded.");
      }
   }
}
