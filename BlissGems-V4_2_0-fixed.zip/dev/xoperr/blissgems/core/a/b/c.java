package dev.xoperr.blissgems.core.a.b;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Display;
import org.bukkit.entity.Display.Billboard;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class c {
   private final String a;
   private Material b;
   private int c;
   private float d;
   private int e;
   private int f;
   private float g;
   private int h;
   private int i;
   private Display.Billboard j;

   public c(String var1) {
      this.b = Material.PAPER;
      this.c = 0;
      this.d = 1.0F;
      this.e = 15;
      this.f = 15;
      this.g = 32.0F;
      this.h = 0;
      this.i = 0;
      this.j = Billboard.CENTER;
      this.a = var1;
   }

   public c a(Material var1) {
      this.b = var1;
      return this;
   }

   public c a(int var1) {
      this.c = var1;
      return this;
   }

   public c a(float var1) {
      this.d = var1;
      return this;
   }

   public c a(int var1, int var2) {
      this.e = Math.max(0, Math.min(15, var1));
      this.f = Math.max(0, Math.min(15, var2));
      return this;
   }

   public c b(float var1) {
      this.g = var1;
      return this;
   }

   public c b(int var1) {
      this.h = var1;
      return this;
   }

   public c c(int var1) {
      this.i = var1;
      return this;
   }

   public c a(Display.Billboard var1) {
      this.j = var1;
      return this;
   }

   public a a(Location var1) {
      return dev.xoperr.blissgems.core.a.b.b.a(this, var1);
   }

   public String a() {
      return this.a;
   }

   public Material b() {
      return this.b;
   }

   public int c() {
      return this.c;
   }

   public float d() {
      return this.d;
   }

   public int e() {
      return this.e;
   }

   public int f() {
      return this.f;
   }

   public float g() {
      return this.g;
   }

   public int h() {
      return this.h;
   }

   public int i() {
      return this.i;
   }

   public Display.Billboard j() {
      return this.j;
   }

   public ItemStack k() {
      ItemStack var1 = new ItemStack(this.b);
      if (this.c > 0) {
         ItemMeta var2 = var1.getItemMeta();
         if (var2 != null) {
            var2.setCustomModelData(this.c);
            var1.setItemMeta(var2);
         }
      }

      return var1;
   }
}
