package dev.xoperr.blissgems.core.a.b;

import org.bukkit.Location;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.util.Transformation;
import org.joml.Vector3f;

public class a {
   private final ItemDisplay a;
   private final String b;
   private boolean c;

   public a(ItemDisplay var1, String var2) {
      this.a = var1;
      this.b = var2;
      this.c = true;
   }

   public String a() {
      return this.b;
   }

   public boolean b() {
      return this.c && this.a != null && this.a.isValid();
   }

   public Location c() {
      return this.a != null ? this.a.getLocation() : null;
   }

   public void a(Location var1) {
      if (this.a != null && this.c) {
         this.a.teleport(var1);
      }

   }

   public void a(float var1) {
      if (this.a != null && this.c) {
         Transformation var2 = this.a.getTransformation();
         this.a.setTransformation(new Transformation(var2.getTranslation(), var2.getLeftRotation(), new Vector3f(var1, var1, var1), var2.getRightRotation()));
      }

   }

   public void a(int var1, int var2) {
      if (this.a != null && this.c) {
         this.a.setBrightness(new Display.Brightness(var1, var2));
      }

   }

   public void b(float var1) {
      if (this.a != null && this.c) {
         this.a.setViewRange(var1);
      }

   }

   public void a(int var1) {
      if (this.a != null && this.c) {
         this.a.setInterpolationDuration(var1);
      }

   }

   public void b(int var1) {
      if (this.a != null && this.c) {
         this.a.setInterpolationDelay(var1);
      }

   }

   public void d() {
      if (this.a != null && this.c) {
         this.a.remove();
         this.c = false;
      }

   }

   public ItemDisplay e() {
      return this.a;
   }
}
