package dev.xoperr.blissgems.core.a.b;

import org.bukkit.Location;

public class b {
   private static dev.xoperr.blissgems.core.b.b a;

   public static void a(dev.xoperr.blissgems.core.b.b var0) {
      a = var0;
   }

   public static c a(String var0) {
      c();
      return new c(var0);
   }

   static a a(c var0, Location var1) {
      c();
      return a.a(var0, var1);
   }

   public static void a() {
      c();
      a.a();
   }

   public static int b() {
      c();
      return a.b();
   }

   private static void c() {
      if (a == null) {
         throw new IllegalStateException("ParticleAPI has not been initialized! Ensure XoperrCore is loaded.");
      }
   }
}
