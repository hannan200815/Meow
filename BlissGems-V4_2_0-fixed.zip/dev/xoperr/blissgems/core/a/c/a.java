package dev.xoperr.blissgems.core.a.c;

import dev.xoperr.blissgems.core.b.c;
import org.bukkit.inventory.ItemStack;

public class a {
   private static c a;

   public static void a(c var0) {
      a = var0;
   }

   public static boolean a(ItemStack var0) {
      a();
      return a.a(var0);
   }

   public static boolean b(ItemStack var0) {
      a();
      return a.b(var0);
   }

   public static boolean c(ItemStack var0) {
      a();
      return a.c(var0);
   }

   public static boolean a(ItemStack var0, String var1, int var2) {
      a();
      return a.a(var0, var1, var2);
   }

   public static String d(ItemStack var0) {
      a();
      return a.d(var0);
   }

   public static int e(ItemStack var0) {
      a();
      return a.e(var0);
   }

   private static void a() {
      if (a == null) {
         throw new IllegalStateException("GemProtectionAPI has not been initialized! Ensure XoperrCore is loaded.");
      }
   }
}
