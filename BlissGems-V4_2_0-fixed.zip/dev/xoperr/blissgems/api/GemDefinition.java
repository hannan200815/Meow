package dev.xoperr.blissgems.api;

import java.util.List;
import org.bukkit.Material;

public class GemDefinition {
   private final String id;
   private final String displayName;
   private final String description;
   private final String color;
   private final String pluginName;
   private final int maxTier;
   private final Material material;
   private final int t1CustomModelData;
   private final int t2CustomModelData;
   private final List<String> t1Lore;
   private final List<String> t2Lore;
   private final String t1DisplayName;
   private final String t2DisplayName;

   private GemDefinition(Builder var1) {
      this.id = var1.id;
      this.displayName = var1.displayName;
      this.description = var1.description;
      this.color = var1.color;
      this.pluginName = var1.pluginName;
      this.maxTier = var1.maxTier;
      this.material = var1.material;
      this.t1CustomModelData = var1.t1CustomModelData;
      this.t2CustomModelData = var1.t2CustomModelData;
      this.t1Lore = var1.t1Lore;
      this.t2Lore = var1.t2Lore;
      this.t1DisplayName = var1.t1DisplayName;
      this.t2DisplayName = var1.t2DisplayName;
   }

   public String getId() {
      return this.id;
   }

   public String getDisplayName() {
      return this.displayName;
   }

   public String getDescription() {
      return this.description;
   }

   public String getColor() {
      return this.color;
   }

   public String getPluginName() {
      return this.pluginName;
   }

   public int getMaxTier() {
      return this.maxTier;
   }

   public Material getMaterial() {
      return this.material;
   }

   public int getT1CustomModelData() {
      return this.t1CustomModelData;
   }

   public int getT2CustomModelData() {
      return this.t2CustomModelData;
   }

   public List<String> getT1Lore() {
      return this.t1Lore;
   }

   public List<String> getT2Lore() {
      return this.t2Lore;
   }

   public String getT1DisplayName() {
      return this.t1DisplayName;
   }

   public String getT2DisplayName() {
      return this.t2DisplayName;
   }

   public String buildItemId(int var1) {
      return this.id + "_gem_t" + var1;
   }

   public static class Builder {
      private final String id;
      private String displayName;
      private String description = "";
      private String color = "§7";
      private String pluginName = "BlissGems";
      private int maxTier = 2;
      private Material material;
      private int t1CustomModelData;
      private int t2CustomModelData;
      private List<String> t1Lore;
      private List<String> t2Lore;
      private String t1DisplayName;
      private String t2DisplayName;

      public Builder(String var1) {
         this.material = Material.ECHO_SHARD;
         this.t1CustomModelData = -1;
         this.t2CustomModelData = -1;
         this.id = var1;
         String var10001 = var1.substring(0, 1).toUpperCase();
         this.displayName = var10001 + var1.substring(1);
      }

      public Builder displayName(String var1) {
         this.displayName = var1;
         return this;
      }

      public Builder description(String var1) {
         this.description = var1;
         return this;
      }

      public Builder color(String var1) {
         this.color = var1;
         return this;
      }

      public Builder plugin(String var1) {
         this.pluginName = var1;
         return this;
      }

      public Builder maxTier(int var1) {
         this.maxTier = var1;
         return this;
      }

      public Builder material(Material var1) {
         this.material = var1;
         return this;
      }

      public Builder t1CustomModelData(int var1) {
         this.t1CustomModelData = var1;
         return this;
      }

      public Builder t2CustomModelData(int var1) {
         this.t2CustomModelData = var1;
         return this;
      }

      public Builder t1Lore(List<String> var1) {
         this.t1Lore = var1;
         return this;
      }

      public Builder t2Lore(List<String> var1) {
         this.t2Lore = var1;
         return this;
      }

      public Builder t1DisplayName(String var1) {
         this.t1DisplayName = var1;
         return this;
      }

      public Builder t2DisplayName(String var1) {
         this.t2DisplayName = var1;
         return this;
      }

      public GemDefinition build() {
         if (this.id != null && !this.id.isEmpty()) {
            return new GemDefinition(this);
         } else {
            throw new IllegalArgumentException("Gem ID must not be empty");
         }
      }
   }
}
