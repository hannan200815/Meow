package dev.xoperr.blissgems.api;

import org.bukkit.entity.Player;

public interface GemAbilityHandler {
   void onPrimary(Player var1, int var2);

   default void onSecondary(Player var1, int var2) {
   }

   default void onTertiary(Player var1, int var2) {
   }

   default void onQuaternary(Player var1, int var2) {
   }

   default void cleanup(Player var1) {
   }
}
