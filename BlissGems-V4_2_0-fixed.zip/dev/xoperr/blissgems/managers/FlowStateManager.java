package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class FlowStateManager {
   private final BlissGems a;
   private final Map<UUID, a> b = new HashMap();
   private static final int c = 3000;
   private static final int d = 5;

   public FlowStateManager(BlissGems var1) {
      this.a = var1;
   }

   public void registerAction(Player var1, ActionType var2) {
      UUID var3 = var1.getUniqueId();
      a var4 = (a)this.b.computeIfAbsent(var3, (var0) -> new a());
      long var5 = System.currentTimeMillis();
      if (var4.a() == var2) {
         long var7 = var5 - var4.b();
         if (var7 <= 3000L) {
            int var9 = Math.min(var4.c() + 1, 5);
            var4.a(var9);
            this.a(var1, var9);
            if (var9 > var4.c()) {
               var1.spawnParticle(Particle.ELECTRIC_SPARK, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10 + var9 * 2, 0.3, (double)0.5F, 0.3, 0.05);
               if (var9 == 5) {
                  var1.playSound(var1.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1.0F, 2.0F);
                  var1.sendMessage("§b§l⚡ MAX FLOW STATE!");
               } else if (var9 % 2 == 0) {
                  var1.playSound(var1.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.5F, 1.5F + (float)var9 * 0.2F);
               }
            }
         } else {
            var4.a(1);
            this.a(var1, 1);
         }
      } else {
         var4.a(1);
         this.a(var1, 1);
      }

      var4.a(var2);
      var4.a(var5);
   }

   private void a(Player var1, int var2) {
      if (var2 > 0) {
         int var3 = Math.min((var2 + 1) / 2, 2);
         var1.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, var3, false, false));
         if (var2 >= 3) {
            int var4 = var2 >= 4 ? 1 : 0;
            var1.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 100, var4, false, false));
         }

         if (var2 >= 3) {
            var1.spawnParticle(Particle.ELECTRIC_SPARK, var1.getLocation().add((double)0.0F, (double)0.5F, (double)0.0F), 5, 0.3, 0.3, 0.3, 0.01);
         }

      }
   }

   public int getFlowLevel(Player var1) {
      a var2 = (a)this.b.get(var1.getUniqueId());
      if (var2 == null) {
         return 0;
      } else {
         long var3 = System.currentTimeMillis() - var2.b();
         return var3 > 3000L ? 0 : var2.c();
      }
   }

   public void resetFlowState(Player var1) {
      this.b.remove(var1.getUniqueId());
   }

   public void clearFlowState(UUID var1) {
      this.b.remove(var1);
   }

   public static enum ActionType {
      BLOCK_BREAK,
      ARROW_SHOOT,
      ATTACK,
      SPRINT,
      JUMP;

      // $FF: synthetic method
      private static ActionType[] a() {
         return new ActionType[]{BLOCK_BREAK, ARROW_SHOOT, ATTACK, SPRINT, JUMP};
      }
   }

   private static class a {
      private ActionType a = null;
      private long b = 0L;
      private int c = 0;

      public a() {
      }

      public ActionType a() {
         return this.a;
      }

      public void a(ActionType var1) {
         this.a = var1;
      }

      public long b() {
         return this.b;
      }

      public void a(long var1) {
         this.b = var1;
      }

      public int c() {
         return this.c;
      }

      public void a(int var1) {
         this.c = var1;
      }
   }
}
