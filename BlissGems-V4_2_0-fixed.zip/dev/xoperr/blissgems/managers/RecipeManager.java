package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.CustomItemManager;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;

public class RecipeManager {
   private final BlissGems a;
   private final List<NamespacedKey> b = new ArrayList();

   public RecipeManager(BlissGems var1) {
      this.a = var1;
   }

   public void registerRecipes() {
      if (!this.a.getConfig().getBoolean("crafting.enabled", true)) {
         this.a.getLogger().info("Crafting recipes are disabled in config");
      } else {
         this.a();
         this.b();
         this.c();
         this.d();
         this.e();
         this.a.getLogger().info("Registered " + this.b.size() + " custom crafting recipes");
      }
   }

   private void a() {
      ItemStack var1 = CustomItemManager.getItemById("gem_fragment");
      if (var1 == null) {
         this.a.getLogger().warning("Could not create gem_fragment item - recipe not registered");
      } else {
         var1.setAmount(4);
         NamespacedKey var2 = new NamespacedKey(this.a, "gem_fragment");
         ShapedRecipe var3 = new ShapedRecipe(var2, var1);
         var3.shape(new String[]{"DAD", "EIE", "DAD"});
         var3.setIngredient('D', Material.DIAMOND);
         var3.setIngredient('A', Material.AMETHYST_CLUSTER);
         var3.setIngredient('E', Material.EMERALD);
         var3.setIngredient('I', Material.IRON_BLOCK);
         this.a.getServer().addRecipe(var3);
         this.b.add(var2);
      }
   }

   private void b() {
      ItemStack var1 = CustomItemManager.getItemById("gem_trader");
      if (var1 == null) {
         this.a.getLogger().warning("Could not create gem_trader item - recipe not registered");
      } else {
         NamespacedKey var2 = new NamespacedKey(this.a, "gem_trader");
         ShapedRecipe var3 = new ShapedRecipe(var2, var1);
         var3.shape(new String[]{"BDB", "DSD", "BDB"});
         var3.setIngredient('B', Material.DIAMOND_BLOCK);
         var3.setIngredient('D', Material.DRAGON_BREATH);
         var3.setIngredient('S', Material.SCULK_CATALYST);
         this.a.getServer().addRecipe(var3);
         this.b.add(var2);
      }
   }

   private void c() {
      ItemStack var1 = CustomItemManager.getItemById("repair_kit");
      if (var1 == null) {
         this.a.getLogger().warning("Could not create repair_kit item - recipe not registered");
      } else {
         NamespacedKey var2 = new NamespacedKey(this.a, "repair_kit");
         ShapedRecipe var3 = new ShapedRecipe(var2, var1);
         var3.shape(new String[]{"FAF", "NTN", "FAF"});
         var3.setIngredient('F', Material.PRISMARINE_SHARD);
         var3.setIngredient('A', Material.ANVIL);
         var3.setIngredient('N', Material.NETHERITE_INGOT);
         var3.setIngredient('T', Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE);
         this.a.getServer().addRecipe(var3);
         this.b.add(var2);
      }
   }

   private void d() {
      ItemStack var1 = CustomItemManager.getItemById("revive_beacon");
      if (var1 == null) {
         this.a.getLogger().warning("Could not create revive_beacon item - recipe not registered");
      } else {
         NamespacedKey var2 = new NamespacedKey(this.a, "revive_beacon");
         ShapedRecipe var3 = new ShapedRecipe(var2, var1);
         var3.shape(new String[]{"ETE", "TBT", "ETE"});
         var3.setIngredient('E', Material.ECHO_SHARD);
         var3.setIngredient('T', Material.TOTEM_OF_UNDYING);
         var3.setIngredient('B', Material.BEACON);
         this.a.getServer().addRecipe(var3);
         this.b.add(var2);
      }
   }

   private void e() {
      ItemStack var1 = CustomItemManager.getItemById("gem_upgrader");
      if (var1 == null) {
         this.a.getLogger().warning("Could not create gem_upgrader - recipe not registered");
      } else {
         NamespacedKey var2 = new NamespacedKey(this.a, "gem_upgrader");
         ShapedRecipe var3 = new ShapedRecipe(var2, var1);
         var3.shape(new String[]{"BBB", "BSB", "BBB"});
         var3.setIngredient('B', Material.DIAMOND_BLOCK);
         var3.setIngredient('S', Material.NETHER_STAR);
         this.a.getServer().addRecipe(var3);
         this.b.add(var2);
      }
   }

   public void unregisterRecipes() {
      for(NamespacedKey var2 : this.b) {
         this.a.getServer().removeRecipe(var2);
      }

      this.b.clear();
   }
}
