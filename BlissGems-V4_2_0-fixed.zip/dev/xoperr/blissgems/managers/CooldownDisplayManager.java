package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.CooldownEntry;
import dev.xoperr.blissgems.api.GemDefinition;
import dev.xoperr.blissgems.utils.CustomItemManager;
import dev.xoperr.blissgems.utils.GemType;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

public class CooldownDisplayManager {
   private final BlissGems a;
   private BukkitTask b;
   private static final Map<GemType, List<String[]>> c = new HashMap();

   public CooldownDisplayManager(BlissGems var1) {
      this.a = var1;
      this.a();
   }

   private void a() {
      this.b = this.a.getServer().getScheduler().runTaskTimer(this.a, () -> {
         for(Player var2 : this.a.getServer().getOnlinePlayers()) {
            if (this.a.getGemManager().hasActiveGem(var2) && this.a(var2) && !this.a.getFireAbilities().a(var2) && !this.a.getFluxAbilities().a(var2) && !this.a.getStrengthAbilities().d(var2)) {
               int var3 = this.a.getEnergyManager().getEnergy(var2);
               String var4 = this.c(var2);
               if (var3 == 0) {
                  String var5 = "§c§lBROKEN §8| ";
                  if (!var4.isEmpty()) {
                     var4 = var5 + var4;
                  } else {
                     var4 = "§c§lBROKEN";
                  }
               }

               if (!var4.isEmpty()) {
                  var2.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(var4));
               }
            }
         }

      }, 0L, 10L);
   }

   private boolean a(Player var1) {
      return this.b(var1) != null;
   }

   private a b(Player var1) {
      GemRegistryImpl var2 = this.a.getGemRegistry();
      ItemStack var3 = var1.getInventory().getItemInMainHand();
      if (var3 != null) {
         String var4 = CustomItemManager.getIdByItem(var3);
         if (var4 != null) {
            if (GemType.isGem(var4)) {
               GemType var11 = GemType.fromOraxenId(var4);
               int var14 = GemType.getTierFromOraxenId(var4);
               String var16 = var11 != null ? var11.getId() : null;
               return new a(var11, var16, var14, "✋");
            }

            if (var2 != null && var2.isRegisteredGem(var4)) {
               String var10 = var2.gemIdFromItemId(var4);
               int var13 = var2.tierFromItemId(var4);
               return new a((GemType)null, var10, var13, "✋");
            }
         }
      }

      ItemStack var9 = var1.getInventory().getItemInOffHand();
      if (var9 != null) {
         String var5 = CustomItemManager.getIdByItem(var9);
         if (var5 != null) {
            if (GemType.isGem(var5)) {
               GemType var12 = GemType.fromOraxenId(var5);
               int var15 = GemType.getTierFromOraxenId(var5);
               String var8 = var12 != null ? var12.getId() : null;
               return new a(var12, var8, var15, "\ud83d\udee1");
            }

            if (var2 != null && var2.isRegisteredGem(var5)) {
               String var6 = var2.gemIdFromItemId(var5);
               int var7 = var2.tierFromItemId(var5);
               return new a((GemType)null, var6, var7, "\ud83d\udee1");
            }
         }
      }

      return null;
   }

   private String c(Player var1) {
      StringBuilder var2 = new StringBuilder();
      AbilityManager var3 = this.a.getAbilityManager();
      a var4 = this.b(var1);
      if (var4 == null) {
         return "";
      } else {
         GemType var5 = var4.a;
         int var6 = var4.c;
         if (var5 == null) {
            return this.a(var1, var4);
         } else {
            String var7 = var5.getColor();
            List var8 = (List)c.get(var5);
            if (var8 == null) {
               return "";
            } else if (var5 == GemType.ASTRA) {
               String var27 = this.a(var5, 0);
               int var34 = var3.getRemainingCooldown(var1, ((String[])var8.get(0))[0]);
               var2.append(var27).append(" ");
               if (var34 > 0) {
                  var2.append("§c").append(var34).append("s");
               } else {
                  var2.append("§aReady");
               }

               if (var6 == 2) {
                  String var41 = this.a(var5, 1);
                  int var48 = var3.getRemainingCooldown(var1, ((String[])var8.get(1))[0]);
                  var2.append(" §5(✦) ");
                  var2.append(var41).append(" ");
                  if (var48 > 0) {
                     var2.append("§c").append(var48).append("s");
                  } else {
                     var2.append("§aReady");
                  }
               }

               return var2.toString();
            } else if (var5 == GemType.FLUX) {
               String var26 = this.a(var5, 0);
               int var33 = var3.getRemainingCooldown(var1, ((String[])var8.get(0))[0]);
               var2.append(var26).append(" ");
               if (var33 > 0) {
                  var2.append("§c").append(var33).append("s");
               } else {
                  var2.append("§aReady");
               }

               if (var6 == 2) {
                  String var40 = this.a(var5, 1);
                  int var47 = var3.getRemainingCooldown(var1, ((String[])var8.get(1))[0]);
                  int var54 = var3.getRemainingCooldown(var1, ((String[])var8.get(2))[0]);
                  int var57 = var3.getRemainingCooldown(var1, ((String[])var8.get(3))[0]);
                  if (var54 > 0 && var57 > 0) {
                     var2.append(" §b(").append(var54).append("s§7|").append(var57).append("s) ");
                  } else if (var54 > 0) {
                     var2.append(" §b(").append(var54).append("s) ");
                  } else if (var57 > 0) {
                     var2.append(" §b(").append(var57).append("s) ");
                  } else {
                     var2.append(" §b(⚡) ");
                  }

                  var2.append(var40).append(" ");
                  if (var47 > 0) {
                     var2.append("§c").append(var47).append("s");
                  } else {
                     var2.append("§aReady");
                  }
               }

               return var2.toString();
            } else if (var5 == GemType.LIFE) {
               String var25 = this.a(var5, 0);
               int var32 = var3.getRemainingCooldown(var1, ((String[])var8.get(0))[0]);
               var2.append(var25).append(" ");
               if (var32 > 0) {
                  var2.append("§c").append(var32).append("s");
               } else {
                  var2.append("§aReady");
               }

               if (var6 == 2) {
                  String var39 = this.a(var5, 1);
                  int var46 = var3.getRemainingCooldown(var1, ((String[])var8.get(1))[0]);
                  int var53 = var3.getRemainingCooldown(var1, ((String[])var8.get(2))[0]);
                  int var56 = var3.getRemainingCooldown(var1, ((String[])var8.get(3))[0]);
                  if (var53 > 0 && var56 > 0) {
                     var2.append(" §d(").append(var53).append("s§7|").append(var56).append("s) ");
                  } else if (var53 > 0) {
                     var2.append(" §d(").append(var53).append("s) ");
                  } else if (var56 > 0) {
                     var2.append(" §d(").append(var56).append("s) ");
                  } else {
                     var2.append(" §d(❤) ");
                  }

                  var2.append(var39).append(" ");
                  if (var46 > 0) {
                     var2.append("§c").append(var46).append("s");
                  } else {
                     var2.append("§aReady");
                  }
               }

               return var2.toString();
            } else if (var5 == GemType.PUFF) {
               String var24 = this.a(var5, 0);
               int var31 = var3.getRemainingCooldown(var1, ((String[])var8.get(0))[0]);
               var2.append(var24).append(" ");
               if (var31 > 0) {
                  var2.append("§c").append(var31).append("s");
               } else {
                  var2.append("§aReady");
               }

               if (var6 == 2) {
                  String var38 = this.a(var5, 1);
                  int var45 = var3.getRemainingCooldown(var1, ((String[])var8.get(1))[0]);
                  int var52 = var3.getRemainingCooldown(var1, ((String[])var8.get(2))[0]);
                  if (var52 > 0) {
                     var2.append(" §f(").append(var52).append("s) ");
                  } else {
                     var2.append(" §f(✨) ");
                  }

                  var2.append(var38).append(" ");
                  if (var45 > 0) {
                     var2.append("§c").append(var45).append("s");
                  } else {
                     var2.append("§aReady");
                  }
               }

               return var2.toString();
            } else if (var5 == GemType.SPEED) {
               String var23 = this.a(var5, 0);
               int var30 = var3.getRemainingCooldown(var1, ((String[])var8.get(0))[0]);
               var2.append(var23).append(" ");
               if (var30 > 0) {
                  var2.append("§c").append(var30).append("s");
               } else {
                  var2.append("§aReady");
               }

               if (var6 == 2 && var8.size() > 1) {
                  String var37 = this.a(var5, 1);
                  int var44 = var3.getRemainingCooldown(var1, ((String[])var8.get(1))[0]);
                  int var51 = var3.getRemainingCooldown(var1, ((String[])var8.get(2))[0]);
                  if (var51 > 0) {
                     var2.append(" §a(").append(var51).append("s) ");
                  } else {
                     var2.append(" §a(⚡) ");
                  }

                  var2.append(var37).append(" ");
                  if (var44 > 0) {
                     var2.append("§c").append(var44).append("s");
                  } else {
                     var2.append("§aReady");
                  }
               }

               return var2.toString();
            } else if (var5 == GemType.WEALTH) {
               String var22 = this.a(var5, 0);
               int var29 = var3.getRemainingCooldown(var1, ((String[])var8.get(0))[0]);
               var2.append(var22).append(" ");
               if (var29 > 0) {
                  var2.append("§c").append(var29).append("s");
               } else {
                  var2.append("§aReady");
               }

               if (var6 == 2 && var8.size() > 1) {
                  String var36 = this.a(var5, 1);
                  int var43 = var3.getRemainingCooldown(var1, ((String[])var8.get(1))[0]);
                  int var50 = var8.size() > 2 ? var3.getRemainingCooldown(var1, ((String[])var8.get(2))[0]) : 0;
                  int var55 = var8.size() > 3 ? var3.getRemainingCooldown(var1, ((String[])var8.get(3))[0]) : 0;
                  if (var50 > 0 && var55 > 0) {
                     var2.append(" §e(").append(var50).append("s§7|").append(var55).append("s) ");
                  } else if (var50 > 0) {
                     var2.append(" §e(").append(var50).append("s) ");
                  } else if (var55 > 0) {
                     var2.append(" §e(").append(var55).append("s) ");
                  } else {
                     var2.append(" §e(\ud83d\udcb0) ");
                  }

                  var2.append(var36).append(" ");
                  if (var43 > 0) {
                     var2.append("§c").append(var43).append("s");
                  } else {
                     var2.append("§aReady");
                  }
               }

               return var2.toString();
            } else if (var5 == GemType.STRENGTH) {
               String var21 = this.a(var5, 0);
               int var28 = var3.getRemainingCooldown(var1, ((String[])var8.get(0))[0]);
               var2.append(var21).append(" ");
               if (var28 > 0) {
                  var2.append("§c").append(var28).append("s");
               } else {
                  var2.append("§aReady");
               }

               if (var6 == 2 && var8.size() > 1) {
                  String var35 = this.a(var5, 1);
                  int var42 = var3.getRemainingCooldown(var1, ((String[])var8.get(1))[0]);
                  int var49 = var8.size() > 2 ? var3.getRemainingCooldown(var1, ((String[])var8.get(2))[0]) : 0;
                  if (var49 > 0) {
                     var2.append(" §6(").append(var49).append("s) ");
                  } else {
                     var2.append(" §6(\ud83d\udcaa) ");
                  }

                  var2.append(var35).append(" ");
                  if (var42 > 0) {
                     var2.append("§c").append(var42).append("s");
                  } else {
                     var2.append("§aReady");
                  }
               }

               return var2.toString();
            } else {
               String[] var9 = (String[])var8.get(0);
               String var10 = var9[0];
               String var11 = this.a(var5, 0);
               int var12 = var3.getRemainingCooldown(var1, var10);
               var2.append(var11).append(" ");
               if (var12 > 0) {
                  var2.append("§c").append(var12).append("s");
               } else {
                  var2.append("§aReady");
               }

               if (var6 == 2 && var8.size() > 1) {
                  String[] var13 = (String[])var8.get(1);
                  String var14 = var13[0];
                  String var15 = this.a(var5, 1);
                  int var16 = var3.getRemainingCooldown(var1, var14);
                  var2.append(" ").append(var7).append("| ").append(var15).append(" ");
                  if (var16 > 0) {
                     var2.append("§c").append(var16).append("s");
                  } else {
                     var2.append("§aReady");
                  }

                  for(int var17 = 2; var17 < var8.size(); ++var17) {
                     String[] var18 = (String[])var8.get(var17);
                     String var19 = var18[0];
                     int var20 = var3.getRemainingCooldown(var1, var19);
                     var2.append(" ").append(var7).append("| ").append(var7).append("✦ ");
                     if (var20 > 0) {
                        var2.append("§c").append(var20).append("s");
                     } else {
                        var2.append("§aReady");
                     }
                  }
               }

               return var2.toString();
            }
         }
      }
   }

   private String a(GemType var1) {
      String var10000;
      switch (var1) {
         case ASTRA -> var10000 = "\ue000";
         case FIRE -> var10000 = "\ue001";
         case FLUX -> var10000 = "\ue002";
         case LIFE -> var10000 = "\ue003";
         case PUFF -> var10000 = "\ue004";
         case SPEED -> var10000 = "\ue005";
         case STRENGTH -> var10000 = "\ue006";
         case WEALTH -> var10000 = "\ue007";
         default -> throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   private String a(GemType var1, int var2) {
      String var10000;
      switch (var1) {
         case ASTRA -> var10000 = var2 == 0 ? "\ue010" : "\ue011";
         case FIRE -> var10000 = var2 == 0 ? "\ue012" : "\ue013";
         case FLUX -> var10000 = var2 == 0 ? "\ue014" : "\ue015";
         case LIFE -> var10000 = var2 == 0 ? "\ue016" : "\ue017";
         case PUFF -> var10000 = var2 == 0 ? "\ue018" : "\ue019";
         case SPEED -> var10000 = var2 == 0 ? "\ue01a" : "\ue01b";
         case STRENGTH -> var10000 = var2 == 0 ? "\ue01c" : "\ue01d";
         case WEALTH -> var10000 = var2 == 0 ? "\ue01e" : "\ue01f";
         default -> throw new IncompatibleClassChangeError();
      }

      return var10000;
   }

   private String b(GemType var1) {
      switch (var1) {
         case ASTRA -> {
            return "✦";
         }
         case FIRE -> {
            return "\ud83d\udd25";
         }
         case FLUX -> {
            return "⚡";
         }
         case LIFE -> {
            return "❤";
         }
         case PUFF -> {
            return "\ud83d\udca8";
         }
         case SPEED -> {
            return "⚡";
         }
         case STRENGTH -> {
            return "⚔";
         }
         case WEALTH -> {
            return "\ud83d\udcb0";
         }
         default -> {
            return "◆";
         }
      }
   }

   private String c(GemType var1) {
      switch (var1) {
         case ASTRA -> {
            return "§5";
         }
         case FIRE -> {
            return "§c";
         }
         case FLUX -> {
            return "§b";
         }
         case LIFE -> {
            return "§d";
         }
         case PUFF -> {
            return "§f";
         }
         case SPEED -> {
            return "§a";
         }
         case STRENGTH -> {
            return "§6";
         }
         case WEALTH -> {
            return "§e";
         }
         default -> {
            return "§7";
         }
      }
   }

   private String a(int var1) {
      StringBuilder var2 = new StringBuilder();
      String var3;
      String var4;
      if (var1 >= 8) {
         var3 = "§d§l";
         var4 = "●";
      } else if (var1 >= 5) {
         var3 = "§b";
         var4 = "●";
      } else if (var1 >= 3) {
         var3 = "§e";
         var4 = "●";
      } else if (var1 >= 2) {
         var3 = "§6";
         var4 = "●";
      } else if (var1 == 1) {
         var3 = "§4";
         var4 = "○";
      } else {
         var3 = "§c§l";
         var4 = "○";
      }

      var2.append(var3);

      for(int var5 = 0; var5 < 10; ++var5) {
         if (var5 < var1) {
            var2.append(var4);
         } else {
            var2.append("§8○");
         }
      }

      var2.append(" §7(").append(var1).append("/10)");
      return var2.toString();
   }

   private String a(int var1, int var2, String var3) {
      double var4 = (double)1.0F - (double)var1 / (double)var2;
      int var6 = (int)(var4 * (double)10.0F);
      StringBuilder var7 = new StringBuilder();
      String var8;
      if (var1 <= 3) {
         var8 = "§a";
      } else if (var1 <= 10) {
         var8 = "§e";
      } else if (var1 <= 30) {
         var8 = "§6";
      } else {
         var8 = "§c";
      }

      var7.append(var8).append(var3).append(" ");
      var7.append("§7[");

      for(int var9 = 0; var9 < 10; ++var9) {
         if (var9 < var6) {
            var7.append("§a▰");
         } else {
            var7.append("§8▱");
         }
      }

      var7.append("§7] ").append(var8).append(var1).append("s");
      return var7.toString();
   }

   private String a(Player var1, a var2) {
      if (var2.b == null) {
         return "";
      } else {
         GemRegistryImpl var3 = this.a.getGemRegistry();
         if (var3 == null) {
            return "";
         } else {
            List var4 = var3.getCooldownEntries(var2.b);
            if (var4 != null && !var4.isEmpty()) {
               GemDefinition var5 = var3.getGem(var2.b);
               String var6 = var5 != null ? var5.getColor() : "§7";
               AbilityManager var7 = this.a.getAbilityManager();
               StringBuilder var8 = new StringBuilder();
               boolean var9 = true;

               for(CooldownEntry var11 : var4) {
                  if (!var9) {
                     var8.append(" ").append(var6).append("| ");
                  }

                  var9 = false;
                  int var12 = var7.getRemainingCooldown(var1, var11.getAbilityKey());
                  var8.append(var6).append(var11.getDisplayName()).append(" ");
                  if (var12 > 0) {
                     var8.append("§c").append(var12).append("s");
                  } else {
                     var8.append("§aReady");
                  }
               }

               return var8.toString();
            } else {
               return "";
            }
         }
      }
   }

   public void stop() {
      if (this.b != null) {
         this.b.cancel();
      }

   }

   static {
      c.put(GemType.FIRE, Arrays.asList(new String[]{"fire-fireball", "Fireball"}, new String[]{"fire-campfire", "Campfire"}, new String[]{"fire-crisp", "Crisp"}, new String[]{"fire-meteor-shower", "Meteor"}));
      c.put(GemType.ASTRA, Arrays.asList(new String[]{"astra-daggers", "Daggers"}, new String[]{"astra-projection", "Projection"}));
      c.put(GemType.LIFE, Arrays.asList(new String[]{"life-drainer", "Drainer"}, new String[]{"life-circle-of-life", "Circle"}, new String[]{"life-vitality-vortex", "Vortex"}, new String[]{"life-heart-lock", "Lock"}));
      c.put(GemType.FLUX, Arrays.asList(new String[]{"flux-beam", "Beam"}, new String[]{"flux-ground", "Ground"}, new String[]{"flux-flashbang", "Flash"}, new String[]{"flux-kinetic-burst", "Kinetic"}));
      c.put(GemType.PUFF, Arrays.asList(new String[]{"puff-dash", "Dash"}, new String[]{"puff-breezy-bash", "Bash"}, new String[]{"puff-group-bash", "Group"}));
      c.put(GemType.SPEED, Arrays.asList(new String[]{"speed-blur", "Blur"}, new String[]{"speed-storm", "Storm"}, new String[]{"speed-terminal", "Terminal"}));
      c.put(GemType.STRENGTH, Arrays.asList(new String[]{"strength-nullify", "Nullify"}, new String[]{"strength-frailer", "Frailer"}, new String[]{"strength-shadow-stalker", "Stalker"}));
      c.put(GemType.WEALTH, Arrays.asList(new String[]{"wealth-unfortunate", "Unfortunate"}, new String[]{"wealth-rich-rush", "Rush"}, new String[]{"wealth-item-lock", "Lock"}, new String[]{"wealth-amplification", "Amplify"}));
   }

   private static class a {
      final GemType a;
      final String b;
      final int c;
      final String d;

      a(GemType var1, String var2, int var3, String var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }
   }
}
