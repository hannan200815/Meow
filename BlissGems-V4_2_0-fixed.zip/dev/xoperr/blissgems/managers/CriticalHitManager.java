package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.ParticleUtils;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class CriticalHitManager {
   private final BlissGems a;
   private final Map<UUID, Integer> b = new HashMap();

   public CriticalHitManager(BlissGems var1) {
      this.a = var1;
   }

   public boolean registerHit(Player var1) {
      UUID var2 = var1.getUniqueId();
      int var3 = (Integer)this.b.merge(var2, 1, Integer::sum);
      int var4 = this.a.getConfig().getInt("abilities.strength-chad.hit-threshold", 4);
      if (var3 >= var4) {
         this.b.put(var2, 0);
         Particle.DustOptions var5 = new Particle.DustOptions(ParticleUtils.STRENGTH_RED, 2.0F);
         var1.spawnParticle(Particle.CRIT, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 50, (double)0.5F, (double)0.5F, (double)0.5F, 0.3);
         var1.spawnParticle(Particle.ENCHANTED_HIT, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
         var1.spawnParticle(Particle.DUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var5, true);
         var1.playSound(var1.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0F, 0.7F);
         var1.playSound(var1.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.5F, 2.0F);
         return true;
      } else {
         if (var3 == var4 - 1) {
            var1.spawnParticle(Particle.CRIT, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 15, 0.3, (double)0.5F, 0.3, 0.1);
            var1.playSound(var1.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.7F, 1.8F);
         }

         return false;
      }
   }

   public int getHitCount(Player var1) {
      return (Integer)this.b.getOrDefault(var1.getUniqueId(), 0);
   }

   public void resetHitCount(Player var1) {
      this.b.remove(var1.getUniqueId());
   }

   public void clearHitData(UUID var1) {
      this.b.remove(var1);
   }
}
