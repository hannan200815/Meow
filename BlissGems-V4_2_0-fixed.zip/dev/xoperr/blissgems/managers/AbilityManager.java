package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class AbilityManager {
   private final BlissGems a;
   private final Map<UUID, Map<String, Long>> b;
   private final File c;

   public AbilityManager(BlissGems var1) {
      this.a = var1;
      this.b = new HashMap();
      this.c = new File(var1.getDataFolder(), "cooldowns");
      if (!this.c.exists()) {
         this.c.mkdirs();
      }

   }

   public boolean isOnCooldown(Player var1, String var2) {
      Map var3 = (Map)this.b.get(var1.getUniqueId());
      if (var3 == null) {
         return false;
      } else {
         Long var4 = (Long)var3.get(var2);
         if (var4 == null) {
            return false;
         } else {
            return System.currentTimeMillis() < var4;
         }
      }
   }

   public int getRemainingCooldown(Player var1, String var2) {
      Map var3 = (Map)this.b.get(var1.getUniqueId());
      if (var3 == null) {
         return 0;
      } else {
         Long var4 = (Long)var3.get(var2);
         if (var4 == null) {
            return 0;
         } else {
            long var5 = var4 - System.currentTimeMillis();
            return var5 > 0L ? (int)Math.ceil((double)var5 / (double)1000.0F) : 0;
         }
      }
   }

   public void setCooldown(Player var1, String var2, int var3) {
      Map var4 = (Map)this.b.computeIfAbsent(var1.getUniqueId(), (var0) -> new HashMap());
      var4.put(var2, System.currentTimeMillis() + (long)var3 * 1000L);
      this.a(var1.getUniqueId());
   }

   public boolean canUseAbility(Player var1, String var2) {
      if (this.a.getRegionManager() != null && this.a.getRegionManager().a(var1)) {
         String var3 = this.a.getRegionManager().a();
         if (var3 != null && !var3.isEmpty()) {
            var1.sendMessage(ChatColor.translateAlternateColorCodes('&', var3));
         }

         return false;
      } else if (!this.a.getEnergyManager().canUseAbilities(var1)) {
         this.a.getConfigManager().sendFormattedMessage(var1, "ability-no-energy");
         return false;
      } else if (!var2.startsWith("astra-") && this.a.getAstraAbilities().m(var1)) {
         var1.sendMessage("§4§l§oYour gem abilities are nullified by a Dimensional Void!");
         return false;
      } else {
         return !this.isOnCooldown(var1, var2);
      }
   }

   public void useAbility(Player var1, String var2) {
      int var3 = this.a.getConfigManager().getAbilityCooldown(var2);
      this.setCooldown(var1, var2, var3);
   }

   public void clearCooldowns(Player var1) {
      this.b.remove(var1.getUniqueId());
      File var2 = new File(this.c, String.valueOf(var1.getUniqueId()) + ".yml");
      if (var2.exists()) {
         var2.delete();
      }

   }

   public void clearCache(UUID var1) {
      this.b.remove(var1);
   }

   public void loadCooldowns(UUID var1) {
      File var2 = new File(this.c, String.valueOf(var1) + ".yml");
      if (var2.exists()) {
         YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
         HashMap var4 = new HashMap();
         Set var5 = var3.getKeys(false);
         if (var5 != null) {
            for(String var7 : var5) {
               long var8 = var3.getLong(var7, 0L);
               if (var8 > System.currentTimeMillis()) {
                  var4.put(var7, var8);
               }
            }
         }

         if (!var4.isEmpty()) {
            this.b.put(var1, var4);
         }

      }
   }

   private void a(UUID var1) {
      Map var2 = (Map)this.b.get(var1);
      if (var2 != null && !var2.isEmpty()) {
         File var3 = new File(this.c, String.valueOf(var1) + ".yml");
         YamlConfiguration var4 = new YamlConfiguration();

         for(Map.Entry var6 : var2.entrySet()) {
            if ((Long)var6.getValue() > System.currentTimeMillis()) {
               var4.set((String)var6.getKey(), var6.getValue());
            }
         }

         try {
            var4.save(var3);
         } catch (IOException var7) {
            Logger var10000 = this.a.getLogger();
            String var10001 = String.valueOf(var1);
            var10000.warning("Failed to save cooldowns for " + var10001 + ": " + var7.getMessage());
         }

      }
   }

   public void saveAllCooldowns() {
      for(UUID var2 : this.b.keySet()) {
         this.a(var2);
      }

   }
}
