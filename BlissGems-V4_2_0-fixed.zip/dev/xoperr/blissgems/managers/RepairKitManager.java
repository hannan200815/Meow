package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.Achievement;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class RepairKitManager {
   private final BlissGems a;
   private final Map<Location, a> b = new HashMap();

   public RepairKitManager(BlissGems var1) {
      this.a = var1;
   }

   public boolean createPedestal(final Location var1) {
      final Block var2 = var1.getBlock();
      if (var2.getType() != Material.BEACON) {
         return false;
      } else if (this.b.containsKey(var1)) {
         return false;
      } else {
         final int var3 = this.a.getConfig().getInt("repair-kit.energy-per-second", 1);
         int var4 = this.a.getConfig().getInt("repair-kit.max-total-energy", 10);
         final double var5 = this.a.getConfig().getDouble("repair-kit.heal-radius", (double)10.0F);
         final int var7 = this.a.getConfig().getInt("repair-kit.update-interval", 20);
         final boolean var8 = this.a.getConfig().getBoolean("repair-kit.prioritize-lowest", true);
         final a var9 = new a(var1, var4);
         this.b.put(var1, var9);
         var1.getWorld().playSound(var1, Sound.BLOCK_BEACON_ACTIVATE, 1.0F, 1.0F);
         var1.getWorld().spawnParticle(Particle.END_ROD, var1.clone().add((double)0.5F, (double)1.0F, (double)0.5F), 50, (double)0.5F, (double)1.0F, (double)0.5F, 0.1);
         BukkitTask var10 = (new BukkitRunnable() {
            int a = 0;

            public void run() {
               if (var2.getType() == Material.BEACON && !var9.b()) {
                  ++this.a;
                  if (this.a % var7 == 0) {
                     List var1x = RepairKitManager.this.a(var1, var5);
                     if (var1x.isEmpty()) {
                        if (this.a >= 1200) {
                           RepairKitManager.this.removePedestal(var1);
                           this.cancel();
                           return;
                        }
                     } else {
                        if (var8) {
                           var1x.sort(Comparator.comparingInt((var1xx) -> RepairKitManager.this.a.getEnergyManager().getEnergy(var1xx)));
                        }

                        int var2x = 0;

                        for(Player var4 : var1x) {
                           int var5x = RepairKitManager.this.a.getEnergyManager().getEnergy(var4);
                           int var6 = RepairKitManager.this.a.getConfigManager().getMaxEnergy();
                           if (var5x < var6) {
                              int var7x = Math.min(var3, var6 - var5x);
                              var7x = Math.min(var7x, var9.a());
                              if (var7x > 0) {
                                 RepairKitManager.this.a.getEnergyManager().addEnergy(var4, var7x);
                                 var9.a(var7x);
                                 var2x += var7x;
                                 if (RepairKitManager.this.a.getAchievementManager() != null) {
                                    RepairKitManager.this.a.getAchievementManager().addProgress(var4, Achievement.GOOD_AS_NEW, var7x);
                                 }

                                 Particle var8x = Particle.valueOf(RepairKitManager.this.a.getConfig().getString("repair-kit.particle", "HAPPY_VILLAGER"));
                                 var4.spawnParticle(var8x, var4.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, 0.3, (double)0.5F, 0.3, (double)0.0F);
                                 var4.playSound(var4.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5F, 1.5F);
                                 String var9x = RepairKitManager.this.a.getConfigManager().getFormattedMessage("gem-energy-restored", "amount", String.valueOf(var7x));
                                 if (var9x != null && !var9x.isEmpty()) {
                                    var4.sendMessage(var9x);
                                 }
                              }

                              if (var9.a() <= 0) {
                                 break;
                              }
                           }
                        }

                        if (var9.a() <= 0) {
                           RepairKitManager.this.removePedestal(var1);

                           for(Player var14 : RepairKitManager.this.b(var1, var5)) {
                              var14.sendMessage("§d§oThe Repair Kit has been exhausted!");
                           }

                           this.cancel();
                           return;
                        }
                     }

                     if (RepairKitManager.this.a.getConfig().getBoolean("repair-kit.play-effects", true)) {
                        Particle var11 = Particle.valueOf(RepairKitManager.this.a.getConfig().getString("repair-kit.particle", "HAPPY_VILLAGER"));
                        int var13 = RepairKitManager.this.a.getConfig().getInt("repair-kit.particle-count", 5);
                        var1.getWorld().spawnParticle(var11, var1.clone().add((double)0.5F, (double)1.0F, (double)0.5F), var13, 0.3, (double)0.5F, 0.3, (double)0.0F);
                        if (this.a % (var7 * 3) == 0) {
                           for(int var15 = 0; var15 < 16; ++var15) {
                              double var16 = (double)var15 / (double)16.0F * (double)2.0F * Math.PI;
                              double var18 = Math.cos(var16) * var5;
                              double var19 = Math.sin(var16) * var5;
                              var1.getWorld().spawnParticle(Particle.END_ROD, var1.clone().add(var18, (double)0.5F, var19), 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);
                           }
                        }
                     }
                  }

               } else {
                  RepairKitManager.this.removePedestal(var1);
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L);
         var9.a(var10);
         return true;
      }
   }

   public void removePedestal(Location var1) {
      a var2 = (a)this.b.remove(var1);
      if (var2 != null) {
         if (var2.c() != null) {
            var2.c().cancel();
         }

         var1.getWorld().playSound(var1, Sound.BLOCK_BEACON_DEACTIVATE, 1.0F, 1.0F);
         var1.getWorld().spawnParticle(Particle.SMOKE, var1.clone().add((double)0.5F, (double)1.0F, (double)0.5F), 30, (double)0.5F, (double)1.0F, (double)0.5F, 0.05);
      }

   }

   private List<Player> a(Location var1, double var2) {
      ArrayList var4 = new ArrayList();
      int var5 = this.a.getConfigManager().getMaxEnergy();

      for(Player var7 : this.b(var1, var2)) {
         if (this.a.getEnergyManager().getEnergy(var7) < var5) {
            var4.add(var7);
         }
      }

      return var4;
   }

   private List<Player> b(Location var1, double var2) {
      ArrayList var4 = new ArrayList();

      for(Entity var6 : var1.getWorld().getNearbyEntities(var1, var2, var2, var2)) {
         if (var6 instanceof Player) {
            var4.add((Player)var6);
         }
      }

      return var4;
   }

   public boolean isPedestal(Location var1) {
      return this.b.containsKey(var1);
   }

   public void cleanup() {
      for(Location var2 : new ArrayList(this.b.keySet())) {
         this.removePedestal(var2);
      }

   }

   private static class a {
      private final Location a;
      private int b;
      private BukkitTask c;

      public a(Location var1, int var2) {
         this.a = var1;
         this.b = var2;
      }

      public int a() {
         return this.b;
      }

      public void a(int var1) {
         this.b -= var1;
      }

      public boolean b() {
         return this.b <= 0;
      }

      public void a(BukkitTask var1) {
         this.c = var1;
      }

      public BukkitTask c() {
         return this.c;
      }
   }
}
