package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class ClickActivationManager {
   private final BlissGems a;
   private final Map<UUID, Boolean> b = new HashMap();
   private final File c;

   public ClickActivationManager(BlissGems var1) {
      this.a = var1;
      this.c = new File(var1.getDataFolder(), "playerdata");
      if (!this.c.exists()) {
         this.c.mkdirs();
      }

   }

   public boolean isClickActivationEnabled(Player var1) {
      UUID var2 = var1.getUniqueId();
      if (this.b.containsKey(var2)) {
         return (Boolean)this.b.get(var2);
      } else {
         boolean var3 = this.a(var1);
         this.b.put(var2, var3);
         return var3;
      }
   }

   public boolean toggleClickActivation(Player var1) {
      boolean var2 = this.isClickActivationEnabled(var1);
      boolean var3 = !var2;
      this.setClickActivation(var1, var3);
      return var3;
   }

   public void setClickActivation(Player var1, boolean var2) {
      UUID var3 = var1.getUniqueId();
      this.b.put(var3, var2);
      this.a(var1, var2);
   }

   private boolean a(Player var1) {
      File var2 = this.b(var1);
      if (!var2.exists()) {
         return true;
      } else {
         YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
         return ((FileConfiguration)var3).getBoolean("click-activation-enabled", true);
      }
   }

   private void a(Player var1, boolean var2) {
      File var3 = this.b(var1);
      YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
      ((FileConfiguration)var4).set("click-activation-enabled", var2);

      try {
         ((FileConfiguration)var4).save(var3);
      } catch (IOException var6) {
         Logger var10000 = this.a.getLogger();
         String var10001 = var1.getName();
         var10000.warning("Failed to save click activation for " + var10001 + ": " + var6.getMessage());
      }

   }

   private File b(Player var1) {
      return new File(this.c, String.valueOf(var1.getUniqueId()) + ".yml");
   }

   public void clearCache(Player var1) {
      this.b.remove(var1.getUniqueId());
   }
}
