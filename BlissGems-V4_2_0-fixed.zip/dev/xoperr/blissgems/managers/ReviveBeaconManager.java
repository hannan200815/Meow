package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;

public class ReviveBeaconManager {
   private final BlissGems a;
   private final Map<UUID, a> b = new HashMap();

   public ReviveBeaconManager(BlissGems var1) {
      this.a = var1;
   }

   public void activateBeacon(Player var1, Location var2, int var3, double var4) {
      UUID var6 = var1.getUniqueId();
      if (this.b.containsKey(var6)) {
         ((a)this.b.get(var6)).d();
      }

      a var7 = new a(this.a, var1, var2, var3, var4);
      this.b.put(var6, var7);
      var7.a();
   }

   public boolean canRevive(Player var1) {
      UUID var2 = var1.getUniqueId();
      if (!this.b.containsKey(var2)) {
         return false;
      } else {
         a var3 = (a)this.b.get(var2);
         return var3.b() && var3.a(var1.getLocation());
      }
   }

   public Location getReviveLocation(Player var1) {
      UUID var2 = var1.getUniqueId();
      return !this.b.containsKey(var2) ? null : ((a)this.b.get(var2)).c();
   }

   public void removeBeacon(Player var1) {
      UUID var2 = var1.getUniqueId();
      if (this.b.containsKey(var2)) {
         ((a)this.b.get(var2)).d();
         this.b.remove(var2);
      }

   }

   public void cleanup() {
      for(a var2 : this.b.values()) {
         var2.d();
      }

      this.b.clear();
   }

   private static class a {
      private final BlissGems a;
      private final Player b;
      private final Location c;
      private final double d;
      private final long e;
      private int f = -1;
      private boolean g = true;

      public a(BlissGems var1, Player var2, Location var3, int var4, double var5) {
         this.a = var1;
         this.b = var2;
         this.c = var3.clone();
         this.d = var5;
         this.e = System.currentTimeMillis() + (long)var4 * 1000L;
      }

      public void a() {
         int var1 = (int)((this.e - System.currentTimeMillis()) / 50L);
         this.f = this.a.getServer().getScheduler().scheduleSyncDelayedTask(this.a, () -> {
            this.g = false;
            this.b.sendMessage("§c§lYour Revive Beacon has expired!");
         }, (long)var1);
         this.a.getServer().getScheduler().runTaskTimer(this.a, (var1x) -> {
            if (this.g && System.currentTimeMillis() < this.e) {
               if (this.c.getWorld() != null) {
                  this.c.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, this.c.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 10, (double)0.5F, (double)0.5F, (double)0.5F, 0.05);
               }

            } else {
               var1x.cancel();
            }
         }, 0L, 20L);
      }

      public boolean b() {
         return this.g && System.currentTimeMillis() < this.e;
      }

      public boolean a(Location var1) {
         if (this.c.getWorld() != null && var1.getWorld() != null) {
            if (!this.c.getWorld().equals(var1.getWorld())) {
               return false;
            } else {
               return this.c.distance(var1) <= this.d;
            }
         } else {
            return false;
         }
      }

      public Location c() {
         return this.c.clone();
      }

      public void d() {
         this.g = false;
         if (this.f != -1) {
            this.a.getServer().getScheduler().cancelTask(this.f);
         }

      }
   }
}
