package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.Achievement;
import dev.xoperr.blissgems.utils.CustomItemManager;
import dev.xoperr.blissgems.utils.GemType;
import java.util.ArrayList;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.Display.Billboard;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

public class GemRitualManager {
   private final BlissGems a;

   public GemRitualManager(BlissGems var1) {
      this.a = var1;
   }

   public void performGemRitual(final Player var1, GemType var2, boolean var3, int var4) {
      if (!var3 && this.a.getAchievementManager() != null) {
         this.a.getAchievementManager().unlock(var1, Achievement.REAWAKENING);
      }

      Location var5 = var1.getLocation().clone();
      Color var6 = this.a(var2);
      var1.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 300, 0, false, false));
      var1.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 40, 1, false, false));
      final ArrayList var7 = new ArrayList();
      GemType[] var8 = GemType.values();
      Location var9 = var1.getLocation();

      for(int var10 = 0; var10 < var8.length; ++var10) {
         String var11 = this.a(var8[var10], var4);
         ItemStack var12 = CustomItemManager.getItemById(var11, 10);
         if (var12 != null) {
            double var13 = (double)var10 / (double)8.0F * (double)2.0F * Math.PI;
            double var15 = (double)2.5F;
            double var17 = (double)1.5F;
            double var19 = Math.cos(var13) * var15;
            double var21 = Math.sin(var13) * var15;
            Location var23 = var9.clone().add(var19, var17, var21);
            ItemDisplay var24 = (ItemDisplay)var1.getWorld().spawn(var23, ItemDisplay.class);
            var24.setItemStack(var12);
            var24.setBillboard(Billboard.FIXED);
            var24.setViewRange(100.0F);
            var24.setGlowing(true);
            var7.add(var24);
         }
      }

      (new BukkitRunnable() {
         int a = 0;
         final int b = 80;

         public void run() {
            if (var1.isOnline() && this.a < 80) {
               for(int var18 = 0; var18 < var7.size(); ++var18) {
                  ItemDisplay var19 = (ItemDisplay)var7.get(var18);
                  if (var19 != null && var19.isValid()) {
                     double var3 = (double)var18 / (double)8.0F * (double)2.0F * Math.PI;
                     double var5 = (double)this.a / (double)20.0F * Math.PI + var3;
                     double var7x = (double)2.5F;
                     double var9 = (double)1.5F + Math.sin((double)this.a / (double)10.0F) * 0.3;
                     double var11 = Math.cos(var5) * var7x;
                     double var13 = Math.sin(var5) * var7x;
                     Location var15 = var1.getLocation().clone().add(var11, var9, var13);
                     var19.teleport(var15);
                     float var16 = (float)(this.a * 5 % 360);
                     Transformation var17 = new Transformation(new Vector3f(0.0F, 0.0F, 0.0F), new AxisAngle4f((float)Math.toRadians((double)var16), 0.0F, 1.0F, 0.0F), new Vector3f(0.7F, 0.7F, 0.7F), new AxisAngle4f(0.0F, 0.0F, 0.0F, 1.0F));
                     var19.setTransformation(var17);
                  }
               }

               if (this.a % 10 == 0) {
                  var1.playSound(var1.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.6F, 1.0F + (float)this.a / 80.0F);
               }

               ++this.a;
            } else {
               for(ItemDisplay var2 : var7) {
                  if (var2 != null && var2.isValid()) {
                     var2.remove();
                  }
               }

               var7.clear();
               this.cancel();
            }
         }
      }).runTaskTimer(this.a, 0L, 1L);
      this.a.getServer().getScheduler().runTaskLater(this.a, () -> {
         final Location var5 = var1.getLocation().add((double)0.0F, (double)1.5F, (double)0.0F);
         final ArrayList var6 = new ArrayList();

         for(int var7 = 0; var7 < var8.length; ++var7) {
            String var8x = this.a(var8[var7], var4);
            ItemStack var9 = CustomItemManager.getItemById(var8x, 10);
            if (var9 != null) {
               double var10 = (double)var7 / (double)8.0F * (double)2.0F * Math.PI;
               double var12 = 12.566370614359172 + var10;
               double var14 = (double)2.5F;
               double var16 = (double)1.5F;
               double var18 = Math.cos(var12) * var14;
               double var20 = Math.sin(var12) * var14;
               Location var22 = var1.getLocation().clone().add(var18, var16, var20);
               ItemDisplay var23 = (ItemDisplay)var1.getWorld().spawn(var22, ItemDisplay.class);
               var23.setItemStack(var9);
               var23.setBillboard(Billboard.FIXED);
               var23.setViewRange(100.0F);
               var23.setGlowing(true);
               var6.add(var23);
            }
         }

         (new BukkitRunnable() {
            int a = 0;
            final int b = 40;

            public void run() {
               if (var1.isOnline() && this.a < 40) {
                  double var20 = (double)this.a / (double)40.0F;

                  for(int var3 = 0; var3 < var6.size(); ++var3) {
                     ItemDisplay var4 = (ItemDisplay)var6.get(var3);
                     if (var4 != null && var4.isValid()) {
                        GemType var5x = var8[var3];
                        double var6x = (double)var3 / (double)8.0F * (double)2.0F * Math.PI;
                        double var8x = 12.566370614359172 + var6x;
                        double var10 = (double)2.5F;
                        double var12 = (double)1.5F;
                        Location var14 = var1.getLocation().add(Math.cos(var8x) * var10, var12, Math.sin(var8x) * var10);
                        Location var15;
                        if (var5x == var2) {
                           var15 = var5.clone();
                        } else {
                           var15 = var14.clone().add((double)0.0F, (double)-3.0F, (double)0.0F);
                        }

                        Location var16 = var14.clone().add((var15.getX() - var14.getX()) * var20, (var15.getY() - var14.getY()) * var20, (var15.getZ() - var14.getZ()) * var20);
                        var4.teleport(var16);
                        float var17 = var5x == var2 ? (float)(this.a * 15 % 360) : (float)(this.a * 3 % 360);
                        Transformation var18 = new Transformation(new Vector3f(0.0F, 0.0F, 0.0F), new AxisAngle4f((float)Math.toRadians((double)var17), 0.0F, 1.0F, 0.0F), var5x == var2 ? new Vector3f(1.0F, 1.0F, 1.0F) : new Vector3f(0.7F, 0.7F, 0.7F), new AxisAngle4f(0.0F, 0.0F, 0.0F, 1.0F));
                        var4.setTransformation(var18);
                        if (var5x == var2) {
                           GemRitualManager.this.a(var5x);
                           var1.getWorld().spawnParticle(Particle.FIREWORK, var16, 3, 0.1, 0.1, 0.1, 0.05);
                           var1.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var16, 2, 0.1, 0.1, 0.1, 0.01);
                        }
                     }
                  }

                  if (this.a % 5 == 0) {
                     var1.playSound(var1.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 0.7F, 1.0F + (float)var20);
                  }

                  ++this.a;
               } else {
                  for(ItemDisplay var2x : var6) {
                     if (var2x != null && var2x.isValid()) {
                        var2x.remove();
                     }
                  }

                  var6.clear();
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L);
         this.a.getServer().getScheduler().runTaskLater(this.a, () -> {
            var1.playSound(var1.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.5F);
            var1.playSound(var1.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.8F, 1.8F);
         }, 40L);
      }, 80L);
      this.a.getServer().getScheduler().runTaskLater(this.a, () -> (new BukkitRunnable() {
            int a = 0;

            public void run() {
               if (var1.isOnline() && this.a < 20) {
                  double var1x = (double)this.a / (double)20.0F * (double)5.0F;

                  for(int var3 = 0; var3 < 32; ++var3) {
                     double var4 = (double)var3 / (double)32.0F * (double)2.0F * Math.PI;
                     double var6x = Math.cos(var4) * var1x;
                     double var8 = Math.sin(var4) * var1x;
                     Location var10 = var5.clone().add(var6x, 0.1, var8);
                     Particle.DustOptions var11 = new Particle.DustOptions(var6, 1.5F);
                     var1.getWorld().spawnParticle(Particle.DUST, var10, 3, 0.1, 0.1, 0.1, (double)0.0F, var11, true);
                     var1.getWorld().spawnParticle(Particle.END_ROD, var10, 1, (double)0.0F, (double)0.0F, (double)0.0F, 0.01);
                  }

                  if (this.a % 5 == 0) {
                     var1.playSound(var5, Sound.BLOCK_ENCHANTMENT_TABLE_USE, 0.5F, 1.5F);
                  }

                  ++this.a;
               } else {
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L), 120L);
      this.a.getServer().getScheduler().runTaskLater(this.a, () -> (new BukkitRunnable() {
            int a = 0;
            final int b = 40;

            public void run() {
               if (var1.isOnline() && this.a < 40) {
                  double var1x = (double)this.a / (double)40.0F;
                  double var3 = var1x * (double)5.0F;

                  for(int var5x = 0; var5x < 3; ++var5x) {
                     double var6x = (double)var5x / (double)3.0F * (double)2.0F * Math.PI;
                     double var8 = var1x * (double)6.0F * Math.PI + var6x;
                     double var10 = (double)1.5F * ((double)1.0F - var1x * (double)0.5F);
                     double var12 = Math.cos(var8) * var10;
                     double var14 = Math.sin(var8) * var10;
                     Location var16 = var5.clone().add(var12, var3, var14);
                     Particle.DustOptions var17 = new Particle.DustOptions(var6, 1.8F);
                     var1.getWorld().spawnParticle(Particle.DUST, var16, 5, 0.1, 0.1, 0.1, (double)0.0F, var17, true);
                     var1.getWorld().spawnParticle(Particle.ENCHANT, var16, 8, 0.2, 0.2, 0.2, (double)0.5F);
                     var1.getWorld().spawnParticle(Particle.END_ROD, var16, 2, 0.1, 0.1, 0.1, 0.02);
                  }

                  for(double var18 = (double)0.0F; var18 <= var3; var18 += 0.3) {
                     Particle.DustOptions var7 = new Particle.DustOptions(var6, 0.8F);
                     var1.getWorld().spawnParticle(Particle.DUST, var5.clone().add((double)0.0F, var18, (double)0.0F), 2, 0.15, 0.1, 0.15, (double)0.0F, var7, true);
                  }

                  if (this.a % 10 == 0) {
                     var1.playSound(var5, Sound.BLOCK_BELL_USE, 0.7F, 1.0F + (float)var1x);
                     var1.playSound(var5, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.5F, 1.5F);
                  }

                  ++this.a;
               } else {
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L), 140L);
      this.a.getServer().getScheduler().runTaskLater(this.a, () -> {
         Location var4 = var5.clone().add((double)0.0F, (double)5.0F, (double)0.0F);
         Particle.DustOptions var5x = new Particle.DustOptions(var6, 2.5F);
         var1.getWorld().spawnParticle(Particle.DUST, var4, 200, (double)1.5F, (double)1.5F, (double)1.5F, (double)0.0F, var5x, true);
         var1.getWorld().spawnParticle(Particle.FIREWORK, var4, 100, (double)1.0F, (double)1.0F, (double)1.0F, 0.2);
         var1.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var4, 80, 1.2, 1.2, 1.2, 0.1);
         var1.getWorld().spawnParticle(Particle.END_ROD, var4, 60, (double)1.5F, (double)1.5F, (double)1.5F, 0.15);
         var1.getWorld().spawnParticle(Particle.ENCHANT, var4, 150, (double)2.0F, (double)2.0F, (double)2.0F, (double)1.0F);

         for(double var6x = (double)0.0F; var6x <= (double)10.0F; var6x += 0.2) {
            Particle.DustOptions var8 = new Particle.DustOptions(var6, 1.5F);
            var1.getWorld().spawnParticle(Particle.DUST, var5.clone().add((double)0.0F, var6x, (double)0.0F), 8, 0.2, 0.1, 0.2, (double)0.0F, var8, true);
            var1.getWorld().spawnParticle(Particle.END_ROD, var5.clone().add((double)0.0F, var6x, (double)0.0F), 3, 0.15, 0.1, 0.15, 0.02);
         }

         var1.playSound(var5, Sound.ITEM_TOTEM_USE, 1.0F, 1.0F);
         var1.playSound(var5, Sound.ENTITY_ENDER_DRAGON_GROWL, 0.6F, 2.0F);
         var1.playSound(var5, Sound.BLOCK_BEACON_ACTIVATE, 1.0F, 1.5F);
         var1.playSound(var5, Sound.BLOCK_END_PORTAL_SPAWN, 0.5F, 1.5F);
         (new BukkitRunnable() {
            int a = 0;

            public void run() {
               if (var1.isOnline() && this.a < 20) {
                  for(int var1x = 0; var1x < 10; ++var1x) {
                     double var2 = (Math.random() - (double)0.5F) * (double)3.0F;
                     double var4 = (Math.random() - (double)0.5F) * (double)3.0F;
                     double var6x = (double)5.0F - (double)this.a / (double)20.0F * (double)4.5F;
                     Location var8 = var5.clone().add(var2, var6x, var4);
                     Location var9 = var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F);
                     Particle.DustOptions var10 = new Particle.DustOptions(var6, 1.2F);
                     var1.getWorld().spawnParticle(Particle.DUST, var8, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, var10, true);
                     var1.getWorld().spawnParticle(Particle.END_ROD, var8, 1, (double)0.0F, (double)0.0F, (double)0.0F, 0.01);
                  }

                  ++this.a;
               } else {
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L);
      }, 180L);
      this.a.getServer().getScheduler().runTaskLater(this.a, () -> {
         Location var3 = var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F);
         Particle.DustOptions var4 = new Particle.DustOptions(var6, 2.0F);
         var1.getWorld().spawnParticle(Particle.DUST, var3, 150, 0.8, (double)1.0F, 0.8, (double)0.0F, var4, true);
         var1.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var3, 50, (double)0.5F, 0.8, (double)0.5F, 0.1);
         var1.getWorld().spawnParticle(Particle.ENCHANT, var3, 100, 0.6, (double)1.0F, 0.6, 0.8);
         var1.getWorld().spawnParticle(Particle.FIREWORK, var3, 30, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
         var1.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, var3, 40, 0.6, 0.8, 0.6, (double)0.0F);

         for(int var5x = 0; var5x < 360; var5x += 10) {
            double var6x = Math.toRadians((double)var5x);
            double var8 = Math.cos(var6x) * (double)2.0F;
            double var10 = Math.sin(var6x) * (double)2.0F;
            Particle.DustOptions var12 = new Particle.DustOptions(var6, 1.5F);
            var1.getWorld().spawnParticle(Particle.DUST, var3.clone().add(var8, (double)0.0F, var10), 5, 0.1, 0.1, 0.1, (double)0.0F, var12, true);
            var1.getWorld().spawnParticle(Particle.END_ROD, var3.clone().add(var8, (double)0.0F, var10), 2, (double)0.0F, (double)0.0F, (double)0.0F, 0.05);
         }

         var1.playSound(var5, Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.0F);
         var1.playSound(var5, Sound.BLOCK_BELL_USE, 1.0F, 2.0F);
         var1.playSound(var5, Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0F, 2.0F);
         var1.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0, false, false));
      }, 200L);
      this.a.getServer().getScheduler().runTaskLater(this.a, () -> (new BukkitRunnable() {
            int a = 0;

            public void run() {
               if (var1.isOnline() && this.a < 40) {
                  double var1x = (double)this.a / (double)40.0F * (double)4.0F * Math.PI;
                  double var3 = (double)1.5F;
                  double var5 = Math.cos(var1x) * var3;
                  double var7 = Math.sin(var1x) * var3;
                  Location var9 = var1.getLocation().add(var5, (double)1.5F, var7);
                  Particle.DustOptions var10 = new Particle.DustOptions(var6, 1.0F);
                  var1.getWorld().spawnParticle(Particle.DUST, var9, 3, 0.1, 0.1, 0.1, (double)0.0F, var10, true);
                  var1.getWorld().spawnParticle(Particle.END_ROD, var9, 1, (double)0.0F, (double)0.0F, (double)0.0F, 0.01);
                  if (this.a % 5 == 0) {
                     Location var11 = var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F);
                     var1.getWorld().spawnParticle(Particle.END_ROD, var11, 3, (double)0.5F, (double)0.5F, (double)0.5F, 0.02);
                  }

                  ++this.a;
               } else {
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L), 200L);
   }

   public void performReviveBeaconRitual(final Player var1, final Location var2) {
      final Color var3 = Color.fromRGB(255, 215, 0);
      var1.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 100, 0, false, false));
      (new BukkitRunnable() {
         int a = 0;

         public void run() {
            if (var1.isOnline() && this.a < 20) {
               double var1x = (double)this.a / (double)20.0F * (double)6.0F;

               for(int var3x = 0; var3x < 32; ++var3x) {
                  double var4 = (double)var3x / (double)32.0F * (double)2.0F * Math.PI;
                  double var6 = Math.cos(var4) * var1x;
                  double var8 = Math.sin(var4) * var1x;
                  Location var10 = var2.clone().add(var6, 0.1, var8);
                  Particle.DustOptions var11 = new Particle.DustOptions(var3, 2.0F);
                  var1.getWorld().spawnParticle(Particle.DUST, var10, 5, 0.1, 0.1, 0.1, (double)0.0F, var11, true);
                  var1.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var10, 2, (double)0.0F, (double)0.0F, (double)0.0F, 0.02);
               }

               if (this.a % 5 == 0) {
                  var1.playSound(var2, Sound.BLOCK_BEACON_AMBIENT, 0.7F, 1.5F);
               }

               ++this.a;
            } else {
               this.cancel();
            }
         }
      }).runTaskTimer(this.a, 0L, 1L);
      this.a.getServer().getScheduler().runTaskLater(this.a, () -> (new BukkitRunnable() {
            int a = 0;
            final int b = 30;

            public void run() {
               if (var1.isOnline() && this.a < 30) {
                  double var1x = (double)this.a / (double)30.0F;
                  double var3x = var1x * (double)8.0F;

                  for(double var5 = (double)0.0F; var5 <= var3x; var5 += 0.3) {
                     Particle.DustOptions var7 = new Particle.DustOptions(var3, 1.5F);
                     var1.getWorld().spawnParticle(Particle.DUST, var2.clone().add((double)0.0F, var5, (double)0.0F), 3, 0.2, 0.1, 0.2, (double)0.0F, var7, true);
                     var1.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var2.clone().add((double)0.0F, var5, (double)0.0F), 1, 0.1, 0.1, 0.1, 0.01);
                  }

                  if (this.a % 10 == 0) {
                     var1.playSound(var2, Sound.BLOCK_BEACON_POWER_SELECT, 0.8F, 1.0F + (float)var1x);
                  }

                  ++this.a;
               } else {
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L), 20L);
      this.a.getServer().getScheduler().runTaskLater(this.a, () -> {
         Location var3x = var2.clone().add((double)0.0F, (double)8.0F, (double)0.0F);
         Particle.DustOptions var4 = new Particle.DustOptions(var3, 3.0F);
         var1.getWorld().spawnParticle(Particle.DUST, var3x, 300, (double)2.0F, (double)2.0F, (double)2.0F, (double)0.0F, var4, true);
         var1.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var3x, 150, (double)1.5F, (double)1.5F, (double)1.5F, 0.15);
         var1.getWorld().spawnParticle(Particle.FIREWORK, var3x, 80, (double)1.0F, (double)1.0F, (double)1.0F, 0.2);
         var1.getWorld().spawnParticle(Particle.END_ROD, var3x, 100, (double)2.0F, (double)2.0F, (double)2.0F, 0.2);

         for(double var5 = (double)0.0F; var5 <= (double)20.0F; var5 += 0.2) {
            Particle.DustOptions var7 = new Particle.DustOptions(var3, 2.0F);
            var1.getWorld().spawnParticle(Particle.DUST, var2.clone().add((double)0.0F, var5, (double)0.0F), 12, 0.3, 0.1, 0.3, (double)0.0F, var7, true);
            var1.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var2.clone().add((double)0.0F, var5, (double)0.0F), 3, 0.2, 0.1, 0.2, 0.03);
         }

         var1.playSound(var2, Sound.BLOCK_BEACON_ACTIVATE, 1.5F, 1.0F);
         var1.playSound(var2, Sound.ITEM_TOTEM_USE, 1.0F, 1.2F);
         var1.playSound(var2, Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5F, 2.0F);
      }, 50L);
      this.a.getServer().getScheduler().runTaskLater(this.a, () -> (new BukkitRunnable() {
            int a = 0;

            public void run() {
               if (var1.isOnline() && this.a < 40) {
                  double var1x = (double)this.a / (double)40.0F * (double)4.0F * Math.PI;
                  double var3x = (double)2.0F;

                  for(int var5 = 0; var5 < 3; ++var5) {
                     double var6 = (double)var5 * (double)2.0F + (double)1.0F;
                     double var8 = Math.cos(var1x + (double)var5 * Math.PI / (double)1.5F) * var3x;
                     double var10 = Math.sin(var1x + (double)var5 * Math.PI / (double)1.5F) * var3x;
                     Location var12 = var2.clone().add(var8, var6, var10);
                     Particle.DustOptions var13 = new Particle.DustOptions(var3, 1.2F);
                     var1.getWorld().spawnParticle(Particle.DUST, var12, 5, 0.1, 0.1, 0.1, (double)0.0F, var13, true);
                     var1.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var12, 1, (double)0.0F, (double)0.0F, (double)0.0F, 0.01);
                  }

                  if (this.a % 5 == 0) {
                     var1.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var2.clone().add((double)0.0F, (double)2.0F, (double)0.0F), 5, (double)0.5F, (double)0.5F, (double)0.5F, 0.02);
                  }

                  ++this.a;
               } else {
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L), 60L);
   }

   private String a(GemType var1, int var2) {
      return GemType.buildOraxenId(var1, var2);
   }

   private Color a(GemType var1) {
      Color var10000;
      switch (var1) {
         case ASTRA -> var10000 = Color.fromRGB(106, 11, 184);
         case FIRE -> var10000 = Color.fromRGB(255, 85, 85);
         case FLUX -> var10000 = Color.fromRGB(85, 255, 255);
         case LIFE -> var10000 = Color.fromRGB(85, 255, 85);
         case PUFF -> var10000 = Color.fromRGB(255, 255, 255);
         case SPEED -> var10000 = Color.fromRGB(255, 255, 85);
         case STRENGTH -> var10000 = Color.fromRGB(170, 0, 0);
         case WEALTH -> var10000 = Color.fromRGB(255, 170, 0);
         default -> throw new IncompatibleClassChangeError();
      }

      return var10000;
   }
}
