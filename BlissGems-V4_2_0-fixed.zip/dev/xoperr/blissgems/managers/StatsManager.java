package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import java.io.File;
import java.util.AbstractMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class StatsManager {
   private final BlissGems a;
   private final Map<UUID, PlayerStats> b = new HashMap();
   private final File c;

   public StatsManager(BlissGems var1) {
      this.a = var1;
      this.c = new File(var1.getDataFolder(), "playerstats");
      if (!this.c.exists()) {
         this.c.mkdirs();
      }

      this.a();
   }

   public void recordKill(Player var1, Player var2) {
      PlayerStats var3 = (PlayerStats)this.b.computeIfAbsent(var1.getUniqueId(), (var0) -> new PlayerStats());
      ++var3.kills;
      this.a(var1.getUniqueId());
   }

   public void recordDeath(Player var1) {
      PlayerStats var2 = (PlayerStats)this.b.computeIfAbsent(var1.getUniqueId(), (var0) -> new PlayerStats());
      ++var2.deaths;
      this.a(var1.getUniqueId());
   }

   public void recordGemSwitch(Player var1) {
      PlayerStats var2 = (PlayerStats)this.b.computeIfAbsent(var1.getUniqueId(), (var0) -> new PlayerStats());
      long var3 = System.currentTimeMillis();
      var2.timePlayedMs += var3 - var2.lastGemSwitchTime;
      var2.lastGemSwitchTime = var3;
      this.a(var1.getUniqueId());
   }

   public int getKills(Player var1) {
      return ((PlayerStats)this.b.getOrDefault(var1.getUniqueId(), new PlayerStats())).kills;
   }

   public int getDeaths(Player var1) {
      return ((PlayerStats)this.b.getOrDefault(var1.getUniqueId(), new PlayerStats())).deaths;
   }

   public long getTimePlayed(Player var1) {
      PlayerStats var2 = (PlayerStats)this.b.getOrDefault(var1.getUniqueId(), new PlayerStats());
      long var3 = var2.timePlayedMs;
      if (var2.lastGemSwitchTime > 0L) {
         var3 += System.currentTimeMillis() - var2.lastGemSwitchTime;
      }

      return var3;
   }

   public List<Map.Entry<UUID, Integer>> getTopKillers(int var1) {
      return this.b.entrySet().stream().sorted((var0, var1x) -> Integer.compare(((PlayerStats)var1x.getValue()).kills, ((PlayerStats)var0.getValue()).kills)).limit((long)var1).map((var0) -> new AbstractMap.SimpleEntry((UUID)var0.getKey(), ((PlayerStats)var0.getValue()).kills)).toList();
   }

   public Map<String, Integer> getGemUsageStats() {
      HashMap var1 = new HashMap();

      for(Player var3 : Bukkit.getOnlinePlayers()) {
         String var4 = this.a.getGemManager().getGemType(var3) != null ? this.a.getGemManager().getGemType(var3).getDisplayName() : "None";
         var1.put(var4, (Integer)var1.getOrDefault(var4, 0) + 1);
      }

      return var1;
   }

   private void a(UUID var1) {
   }

   private void a() {
   }

   public void cleanup(UUID var1) {
      this.recordGemSwitch(Bukkit.getPlayer(var1));
   }

   public static class PlayerStats {
      public int kills = 0;
      public int deaths = 0;
      public long timePlayedMs = 0L;
      public long lastGemSwitchTime = System.currentTimeMillis();
   }
}
