package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.api.GemDefinition;
import dev.xoperr.blissgems.utils.CustomItemManager;
import dev.xoperr.blissgems.utils.GemType;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class GemManager {
   private final BlissGems a;
   private final Map<UUID, ActiveGem> b;

   public GemManager(BlissGems var1) {
      this.a = var1;
      this.b = new HashMap();
   }

   public void updateActiveGem(Player var1) {
      ActiveGem var2 = (ActiveGem)this.b.get(var1.getUniqueId());
      ItemStack[] var3 = var1.getInventory().getContents();
      ActiveGem var4 = null;
      GemRegistryImpl var5 = this.a.getGemRegistry();

      for(ItemStack var9 : var3) {
         String var10;
         if (var9 != null && (var10 = CustomItemManager.getIdByItem(var9)) != null) {
            if (GemType.isGem(var10)) {
               GemType var11 = GemType.fromOraxenId(var10);
               int var12 = GemType.getTierFromOraxenId(var10);
               if (var11 != null && this.a.getConfigManager().isGemEnabled(var11)) {
                  var4 = new ActiveGem(var11, var12);
                  break;
               }
            }

            if (var5 != null && var5.isRegisteredGem(var10)) {
               String var14 = var5.gemIdFromItemId(var10);
               int var15 = var5.tierFromItemId(var10);
               var4 = new ActiveGem(var14, var15);
               break;
            }
         }
      }

      if (var2 != null && (var4 == null || !Objects.equals(var2.getGemId(), var4.getGemId())) && var2.getGemId() != null && var5 != null) {
         GemAbilityHandler var13 = var5.getAbilityHandler(var2.getGemId());
         if (var13 != null) {
            var13.cleanup(var1);
         }
      }

      if (var4 != null) {
         this.b.put(var1.getUniqueId(), var4);
      } else {
         this.b.remove(var1.getUniqueId());
      }

   }

   public ActiveGem getActiveGem(Player var1) {
      return (ActiveGem)this.b.get(var1.getUniqueId());
   }

   public boolean hasActiveGem(Player var1) {
      return this.b.containsKey(var1.getUniqueId());
   }

   public GemType getGemType(Player var1) {
      ActiveGem var2 = this.getActiveGem(var1);
      return var2 != null ? var2.getType() : null;
   }

   public int getGemTier(Player var1) {
      ActiveGem var2 = this.getActiveGem(var1);
      return var2 != null ? var2.getTier() : 1;
   }

   public String getGemId(Player var1) {
      ActiveGem var2 = this.getActiveGem(var1);
      return var2 != null ? var2.getGemId() : null;
   }

   public boolean hasGemType(Player var1, GemType var2) {
      ActiveGem var3 = this.getActiveGem(var1);
      return var3 != null && var3.getType() == var2;
   }

   public boolean hasGemInOffhand(Player var1) {
      ItemStack var2 = var1.getInventory().getItemInOffHand();
      if (var2 == null) {
         return false;
      } else {
         String var3 = CustomItemManager.getIdByItem(var2);
         if (var3 == null) {
            return false;
         } else if (GemType.isGem(var3)) {
            GemType var5 = GemType.fromOraxenId(var3);
            return var5 != null && this.a.getConfigManager().isGemEnabled(var5);
         } else {
            GemRegistryImpl var4 = this.a.getGemRegistry();
            return var4 != null && var4.isRegisteredGem(var3);
         }
      }
   }

   public boolean hasGemTypeInOffhand(Player var1, GemType var2) {
      ItemStack var3 = var1.getInventory().getItemInOffHand();
      if (var3 == null) {
         return false;
      } else {
         String var4 = CustomItemManager.getIdByItem(var3);
         if (var4 != null && GemType.isGem(var4)) {
            GemType var5 = GemType.fromOraxenId(var4);
            return var5 == var2;
         } else {
            return false;
         }
      }
   }

   public GemType getGemTypeFromOffhand(Player var1) {
      ItemStack var2 = var1.getInventory().getItemInOffHand();
      if (var2 == null) {
         return null;
      } else {
         String var3 = CustomItemManager.getIdByItem(var2);
         return var3 != null && GemType.isGem(var3) ? GemType.fromOraxenId(var3) : null;
      }
   }

   public String getGemIdFromOffhand(Player var1) {
      ItemStack var2 = var1.getInventory().getItemInOffHand();
      if (var2 == null) {
         return null;
      } else {
         String var3 = CustomItemManager.getIdByItem(var2);
         if (var3 == null) {
            return null;
         } else {
            GemType var4 = GemType.fromOraxenId(var3);
            if (var4 != null) {
               return var4.getId();
            } else {
               GemRegistryImpl var5 = this.a.getGemRegistry();
               return var5 != null ? var5.gemIdFromItemId(var3) : null;
            }
         }
      }
   }

   public int getTierFromOffhand(Player var1) {
      ItemStack var2 = var1.getInventory().getItemInOffHand();
      if (var2 == null) {
         return 1;
      } else {
         String var3 = CustomItemManager.getIdByItem(var2);
         if (var3 == null) {
            return 1;
         } else if (GemType.isGem(var3)) {
            return GemType.getTierFromOraxenId(var3);
         } else {
            GemRegistryImpl var4 = this.a.getGemRegistry();
            return var4 != null && var4.isRegisteredGem(var3) ? var4.tierFromItemId(var3) : 1;
         }
      }
   }

   public boolean giveGem(Player var1, GemType var2, int var3) {
      String var4 = GemType.buildOraxenId(var2, var3);
      int var5 = this.a.getEnergyManager().getEnergy(var1);
      ItemStack var6 = CustomItemManager.getItemById(var4, var5);
      if (var6 != null) {
         var1.getInventory().addItem(new ItemStack[]{var6});
         this.updateActiveGem(var1);
         return true;
      } else {
         return false;
      }
   }

   public boolean giveGem(Player var1, String var2, int var3) {
      for(GemType var7 : GemType.values()) {
         if (var7.getId().equalsIgnoreCase(var2)) {
            return this.giveGem(var1, var7, var3);
         }
      }

      GemRegistryImpl var9 = this.a.getGemRegistry();
      if (var9 != null) {
         GemDefinition var10 = var9.getGem(var2);
         if (var10 != null) {
            String var11 = var10.buildItemId(var3);
            int var12 = this.a.getEnergyManager().getEnergy(var1);
            ItemStack var8 = CustomItemManager.getItemById(var11, var12);
            if (var8 != null) {
               var1.getInventory().addItem(new ItemStack[]{var8});
               this.updateActiveGem(var1);
               return true;
            }
         }
      }

      return false;
   }

   public ItemStack findGemInInventory(Player var1) {
      GemRegistryImpl var2 = this.a.getGemRegistry();

      for(ItemStack var6 : var1.getInventory().getContents()) {
         String var7;
         if (var6 != null && (var7 = CustomItemManager.getIdByItem(var6)) != null) {
            if (GemType.isGem(var7)) {
               return var6;
            }

            if (var2 != null && var2.isRegisteredGem(var7)) {
               return var6;
            }
         }
      }

      for(ItemStack var11 : var1.getEnderChest().getContents()) {
         String var12;
         if (var11 != null && (var12 = CustomItemManager.getIdByItem(var11)) != null) {
            if (GemType.isGem(var12)) {
               return var11;
            }

            if (var2 != null && var2.isRegisteredGem(var12)) {
               return var11;
            }
         }
      }

      return null;
   }

   public boolean isAnyGem(String var1) {
      if (var1 == null) {
         return false;
      } else if (GemType.isGem(var1)) {
         return true;
      } else {
         GemRegistryImpl var2 = this.a.getGemRegistry();
         return var2 != null && var2.isRegisteredGem(var1);
      }
   }

   public boolean replaceGemType(Player var1, GemType var2) {
      ItemStack var3 = this.findGemInInventory(var1);
      if (var3 == null) {
         return false;
      } else {
         String var4 = CustomItemManager.getIdByItem(var3);
         if (var4 == null) {
            return false;
         } else {
            int var5 = GemType.getTierFromOraxenId(var4);
            String var6 = GemType.buildOraxenId(var2, var5);
            int var7 = this.a.getEnergyManager().getEnergy(var1);
            ItemStack var8 = CustomItemManager.getItemById(var6, var7);
            if (var8 == null) {
               return false;
            } else {
               for(int var9 = 0; var9 < var1.getInventory().getSize(); ++var9) {
                  ItemStack var10 = var1.getInventory().getItem(var9);
                  if (var10 != null && var10.equals(var3)) {
                     var1.getInventory().setItem(var9, var8);
                     this.updateActiveGem(var1);
                     return true;
                  }
               }

               return false;
            }
         }
      }
   }

   public boolean upgradeGem(Player var1, GemType var2) {
      ItemStack var3 = this.findGemInInventory(var1);
      if (var3 == null) {
         return false;
      } else {
         String var4 = CustomItemManager.getIdByItem(var3);
         if (var4 == null) {
            return false;
         } else {
            GemType var5 = GemType.fromOraxenId(var4);
            int var6 = GemType.getTierFromOraxenId(var4);
            if (var5 == var2 && var6 == 1) {
               String var7 = GemType.buildOraxenId(var2, 2);
               int var8 = this.a.getEnergyManager().getEnergy(var1);
               ItemStack var9 = CustomItemManager.getItemById(var7, var8);
               if (var9 == null) {
                  return false;
               } else {
                  for(int var10 = 0; var10 < var1.getInventory().getSize(); ++var10) {
                     ItemStack var11 = var1.getInventory().getItem(var10);
                     if (var11 != null && var11.equals(var3)) {
                        var1.getInventory().setItem(var10, var9);
                        this.updateActiveGem(var1);
                        return true;
                     }
                  }

                  return false;
               }
            } else {
               return false;
            }
         }
      }
   }

   public void updateGemTextures(Player var1) {
      int var2 = this.a.getEnergyManager().getEnergy(var1);

      for(ItemStack var6 : var1.getInventory().getContents()) {
         if (var6 != null) {
            CustomItemManager.updateGemTexture(var6, var2);
         }
      }

   }

   public void clearCache(UUID var1) {
      this.b.remove(var1);
   }

   public static class ActiveGem {
      private final GemType a;
      private final String b;
      private final int c;

      public ActiveGem(GemType var1, int var2) {
         this.a = var1;
         this.b = var1 != null ? var1.getId() : null;
         this.c = var2;
      }

      public ActiveGem(String var1, int var2) {
         this.a = null;
         this.b = var1;
         this.c = var2;
      }

      public GemType getType() {
         return this.a;
      }

      public String getGemId() {
         return this.b;
      }

      public int getTier() {
         return this.c;
      }
   }
}
