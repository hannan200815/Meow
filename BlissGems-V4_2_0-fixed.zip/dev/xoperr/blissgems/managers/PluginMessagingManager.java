package dev.xoperr.blissgems.managers;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.GemType;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;

public class PluginMessagingManager implements PluginMessageListener {
   private final BlissGems a;
   public static final String ABILITY_CHANNEL = "blissgems:ability";
   public static final String GEM_DATA_CHANNEL = "blissgems:gemdata";

   public PluginMessagingManager(BlissGems var1) {
      this.a = var1;
      var1.getServer().getMessenger().registerIncomingPluginChannel(var1, "blissgems:ability", this);
      var1.getServer().getMessenger().registerOutgoingPluginChannel(var1, "blissgems:gemdata");
   }

   public void onPluginMessageReceived(String var1, Player var2, byte[] var3) {
      if (var1.equals("blissgems:ability")) {
         ByteArrayDataInput var4 = ByteStreams.newDataInput(var3);
         String var5 = var4.readUTF();
         if (!this.a.getGemManager().hasActiveGem(var2)) {
            var2.sendMessage("§c§lYou don't have a gem!");
         } else {
            int var6 = this.a.getEnergyManager().getEnergy(var2);
            if (var6 <= 0) {
               String var11 = this.a.getConfigManager().getFormattedMessage("no-energy");
               if (var11 != null && !var11.isEmpty()) {
                  var2.sendMessage(var11);
               }

            } else {
               GemType var7 = this.a.getGemManager().getGemType(var2);
               int var8 = this.a.getGemManager().getGemTier(var2);
               if (var7 != null) {
                  switch (var5) {
                     case "main":
                        this.a(var2, var7, var8);
                        break;
                     case "secondary":
                        if (var8 < 2) {
                           var2.sendMessage("§c§lSecondary abilities require Tier 2 gem!");
                           return;
                        }

                        this.b(var2, var7, var8);
                        break;
                     case "tertiary":
                        if (var8 < 2) {
                           var2.sendMessage("§c§lTertiary abilities require Tier 2 gem!");
                           return;
                        }

                        this.c(var2, var7, var8);
                  }

               }
            }
         }
      }
   }

   private void a(Player var1, GemType var2, int var3) {
      switch (var2) {
         case ASTRA -> this.a.getAstraAbilities().a(var1, var3);
         case FIRE -> this.a.getFireAbilities().a(var1, var3);
         case FLUX -> this.a.getFluxAbilities().a(var1, var3);
         case LIFE -> this.a.getLifeAbilities().a(var1, var3);
         case PUFF -> this.a.getPuffAbilities().a(var1, var3);
         case SPEED -> this.a.getSpeedAbilities().a(var1, var3);
         case STRENGTH -> this.a.getStrengthAbilities().a(var1, var3);
         case WEALTH -> this.a.getWealthAbilities().a(var1, var3);
      }

   }

   private void b(Player var1, GemType var2, int var3) {
      switch (var2) {
         case ASTRA -> this.a.getAstraAbilities().a(var1, var3);
         case FIRE -> this.a.getFireAbilities().a(var1, var3);
         case FLUX -> this.a.getFluxAbilities().a(var1, var3);
         case LIFE -> this.a.getLifeAbilities().a(var1, var3);
         case PUFF -> this.a.getPuffAbilities().a(var1, var3);
         case SPEED -> this.a.getSpeedAbilities().a(var1, var3);
         case STRENGTH -> this.a.getStrengthAbilities().a(var1, var3);
         case WEALTH -> this.a.getWealthAbilities().a(var1, var3);
      }

   }

   private void c(Player var1, GemType var2, int var3) {
      switch (var2) {
         case WEALTH -> this.a.getWealthAbilities().a(var1, var3);
         default -> var1.sendMessage("§c§lThis gem doesn't have a tertiary ability!");
      }

   }

   public void sendGemData(Player var1) {
      if (var1.isOnline()) {
         GemType var2 = this.a.getGemManager().getGemType(var1);
         int var3 = this.a.getGemManager().getGemTier(var1);
         int var4 = this.a.getEnergyManager().getEnergy(var1);
         ByteArrayDataOutput var5 = ByteStreams.newDataOutput();
         var5.writeUTF(var2 != null ? var2.name() : "NONE");
         var5.writeInt(var3);
         var5.writeInt(var4);
         var1.sendPluginMessage(this.a, "blissgems:gemdata", var5.toByteArray());
      }
   }

   public void shutdown() {
      this.a.getServer().getMessenger().unregisterIncomingPluginChannel(this.a, "blissgems:ability");
      this.a.getServer().getMessenger().unregisterOutgoingPluginChannel(this.a, "blissgems:gemdata");
   }
}
