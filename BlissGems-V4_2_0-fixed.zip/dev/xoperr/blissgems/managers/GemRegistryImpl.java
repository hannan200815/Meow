package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.CooldownEntry;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.api.GemDefinition;
import dev.xoperr.blissgems.api.GemPassiveHandler;
import dev.xoperr.blissgems.api.GemRegistry;
import dev.xoperr.blissgems.utils.CustomItemManager;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GemRegistryImpl implements GemRegistry {
   private static final Pattern a = Pattern.compile("^(.+)_gem_t(\\d+)$");
   private final BlissGems b;
   private final Logger c;
   private final Map<String, GemDefinition> d = new ConcurrentHashMap();
   private final Map<String, GemAbilityHandler> e = new ConcurrentHashMap();
   private final Map<String, GemPassiveHandler> f = new ConcurrentHashMap();
   private final Map<String, List<CooldownEntry>> g = new ConcurrentHashMap();

   public GemRegistryImpl(BlissGems var1) {
      this.b = var1;
      this.c = var1.getLogger();
   }

   public void registerGem(GemDefinition var1) {
      String var2 = var1.getId();
      if (this.d.containsKey(var2)) {
         throw new IllegalArgumentException("Gem ID '" + var2 + "' is already registered!");
      } else {
         this.d.put(var2, var1);
         if (!"BlissGems".equals(var1.getPluginName())) {
            this.a(var1);
         }

         this.c.info("[AddonAPI] Registered gem: " + var2 + " (" + var1.getPluginName() + ")");
      }
   }

   private void a(GemDefinition var1) {
      if (var1.getT1CustomModelData() > 0) {
         String var2 = var1.buildItemId(1);
         String var3 = var1.getT1DisplayName() != null ? var1.getT1DisplayName() : var1.getColor() + "§l" + var1.getDisplayName().toUpperCase() + " GEM";
         CustomItemManager.registerAddonItem(var2, var1.getMaterial(), var1.getT1CustomModelData(), var3, var1.getT1Lore());
      }

      if (var1.getMaxTier() >= 2 && var1.getT2CustomModelData() > 0) {
         String var4 = var1.buildItemId(2);
         String var5 = var1.getT2DisplayName() != null ? var1.getT2DisplayName() : var1.getColor() + "§l" + var1.getDisplayName().toUpperCase() + " GEM";
         CustomItemManager.registerAddonItem(var4, var1.getMaterial(), var1.getT2CustomModelData(), var5, var1.getT2Lore());
      }

   }

   public void registerAbilities(String var1, GemAbilityHandler var2) {
      this.e.put(var1, var2);
   }

   public void registerPassives(String var1, GemPassiveHandler var2) {
      this.f.put(var1, var2);
   }

   public void registerCooldowns(String var1, List<CooldownEntry> var2) {
      this.g.put(var1, Collections.unmodifiableList(new ArrayList(var2)));
   }

   public GemDefinition getGem(String var1) {
      return (GemDefinition)this.d.get(var1);
   }

   public GemAbilityHandler getAbilityHandler(String var1) {
      return (GemAbilityHandler)this.e.get(var1);
   }

   public GemPassiveHandler getPassiveHandler(String var1) {
      return (GemPassiveHandler)this.f.get(var1);
   }

   public List<CooldownEntry> getCooldownEntries(String var1) {
      return (List)this.g.getOrDefault(var1, Collections.emptyList());
   }

   public Collection<GemDefinition> getAllGems() {
      return Collections.unmodifiableCollection(this.d.values());
   }

   public boolean isRegisteredGem(String var1) {
      return this.gemIdFromItemId(var1) != null;
   }

   public String gemIdFromItemId(String var1) {
      if (var1 == null) {
         return null;
      } else {
         Matcher var2 = a.matcher(var1);
         if (var2.matches()) {
            String var3 = var2.group(1);
            if (this.d.containsKey(var3)) {
               return var3;
            }
         }

         return null;
      }
   }

   public int tierFromItemId(String var1) {
      if (var1 == null) {
         return 1;
      } else {
         Matcher var2 = a.matcher(var1);
         if (var2.matches()) {
            try {
               return Integer.parseInt(var2.group(2));
            } catch (NumberFormatException var4) {
               return 1;
            }
         } else {
            return 1;
         }
      }
   }
}
