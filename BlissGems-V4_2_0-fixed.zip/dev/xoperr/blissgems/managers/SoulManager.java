package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.attribute.AttributeModifier.Operation;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.NPC;
import org.bukkit.entity.Player;

public class SoulManager {
   private final BlissGems a;
   private final NamespacedKey b;
   private final Map<UUID, List<CapturedMob>> c = new HashMap();
   private static final int d = 2;
   private static final String e = "soul_absorb_";
   private int f = 0;
   private final Map<UUID, List<UUID>> g = new HashMap();

   public SoulManager(BlissGems var1) {
      this.a = var1;
      this.b = new NamespacedKey(var1, "captured_mob");
   }

   public void absorbSoul(Player var1, Entity var2) {
      boolean var3 = var2 instanceof Player;
      double var4;
      if (var3) {
         var4 = this.a.getConfig().getDouble("abilities.soul-absorption.player-kill-hearts", (double)10.0F);
      } else {
         var4 = this.a.getConfig().getDouble("abilities.soul-absorption.mob-kill-hearts", (double)4.0F);
      }

      int var6 = this.a.getConfig().getInt("abilities.soul-absorption.duration", 60);
      AttributeInstance var7 = var1.getAttribute(Attribute.GENERIC_MAX_HEALTH);
      if (var7 != null) {
         UUID var8 = UUID.randomUUID();
         BlissGems var10002 = this.a;
         String var10003 = var8.toString();
         NamespacedKey var9 = new NamespacedKey(var10002, "soul-absorb-" + var10003.replace("-", ""));
         ++this.f;
         AttributeModifier var10 = new AttributeModifier(var8, var9.toString(), var4, Operation.ADD_NUMBER);
         var7.addModifier(var10);
         ((List)this.g.computeIfAbsent(var1.getUniqueId(), (var0) -> new ArrayList())).add(var8);
         this.a(var1.getUniqueId(), var8);
         this.a.getServer().getScheduler().runTaskLater(this.a, () -> {
            if (var1.isOnline()) {
               var7.removeModifier(var10);
               double var5 = var7.getValue();
               if (var1.getHealth() > var5) {
                  var1.setHealth(var5);
               }
            }

            List var7x = (List)this.g.get(var1.getUniqueId());
            if (var7x != null) {
               var7x.remove(var8);
               if (var7x.isEmpty()) {
                  this.g.remove(var1.getUniqueId());
               }
            }

            this.b(var1.getUniqueId(), var8);
         }, (long)var6 * 20L);
         var1.getWorld().spawnParticle(Particle.SOUL, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 15, (double)0.5F, (double)0.5F, (double)0.5F, 0.05);
         var1.getWorld().spawnParticle(Particle.ENCHANTED_HIT, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F);
         var1.playSound(var1.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.5F);
         var1.playSound(var1.getLocation(), Sound.BLOCK_SOUL_SAND_BREAK, 1.0F, 1.5F);
         String var11 = var3 ? ((Player)var2).getName() : var2.getType().toString().toLowerCase().replace("_", " ");
         var1.sendMessage("§d§oAbsorbed soul from " + var11 + "! +" + var4 / (double)2.0F + " hearts for " + var6 + "s");
      }
   }

   public boolean captureMob(Player var1, LivingEntity var2) {
      if (var2 instanceof Player) {
         var1.sendMessage("§c§oCannot capture players!");
         return false;
      } else {
         List var3 = (List)this.c.computeIfAbsent(var1.getUniqueId(), (var0) -> new ArrayList());
         if (var3.size() >= 2) {
            var1.sendMessage("§c§oYour gem is full! (Max 2 souls)");
            return false;
         } else if (!this.a(var2)) {
            var1.sendMessage("§c§oThis entity cannot be captured!");
            return false;
         } else {
            CapturedMob var4 = new CapturedMob(var2.getType(), var2.getCustomName());
            var3.add(var4);
            var2.remove();
            Location var5 = var2.getLocation();
            var5.getWorld().spawnParticle(Particle.REVERSE_PORTAL, var5.add((double)0.0F, (double)1.0F, (double)0.0F), 50, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
            var5.getWorld().spawnParticle(Particle.WITCH, var5, 30, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F);
            var1.playSound(var1.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 1.0F, 2.0F);
            String var6 = var4.getDisplayName();
            var1.sendMessage("§d§lSoul Captured! §d§oCaptured " + var6 + " (" + var3.size() + "/2)");
            return true;
         }
      }
   }

   public void releaseAllSouls(Player var1) {
      List var2 = (List)this.c.get(var1.getUniqueId());
      if (var2 != null && !var2.isEmpty()) {
         Location var3 = var1.getLocation().add(var1.getLocation().getDirection().multiply(2));
         var3.setY(var1.getLocation().getY());
         Collections.reverse(var2);
         int var4 = 0;

         for(CapturedMob var6 : var2) {
            Entity var7 = var1.getWorld().spawnEntity(var3, var6.getType());
            if (var6.getCustomName() != null && var7 instanceof LivingEntity) {
               var7.setCustomName(var6.getCustomName());
               var7.setCustomNameVisible(true);
            }

            var3.getWorld().spawnParticle(Particle.PORTAL, var3.add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
            ++var4;
         }

         var2.clear();
         var1.playSound(var1.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 1.0F, 0.8F);
         var1.sendMessage("§d§lReleased " + var4 + " captured soul(s)!");
      } else {
         var1.sendMessage("§c§oNo souls captured!");
      }
   }

   public List<CapturedMob> getCapturedSouls(Player var1) {
      return (List)this.c.getOrDefault(var1.getUniqueId(), new ArrayList());
   }

   public int getCapturedCount(Player var1) {
      return this.getCapturedSouls(var1).size();
   }

   private boolean a(LivingEntity var1) {
      EntityType var2 = var1.getType();
      return var2 != EntityType.ENDER_DRAGON && var2 != EntityType.WITHER && var2 != EntityType.WARDEN && var2 != EntityType.PLAYER && var2 != EntityType.ARMOR_STAND && !(var1 instanceof NPC);
   }

   public void clearSouls(UUID var1) {
      this.c.remove(var1);
   }

   public void cleanup(Player var1) {
      AttributeInstance var2 = var1.getAttribute(Attribute.GENERIC_MAX_HEALTH);
      if (var2 != null) {
         Set var3 = this.b(var1.getUniqueId());
         ArrayList var4 = new ArrayList();

         for(AttributeModifier var6 : var2.getModifiers()) {
            if (var6.getUniqueId() != null && var3.contains(var6.getUniqueId())) {
               var4.add(var6);
            } else if (this.a(var6)) {
               var4.add(var6);
            }
         }

         for(AttributeModifier var9 : var4) {
            var2.removeModifier(var9);
         }

         double var8 = var2.getValue();
         if (var1.getHealth() > var8) {
            var1.setHealth(var8);
         }

         this.g.remove(var1.getUniqueId());
         this.c(var1.getUniqueId());
         if (!var4.isEmpty()) {
            Logger var10000 = this.a.getLogger();
            int var10001 = var4.size();
            var10000.info("[SoulManager] Removed " + var10001 + " stale soul-absorb modifier(s) from " + var1.getName());
         }

      }
   }

   private boolean a(AttributeModifier var1) {
      String var2 = var1.getName();
      if (var2 != null) {
         String var3 = var2.toLowerCase();
         if (var3.contains("soul_absorb") || var3.contains("soul-absorb")) {
            return true;
         }

         if (var3.startsWith("blissgems:")) {
            return true;
         }
      }

      try {
         NamespacedKey var6 = var1.getKey();
         if (var6 != null) {
            if ("blissgems".equals(var6.getNamespace())) {
               return true;
            }

            String var4 = var6.getKey();
            if (var4 != null && (var4.contains("soul_absorb") || var4.contains("soul-absorb"))) {
               return true;
            }
         }
      } catch (Throwable var5) {
      }

      return false;
   }

   private File a(UUID var1) {
      File var2 = new File(this.a.getDataFolder(), "playerdata");
      if (!var2.exists()) {
         var2.mkdirs();
      }

      return new File(var2, String.valueOf(var1) + ".yml");
   }

   private void a(UUID var1, UUID var2) {
      File var3 = this.a(var1);
      YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
      List var5 = ((FileConfiguration)var4).getStringList("soul-modifier-uuids");
      var5.add(var2.toString());
      ((FileConfiguration)var4).set("soul-modifier-uuids", var5);

      try {
         ((FileConfiguration)var4).save(var3);
      } catch (IOException var7) {
      }

   }

   private void b(UUID var1, UUID var2) {
      File var3 = this.a(var1);
      if (var3.exists()) {
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         List var5 = ((FileConfiguration)var4).getStringList("soul-modifier-uuids");
         var5.remove(var2.toString());
         ((FileConfiguration)var4).set("soul-modifier-uuids", var5.isEmpty() ? null : var5);

         try {
            ((FileConfiguration)var4).save(var3);
         } catch (IOException var7) {
         }

      }
   }

   private Set<UUID> b(UUID var1) {
      File var2 = this.a(var1);
      if (!var2.exists()) {
         return Collections.emptySet();
      } else {
         YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
         List var4 = ((FileConfiguration)var3).getStringList("soul-modifier-uuids");
         HashSet var5 = new HashSet();

         for(String var7 : var4) {
            try {
               var5.add(UUID.fromString(var7));
            } catch (IllegalArgumentException var9) {
            }
         }

         return var5;
      }
   }

   private void c(UUID var1) {
      File var2 = this.a(var1);
      if (var2.exists()) {
         YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
         if (((FileConfiguration)var3).contains("soul-modifier-uuids")) {
            ((FileConfiguration)var3).set("soul-modifier-uuids", (Object)null);

            try {
               ((FileConfiguration)var3).save(var2);
            } catch (IOException var5) {
            }
         }

      }
   }

   public static class CapturedMob {
      private final EntityType a;
      private final String b;

      public CapturedMob(EntityType var1, String var2) {
         this.a = var1;
         this.b = var2;
      }

      public EntityType getType() {
         return this.a;
      }

      public String getCustomName() {
         return this.b;
      }

      public String getDisplayName() {
         return this.b != null && !this.b.isEmpty() ? this.b : this.a.toString().toLowerCase().replace("_", " ");
      }
   }
}
