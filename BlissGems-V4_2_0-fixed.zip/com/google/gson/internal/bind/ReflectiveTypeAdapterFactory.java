package com.google.gson.internal.bind;

import com.google.gson.FieldNamingStrategy;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.ReflectionAccessFilter;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.$Gson$Types;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.internal.ObjectConstructor;
import com.google.gson.internal.Primitives;
import com.google.gson.internal.ReflectionAccessFilterHelper;
import com.google.gson.internal.reflect.ReflectionHelper;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ReflectiveTypeAdapterFactory implements TypeAdapterFactory {
   private final ConstructorConstructor constructorConstructor;
   private final FieldNamingStrategy fieldNamingPolicy;
   private final Excluder excluder;
   private final JsonAdapterAnnotationTypeAdapterFactory jsonAdapterFactory;
   private final List<ReflectionAccessFilter> reflectionFilters;

   public ReflectiveTypeAdapterFactory(ConstructorConstructor var1, FieldNamingStrategy var2, Excluder var3, JsonAdapterAnnotationTypeAdapterFactory var4, List<ReflectionAccessFilter> var5) {
      this.constructorConstructor = var1;
      this.fieldNamingPolicy = var2;
      this.excluder = var3;
      this.jsonAdapterFactory = var4;
      this.reflectionFilters = var5;
   }

   private boolean includeField(Field var1, boolean var2) {
      return !this.excluder.excludeClass(var1.getType(), var2) && !this.excluder.excludeField(var1, var2);
   }

   private List<String> getFieldNames(Field var1) {
      SerializedName var2 = (SerializedName)var1.getAnnotation(SerializedName.class);
      if (var2 == null) {
         String var6 = this.fieldNamingPolicy.translateName(var1);
         return Collections.singletonList(var6);
      } else {
         String var3 = var2.value();
         String[] var4 = var2.alternate();
         if (var4.length == 0) {
            return Collections.singletonList(var3);
         } else {
            ArrayList var5 = new ArrayList(var4.length + 1);
            var5.add(var3);
            Collections.addAll(var5, var4);
            return var5;
         }
      }
   }

   public <T> TypeAdapter<T> create(Gson var1, TypeToken<T> var2) {
      Class var3 = var2.getRawType();
      if (!Object.class.isAssignableFrom(var3)) {
         return null;
      } else {
         ReflectionAccessFilter.FilterResult var4 = ReflectionAccessFilterHelper.getFilterResult(this.reflectionFilters, var3);
         if (var4 == ReflectionAccessFilter.FilterResult.BLOCK_ALL) {
            throw new JsonIOException("ReflectionAccessFilter does not permit using reflection for " + var3 + ". Register a TypeAdapter for this type or adjust the access filter.");
         } else {
            boolean var5 = var4 == ReflectionAccessFilter.FilterResult.BLOCK_INACCESSIBLE;
            if (ReflectionHelper.isRecord(var3)) {
               RecordAdapter var7 = new RecordAdapter(var3, this.getBoundFields(var1, var2, var3, var5, true), var5);
               return var7;
            } else {
               ObjectConstructor var6 = this.constructorConstructor.get(var2);
               return new FieldReflectionAdapter<T>(var6, this.getBoundFields(var1, var2, var3, var5, false));
            }
         }
      }
   }

   private static <M extends AccessibleObject & Member> void checkAccessible(Object var0, M var1) {
      if (!ReflectionAccessFilterHelper.canAccess(var1, Modifier.isStatic(((Member)var1).getModifiers()) ? null : var0)) {
         String var2 = ReflectionHelper.getAccessibleObjectDescription(var1, true);
         throw new JsonIOException(var2 + " is not accessible and ReflectionAccessFilter does not permit making it accessible. Register a TypeAdapter for the declaring type, adjust the access filter or increase the visibility of the element and its declaring type.");
      }
   }

   private BoundField createBoundField(final Gson var1, Field var2, final Method var3, String var4, final TypeToken<?> var5, boolean var6, boolean var7, final boolean var8) {
      final boolean var9 = Primitives.isPrimitive(var5.getRawType());
      int var10 = var2.getModifiers();
      final boolean var11 = Modifier.isStatic(var10) && Modifier.isFinal(var10);
      JsonAdapter var12 = (JsonAdapter)var2.getAnnotation(JsonAdapter.class);
      final TypeAdapter var13 = null;
      if (var12 != null) {
         var13 = this.jsonAdapterFactory.getTypeAdapter(this.constructorConstructor, var1, var5, var12);
      }

      final boolean var14 = var13 != null;
      if (var13 == null) {
         var13 = var1.getAdapter(var5);
      }

      return new BoundField(var4, var2, var6, var7) {
         void write(JsonWriter var1x, Object var2) throws IOException, IllegalAccessException {
            if (this.serialized) {
               if (var8) {
                  if (var3 == null) {
                     ReflectiveTypeAdapterFactory.checkAccessible(var2, this.field);
                  } else {
                     ReflectiveTypeAdapterFactory.checkAccessible(var2, var3);
                  }
               }

               Object var3x;
               if (var3 != null) {
                  try {
                     var3x = var3.invoke(var2);
                  } catch (InvocationTargetException var6) {
                     String var5x = ReflectionHelper.getAccessibleObjectDescription(var3, false);
                     throw new JsonIOException("Accessor " + var5x + " threw exception", var6.getCause());
                  }
               } else {
                  var3x = this.field.get(var2);
               }

               if (var3x != var2) {
                  var1x.name(this.name);
                  Object var4 = var14 ? var13 : new TypeAdapterRuntimeTypeWrapper(var1, var13, var5.getType());
                  ((TypeAdapter)var4).write(var1x, var3x);
               }
            }
         }

         void readIntoArray(JsonReader var1x, int var2, Object[] var3x) throws IOException, JsonParseException {
            Object var4 = var13.read(var1x);
            if (var4 == null && var9) {
               throw new JsonParseException("null is not allowed as value for record component '" + this.fieldName + "' of primitive type; at path " + var1x.getPath());
            } else {
               var3x[var2] = var4;
            }
         }

         void readIntoField(JsonReader var1x, Object var2) throws IOException, IllegalAccessException {
            Object var3x = var13.read(var1x);
            if (var3x != null || !var9) {
               if (var8) {
                  ReflectiveTypeAdapterFactory.checkAccessible(var2, this.field);
               } else if (var11) {
                  String var4 = ReflectionHelper.getAccessibleObjectDescription(this.field, false);
                  throw new JsonIOException("Cannot set value of 'static final' " + var4);
               }

               this.field.set(var2, var3x);
            }

         }
      };
   }

   private Map<String, BoundField> getBoundFields(Gson var1, TypeToken<?> var2, Class<?> var3, boolean var4, boolean var5) {
      LinkedHashMap var6 = new LinkedHashMap();
      if (var3.isInterface()) {
         return var6;
      } else {
         for(Class var7 = var3; var3 != Object.class; var3 = var2.getRawType()) {
            Field[] var8 = var3.getDeclaredFields();
            if (var3 != var7 && var8.length > 0) {
               ReflectionAccessFilter.FilterResult var9 = ReflectionAccessFilterHelper.getFilterResult(this.reflectionFilters, var3);
               if (var9 == ReflectionAccessFilter.FilterResult.BLOCK_ALL) {
                  throw new JsonIOException("ReflectionAccessFilter does not permit using reflection for " + var3 + " (supertype of " + var7 + "). Register a TypeAdapter for this type or adjust the access filter.");
               }

               var4 = var9 == ReflectionAccessFilter.FilterResult.BLOCK_INACCESSIBLE;
            }

            for(Field var12 : var8) {
               boolean var13 = this.includeField(var12, true);
               boolean var14 = this.includeField(var12, false);
               if (var13 || var14) {
                  Method var15 = null;
                  if (var5) {
                     if (Modifier.isStatic(var12.getModifiers())) {
                        var14 = false;
                     } else {
                        var15 = ReflectionHelper.getAccessor(var3, var12);
                        if (!var4) {
                           ReflectionHelper.makeAccessible(var15);
                        }

                        if (var15.getAnnotation(SerializedName.class) != null && var12.getAnnotation(SerializedName.class) == null) {
                           String var25 = ReflectionHelper.getAccessibleObjectDescription(var15, false);
                           throw new JsonIOException("@SerializedName on " + var25 + " is not supported");
                        }
                     }
                  }

                  if (!var4 && var15 == null) {
                     ReflectionHelper.makeAccessible(var12);
                  }

                  Type var16 = $Gson$Types.resolve(var2.getType(), var3, var12.getGenericType());
                  List var17 = this.getFieldNames(var12);
                  BoundField var18 = null;
                  int var19 = 0;

                  for(int var20 = var17.size(); var19 < var20; ++var19) {
                     String var21 = (String)var17.get(var19);
                     if (var19 != 0) {
                        var13 = false;
                     }

                     BoundField var22 = this.createBoundField(var1, var12, var15, var21, TypeToken.get(var16), var13, var14, var4);
                     BoundField var23 = (BoundField)var6.put(var21, var22);
                     if (var18 == null) {
                        var18 = var23;
                     }
                  }

                  if (var18 != null) {
                     throw new IllegalArgumentException("Class " + var7.getName() + " declares multiple JSON fields named '" + var18.name + "'; conflict is caused by fields " + ReflectionHelper.fieldToString(var18.field) + " and " + ReflectionHelper.fieldToString(var12));
                  }
               }
            }

            var2 = TypeToken.get($Gson$Types.resolve(var2.getType(), var3, var3.getGenericSuperclass()));
         }

         return var6;
      }
   }

   abstract static class BoundField {
      final String name;
      final Field field;
      final String fieldName;
      final boolean serialized;
      final boolean deserialized;

      protected BoundField(String var1, Field var2, boolean var3, boolean var4) {
         this.name = var1;
         this.field = var2;
         this.fieldName = var2.getName();
         this.serialized = var3;
         this.deserialized = var4;
      }

      abstract void write(JsonWriter var1, Object var2) throws IOException, IllegalAccessException;

      abstract void readIntoArray(JsonReader var1, int var2, Object[] var3) throws IOException, JsonParseException;

      abstract void readIntoField(JsonReader var1, Object var2) throws IOException, IllegalAccessException;
   }

   public abstract static class Adapter<T, A> extends TypeAdapter<T> {
      final Map<String, BoundField> boundFields;

      Adapter(Map<String, BoundField> var1) {
         this.boundFields = var1;
      }

      public void write(JsonWriter var1, T var2) throws IOException {
         if (var2 == null) {
            var1.nullValue();
         } else {
            var1.beginObject();

            try {
               for(BoundField var4 : this.boundFields.values()) {
                  var4.write(var1, var2);
               }
            } catch (IllegalAccessException var5) {
               throw ReflectionHelper.createExceptionForUnexpectedIllegalAccess(var5);
            }

            var1.endObject();
         }
      }

      public T read(JsonReader var1) throws IOException {
         if (var1.peek() == JsonToken.NULL) {
            var1.nextNull();
            return null;
         } else {
            Object var2 = this.createAccumulator();

            try {
               var1.beginObject();

               while(var1.hasNext()) {
                  String var3 = var1.nextName();
                  BoundField var4 = (BoundField)this.boundFields.get(var3);
                  if (var4 != null && var4.deserialized) {
                     this.readField(var2, var1, var4);
                  } else {
                     var1.skipValue();
                  }
               }
            } catch (IllegalStateException var5) {
               throw new JsonSyntaxException(var5);
            } catch (IllegalAccessException var6) {
               throw ReflectionHelper.createExceptionForUnexpectedIllegalAccess(var6);
            }

            var1.endObject();
            return (T)this.finalize(var2);
         }
      }

      abstract A createAccumulator();

      abstract void readField(A var1, JsonReader var2, BoundField var3) throws IllegalAccessException, IOException;

      abstract T finalize(A var1);
   }

   private static final class FieldReflectionAdapter<T> extends Adapter<T, T> {
      private final ObjectConstructor<T> constructor;

      FieldReflectionAdapter(ObjectConstructor<T> var1, Map<String, BoundField> var2) {
         super(var2);
         this.constructor = var1;
      }

      T createAccumulator() {
         return this.constructor.construct();
      }

      void readField(T var1, JsonReader var2, BoundField var3) throws IllegalAccessException, IOException {
         var3.readIntoField(var2, var1);
      }

      T finalize(T var1) {
         return var1;
      }
   }

   private static final class RecordAdapter<T> extends Adapter<T, Object[]> {
      static final Map<Class<?>, Object> PRIMITIVE_DEFAULTS = primitiveDefaults();
      private final Constructor<T> constructor;
      private final Object[] constructorArgsDefaults;
      private final Map<String, Integer> componentIndices = new HashMap();

      RecordAdapter(Class<T> var1, Map<String, BoundField> var2, boolean var3) {
         super(var2);
         this.constructor = ReflectionHelper.<T>getCanonicalRecordConstructor(var1);
         if (var3) {
            ReflectiveTypeAdapterFactory.checkAccessible((Object)null, this.constructor);
         } else {
            ReflectionHelper.makeAccessible(this.constructor);
         }

         String[] var4 = ReflectionHelper.getRecordComponentNames(var1);

         for(int var5 = 0; var5 < var4.length; ++var5) {
            this.componentIndices.put(var4[var5], var5);
         }

         Class[] var7 = this.constructor.getParameterTypes();
         this.constructorArgsDefaults = new Object[var7.length];

         for(int var6 = 0; var6 < var7.length; ++var6) {
            this.constructorArgsDefaults[var6] = PRIMITIVE_DEFAULTS.get(var7[var6]);
         }

      }

      private static Map<Class<?>, Object> primitiveDefaults() {
         HashMap var0 = new HashMap();
         var0.put(Byte.TYPE, (byte)0);
         var0.put(Short.TYPE, (short)0);
         var0.put(Integer.TYPE, 0);
         var0.put(Long.TYPE, 0L);
         var0.put(Float.TYPE, 0.0F);
         var0.put(Double.TYPE, (double)0.0F);
         var0.put(Character.TYPE, '\u0000');
         var0.put(Boolean.TYPE, false);
         return var0;
      }

      Object[] createAccumulator() {
         return this.constructorArgsDefaults.clone();
      }

      void readField(Object[] var1, JsonReader var2, BoundField var3) throws IOException {
         Integer var4 = (Integer)this.componentIndices.get(var3.fieldName);
         if (var4 == null) {
            throw new IllegalStateException("Could not find the index in the constructor '" + ReflectionHelper.constructorToString(this.constructor) + "' for field with name '" + var3.fieldName + "', unable to determine which argument in the constructor the field corresponds to. This is unexpected behavior, as we expect the RecordComponents to have the same names as the fields in the Java class, and that the order of the RecordComponents is the same as the order of the canonical constructor parameters.");
         } else {
            var3.readIntoArray(var2, var4, var1);
         }
      }

      T finalize(Object[] var1) {
         try {
            return (T)this.constructor.newInstance(var1);
         } catch (IllegalAccessException var3) {
            throw ReflectionHelper.createExceptionForUnexpectedIllegalAccess(var3);
         } catch (IllegalArgumentException | InstantiationException var4) {
            throw new RuntimeException("Failed to invoke constructor '" + ReflectionHelper.constructorToString(this.constructor) + "' with args " + Arrays.toString(var1), var4);
         } catch (InvocationTargetException var5) {
            throw new RuntimeException("Failed to invoke constructor '" + ReflectionHelper.constructorToString(this.constructor) + "' with args " + Arrays.toString(var1), var5.getCause());
         }
      }
   }
}
