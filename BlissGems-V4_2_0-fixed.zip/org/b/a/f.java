package org.b.a;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

public final class f {
   private f() {
      throw new AssertionError("Debug should not be instantiated");
   }

   @Target({ElementType.TYPE})
   @Retention(RetentionPolicy.CLASS)
   public @interface a {
      @org.a.a.a.d(
         a = "JAVA",
         b = "class Renderer{String $text(){return ",
         c = ";}}"
      )
      @k String a() default "";

      @org.a.a.a.d(
         a = "JAVA",
         b = "class Renderer{Object[] $childrenArray(){return ",
         c = ";}}"
      )
      @k String b() default "";

      @org.a.a.a.d(
         a = "JAVA",
         b = "class Renderer{boolean $hasChildren(){return ",
         c = ";}}"
      )
      @k String c() default "";
   }
}
