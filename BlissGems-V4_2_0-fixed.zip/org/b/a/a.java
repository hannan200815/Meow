package org.b.a;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

public final class a {
   private a() {
      throw new AssertionError("ApiStatus should not be instantiated");
   }

   @Documented
   @Retention(RetentionPolicy.CLASS)
   @Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE, ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.PACKAGE})
   public @interface a {
      String a();
   }

   @Documented
   @Retention(RetentionPolicy.CLASS)
   @Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE, ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.PACKAGE})
   public @interface b {
   }

   @Documented
   @Retention(RetentionPolicy.CLASS)
   @Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE, ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.PACKAGE})
   public @interface c {
   }

   @Documented
   @Retention(RetentionPolicy.CLASS)
   @Target({ElementType.TYPE, ElementType.METHOD})
   public @interface d {
   }

   @Documented
   @Retention(RetentionPolicy.CLASS)
   @Target({ElementType.TYPE, ElementType.METHOD})
   public @interface e {
   }

   @Documented
   @Retention(RetentionPolicy.CLASS)
   @Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE, ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.PACKAGE})
   public @interface f {
      String a() default "";
   }
}
