package org.a.a.a;

@f(
   a = "\\p{javaJavaIdentifierStart}\\p{javaJavaIdentifierPart}*"
)
public @interface b {
}
